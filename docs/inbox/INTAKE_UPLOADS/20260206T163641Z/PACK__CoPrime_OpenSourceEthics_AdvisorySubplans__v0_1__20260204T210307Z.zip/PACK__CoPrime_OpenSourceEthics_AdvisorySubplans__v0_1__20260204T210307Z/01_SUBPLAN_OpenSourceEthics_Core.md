<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Subplan — Open‑source Ethics via Prompt Rails + Forks

## 1) Problem statement
CoCivium influences model behavior by injecting prompt rails (ethical / safety / consent / reversibility) into workflows.
Vendors can unilaterally reduce or eliminate rail effectiveness by deprioritizing or ignoring injected prompts.

## 2) Goal
Create a sustainable, multi-platform governance layer that:
- remains useful even when vendor behavior shifts,
- builds user trust through transparency,
- distributes risk via forks,
- and offers vendors an incentive-compatible adoption path.

## 3) Non-goals
- “Un-interceptable prompts.” We assume the vendor or wrapper can always alter/ignore prompts.
  The objective is **tamper evidence**, provenance, and user-facing auditability—not perfect enforcement.

## 4) System framing
### CoCivium is NOT selling prompts
Prompts must be public to be inspectable and verifiable. The value is:
- provenance (what rails were applied),
- UX (user-visible receipts),
- composition safety (rails that don’t conflict),
- detection (evidence when rails are ignored),
- ecosystem (forks + registry),
- operational tooling (CoStacks).

## 5) Key design constraints
- **Transparency**: users can view injected rails, versions, and sources.
- **Provenance**: rail packs are referenced by canonical URL + hash; optionally signed.
- **Composability safety**: rails can be combined without creating harmful behavior.
- **Forkability**: forks can exist without breaking the trust chain.
- **Vendor incentive**: modular adoption; vendors gain trust + governance exports.

## 6) Four-prong strategy
1) User trust → vendor incentive
2) Auditability → bypass becomes visible
3) Modular vendor adoption
4) User-side injection + fork ecosystem

## 7) Work breakdown
Implement modules A–I (separate subplans).
Start with A+B+C as the minimum viable “it’s real” foundation.

## 8) Success criteria (evidence-based)
- Users can export a receipt showing rails applied (IDs/hashes).
- A 3rd party can verify receipt integrity (hash/signature).
- Fork lineage is visible (parent hash/version).
- CoStacks can apply rail packs consistently across tools/models.
- “Ignore rails” behavior can be surfaced as a confidence score (later).
