<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Subplan — Module A: Canonical Rail Library (public rail packs)

    ## Intent
    Define and publish versioned rail packs (CoPRE/CoCrux/etc.) that are publicly inspectable and safely composable.

    ## Why it matters
    This is the foundation: without canonical packs, provenance/receipts/forks have nothing stable to reference.

    ## Scope
    - Rail pack structure: metadata, rails, compatibility, warnings
- Semantic versions + stable IDs
- Composition constraints and “known-bad combinations” list

    ## Outputs (repo artifacts)
    - `RAILS/` directory with packs
- `RAILS/MANIFEST.json` (index + hashes)
- `RAILS/CHANGELOG.md`

    ## Milestones
    - M1: Define pack schema (minimal)
- M2: Publish 3 “starter” packs (baseline safety, consent/reversibility, transparency/receipts)
- M3: Add composition rules + linter

    ## Risks / failure modes
    - Overcomplexity → stalls adoption
- Hidden conflicts between rails → safety regression
- Packs become “policy theater” without receipts/probes

    ## Immediate CoStacks impacts
    - CoStacks needs a Rail Pack Loader: fetch by URL, verify hash, load rails into injection pipeline.
