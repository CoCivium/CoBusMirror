<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Subplan — Module H: Legal Posture Pack (not legal advice)

    ## Intent
    Prepare a counsel-ready structure for disclaimers, scope boundaries, fork liability separation, and vendor partnership terms.

    ## Why it matters
    CoCivium sits between user and vendor; liability ambiguity must be managed proactively.

    ## Scope
    - Disclaimer patterns (decision-support framing)
- Fork branding separation (“sub-brand for forks”)
- Vendor partnership term options (badge use, receipt export)

    ## Outputs (repo artifacts)
    - `LEGAL_POSTURE.md` (counsel rewrite)
- `FORK_BRANDING_NOTES.md`
- `VENDOR_TERMS_OUTLINE.md`

    ## Milestones
    - M1: Draft counsel-ready outline
- M2: Integrate with UX (where disclaimers appear)
- M3: Fork terms and badge policy

    ## Risks / failure modes
    - Over-disclaiming harms trust
- Under-disclaiming increases exposure

    ## Immediate CoStacks impacts
    - CoStacks needs careful receipt language: applied/requested vs enforced.
