<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Subplan — Module C: Prompt Receipts (user-visible, exportable)

    ## Intent
    Generate a per-session/workflow receipt describing what rails were applied: IDs, versions, hashes, injection points, timestamps.

    ## Why it matters
    Receipts convert transparency into evidence. They also enable governance export for enterprise and vendor incentives.

    ## Scope
    - Receipt data model (JSON)
- Human-readable renderer (UI)
- Export and share mechanisms

    ## Outputs (repo artifacts)
    - `receipt.schema.json`
- `Receipt_Renderer_Spec.md`
- Example receipts

    ## Milestones
    - M1: Minimal receipt schema + export
- M2: Human-readable receipt view
- M3: Shareable “receipt link” pattern (optional)

    ## Risks / failure modes
    - Overclaiming compliance (receipt should include verification state)
- Privacy: receipts may leak sensitive prompts unless redaction rules exist

    ## Immediate CoStacks impacts
    - CoStacks needs: receipt generator in injection pipeline + receipt UI panel + export button.
