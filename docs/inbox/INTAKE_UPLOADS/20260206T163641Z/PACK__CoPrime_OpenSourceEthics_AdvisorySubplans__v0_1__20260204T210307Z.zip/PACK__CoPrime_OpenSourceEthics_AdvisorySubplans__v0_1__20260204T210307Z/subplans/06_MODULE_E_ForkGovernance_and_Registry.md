<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Subplan — Module E: Fork Governance + Registry

    ## Intent
    Enable a fork ecosystem while preserving lineage, trust categories, and user clarity.

    ## Why it matters
    Forking distributes risk and avoids a single target, but needs taxonomy to prevent trust collapse.

    ## Scope
    - Fork taxonomy: Verified / Derived / Unaffiliated
- Lineage metadata (parent hash/version)
- Optional registry index (public)

    ## Outputs (repo artifacts)
    - `fork_taxonomy.md`
- `fork_manifest.schema.json`
- `registry_index.md` (or JSON)

    ## Milestones
    - M1: Metadata + taxonomy
- M2: Minimal registry index + submission process
- M3: UI surfaces for fork trust category

    ## Risks / failure modes
    - Brand dilution if “fork” implies endorsement
- Governance disputes over who is “Verified”

    ## Immediate CoStacks impacts
    - CoStacks: allow loading forked packs; display trust category + lineage; block “Verified” badge unless checks pass.
