<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Subplan — Module D: Compliance Signals (detect rails being ignored)

    ## Intent
    Provide evidence-based signals when a model appears to ignore rails: probes, behavioral checks, consistency tests.

    ## Why it matters
    Vendors can ignore prompts; signals create reputational/UX costs for bypass and help users choose trustworthy stacks.

    ## Scope
    - Probe suite design (non-adversarial, user-safe)
- Confidence scoring rubric
- Reporting / visualization

    ## Outputs (repo artifacts)
    - `probes/` design doc
- `compliance_score_spec.md`
- Initial probe checklist

    ## Milestones
    - M1: 5–10 basic probes
- M2: Score aggregation + uncertainty communication
- M3: Automated regression tests for probes

    ## Risks / failure modes
    - False positives/negatives can damage trust
- Vendors may optimize for probes (Goodhart)

    ## Immediate CoStacks impacts
    - Add a “Compliance Confidence” widget fed by probe results; keep language cautious (“evidence suggests…”)
