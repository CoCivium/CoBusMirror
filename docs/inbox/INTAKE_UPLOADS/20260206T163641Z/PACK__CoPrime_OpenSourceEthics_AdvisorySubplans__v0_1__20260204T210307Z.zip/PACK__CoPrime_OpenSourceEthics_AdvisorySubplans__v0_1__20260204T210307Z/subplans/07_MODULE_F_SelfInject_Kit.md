<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Subplan — Module F: User-side Self-inject Kit (CoStacks helper)

    ## Intent
    Give users tooling to select, preview, and inject rail packs themselves—optionally using a separate AI to choose packs.

    ## Why it matters
    If vendors resist, users can still apply rails; also reduces single chokepoint and increases adoption velocity.

    ## Scope
    - Wrapper/extension UX for selecting packs
- “Preview diff” and “why these rails” explainer
- Injection integration points (chat, tool calls, workflows)

    ## Outputs (repo artifacts)
    - `SelfInject_UX_Spec.md`
- `Injection_Points_Spec.md`
- Prototype backlog items

    ## Milestones
    - M1: Manual rail selection + injection
- M2: Assisted selection (second AI) + explainability
- M3: Organization policy bundles (enterprise)

    ## Risks / failure modes
    - Users may misconfigure rails; need safe defaults
- Support load if UX is too complex

    ## Immediate CoStacks impacts
    - Direct CoStacks scope: start with minimal “rail picker” UI and injected prompt assembler.
