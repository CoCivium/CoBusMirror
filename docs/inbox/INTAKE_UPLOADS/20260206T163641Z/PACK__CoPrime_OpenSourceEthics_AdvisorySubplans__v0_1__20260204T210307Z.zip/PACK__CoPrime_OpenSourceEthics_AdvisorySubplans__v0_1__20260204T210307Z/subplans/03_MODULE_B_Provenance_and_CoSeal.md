<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Subplan — Module B: Provenance + Branding (CoSeal)

    ## Intent
    Make rail application tamper-evident via canonical URLs, hashes, and (optionally) signatures; enable a visible badge only when verified.

    ## Why it matters
    You cannot prevent vendors from ignoring rails, but you can prevent silent substitution and create verifiable lineage.

    ## Scope
    - Define CoSeal: what counts as “Verified”
- Hash-based integrity checks (required)
- Signature-based verification (optional, later)

    ## Outputs (repo artifacts)
    - `COSEAL_SPEC.md`
- verifier tool spec (hash now, signatures later)
- `badge_rules.md` (when UI may display “Verified”)

    ## Milestones
    - M1: Hash-only verification with manifest
- M2: Key management plan for signatures (public keys)
- M3: Add signature verification to tooling

    ## Risks / failure modes
    - Users misinterpret “Verified” as “enforced by vendor”
- Key compromise risk (if signatures used)

    ## Immediate CoStacks impacts
    - CoStacks must implement: (1) fetch manifest, (2) verify hash/signature, (3) surface verified status + failure reasons.
