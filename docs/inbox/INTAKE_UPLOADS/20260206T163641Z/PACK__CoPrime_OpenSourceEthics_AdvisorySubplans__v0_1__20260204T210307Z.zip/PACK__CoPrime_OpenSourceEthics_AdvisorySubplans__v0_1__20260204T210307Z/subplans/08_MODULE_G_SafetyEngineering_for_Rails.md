<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Subplan — Module G: Safety Engineering for Rail Packs

    ## Intent
    Treat rails like code: linting, composition rules, red-team tests, and rollback.

    ## Why it matters
    Open rails increase attack surface. Safety discipline prevents harmful combinations and unintended behaviors.

    ## Scope
    - Rail linter + composition validator
- Test harness + regression suite
- Rollback/version pinning practices

    ## Outputs (repo artifacts)
    - `rail_lint_rules.md`
- `tests/` harness spec
- `rollback_guidelines.md`

    ## Milestones
    - M1: Static linting rules
- M2: Composition tests for top packs
- M3: Red-team harness integration

    ## Risks / failure modes
    - If tests lag behind rail changes, confidence erodes
- Overly strict linting blocks innovation

    ## Immediate CoStacks impacts
    - CoStacks default mode should load only packs passing lint + verification.
