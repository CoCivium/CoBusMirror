<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# CoPrime Advisory Pack — Open‑source Ethics via Prompt Rails + Forks

## Purpose
This pack contains **repo-ready, modular advisory subplans** that CoPrime can park under MasterPlan as subordinate plans.
It formalizes a sustainable strategy for **CoCivium as a prompt‑rail injector** (and a forkable ecosystem), while highlighting **immediate impacts to CoStacks** product development.

## Suggested repo placement
Recommended directory layout (adjust to your canonical MasterPlan conventions):

- `docs/MasterPlan/subplans/CoCivium.OpenSourceEthics/`  
  - `00_EXEC_SUMMARY.md`
  - `01_SUBPLAN_OpenSourceEthics_Core.md`
  - `modules/` (A–I)
  - `CoStacks_Impacts_Immediate.md`
  - `Backlog_Suggested_Issues.md`
  - `annex/` (schemas, checklists)

## What’s inside
- `00_EXEC_SUMMARY_CoPrime.md` — fast decision brief: what/why/now
- `01_SUBPLAN_OpenSourceEthics_Core.md` — the “open‑source ethics” model + 4-prong strategy
- `subplans/` — Modules A–I as separate subplans
- `annex/schemas/` — optional starter schemas for receipts + manifests (minimal)

## Operating assumptions (explicit)
- **Prompts/rails are public**: inspectable, versioned, forkable.
- **Moat is not secrecy**: it’s provenance, audit UX, safety testing, distribution, and adoption.
- **Vendors can ignore rails**: resilience requires receipts, detection, and an ecosystem.
- **Forks are a feature**: distributed rails reduce single chokepoints and vendor-target risk.

## How CoPrime can use this pack (minimum viable sequence)
1. Land `00_EXEC_SUMMARY` + `01_SUBPLAN_OpenSourceEthics_Core` as MasterPlan subplans.
2. Prioritize Modules **A (Rail Library)**, **B (Provenance/CoSeal)**, **C (Receipts)** because they create immediate product surfaces for CoStacks.
3. Create a “rail pack registry” issue and a “receipt renderer UI” issue in CoStacks backlog.
4. Treat remaining modules as staged enhancements.

## Versioning
This pack is **v0.1**. Treat as advisory, not canon, until merged into MasterPlan and referenced by CoBeacon/CoBus rails.
