<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# CoStacks — Immediate Development Impacts from Open‑source Ethics Plan

## Why CoStacks is pivotal
CoStacks is the product surface that operationalizes:
- rail pack selection,
- injection consistency,
- provenance verification,
- user-visible receipts.

If CoStacks doesn’t ship these primitives, “open‑source ethics” remains theoretical.

## Highest-leverage near-term features (ordered)
1) Rail Pack Loader
- Input: canonical URL + expected hash (and/or signed manifest)
- Output: normalized “rail set” object for injection pipeline

2) CoSeal Verification
- Verify pack integrity (hash) + manifest version
- Surface status: Verified / Unverified / Failed with reasons

3) Receipt Generator
- Per workflow/session: list of rails applied, versions, injection points, timestamps
- Include verification status (what was verified vs not)

4) Receipt Renderer UI
- Human view: “what guardrails are applied”
- Export: JSON receipt + share copy

5) (Later) Compliance Confidence
- Run probes and show a cautious score with uncertainty

## UX principles (non-negotiable)
- Never claim “enforced by vendor” unless you can prove enforcement.
- Use language like “applied”, “requested”, “verified content”, “evidence suggests”.
- Provide “copy receipt” and “view rails” as first-class controls.

## Suggested backlog epics
- EPIC: Rail Packs
- EPIC: Receipts
- EPIC: CoSeal Verification
- EPIC: Fork Support + Trust Labels
- EPIC: Probe Suite + Compliance Confidence
