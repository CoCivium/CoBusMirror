<!--
PACK: PACK__CoPrime_OpenSourceEthics_AdvisorySubplans__v0_1__20260204T210307Z
UTC_BUILT: 20260204T210307Z
LICENSE: CC0-1.0 (intended) / public-domain style advisory content
DISCLAIMER: Not legal advice. Engineering + product governance advisory only.
-->
# Suggested Backlog / Issues to Open (CoPrime + CoStacks)

## CoPrime (MasterPlan subplans)
- Add subplan directory for `CoCivium.OpenSourceEthics` and link from MasterPlan index
- Define canonical placement + naming conventions for subplans/modules
- Decide whether “CoSeal” is a term to register in GIBindex

## CoStacks (product work)
- Rail Pack Loader (URL + hash, cache, version pinning)
- Receipt schema + generator integration
- Receipt renderer UI + export/share
- CoSeal verification step + UI badge rules
- Fork trust taxonomy in UI (Verified/Derived/Unaffiliated)
- Composition validator / linter (later)
- Probe suite scaffolding + confidence display (later)

## Governance & safety
- Rail pack authoring guidelines
- Composition “known-bad combos” list
- Redaction rules for receipts (protect user secrets)
