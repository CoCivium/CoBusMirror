# CoWorkflow Workflow Hierarchy + Profile Pack (v0_1)
**UTC build:** 20260204T220325Z

## Intent
Repackage the voice-notes into a concrete, portable taxonomy + starter schemas for:
- workflow units (atomic → mission scale)
- session / sub-session structure
- organization types (human/AI composition)
- role naming (legacy → AI-enabled “Co-roles”)
- default persona/profile for CoContributor / CoSteward (CoEvo-forward)

This is a *starter spec* designed to be evolved via repo-first workflow.

---

## A. Workflow hierarchy (proposed)
### A1) Atomic execution units
**CoDoBlock**  
- *Meaning:* The smallest “do this” instruction block (usually executed in PS7).  
- *Output:* concrete mutation(s): file(s), commit(s), hashes, logs.

**CoBlock**  
- *Meaning:* A packaged bundle of 1+ CoDoBlocks plus guardrails.  
- *Typical guardrails:* strict mode, fail-closed, sha checks, canonical RAW pointers, commit+push.

### A2) Conversational iteration units
**CoWave**  
- *Meaning:* One conversational iteration that ships **one scoped mutation** (or one reversible set).  
- *Rule of thumb:* 1 CoWave → 1 CoBlock → 1 “receipt” (hash/pointer).

**MegaWave**  
- *Meaning:* A bundle of CoWaves executed as a coordinated unit.  
- *Output:* usually a **MegaZip** plus a single “index/receipt” pointer.

**MegaZip**  
- *Meaning:* The file artifact containing the deliverables (plus sha sidecars) produced by a MegaWave.

### A3) Session container units
**CoSession**  
- *Meaning:* A labeled container for a sequence of CoWaves pursuing one intent thread.
- *Heuristic capacity cap:* ~**32 CoWaves** before bloat/lag risk becomes likely.

**SubSession**  
- *Meaning:* A temporary child session created to offload a sub-problem without polluting the parent.  
- *Contract:* SubSession returns **one pointer-pack** back to the parent (raw URLs + sha).

### A4) Product/work units
**CoTask** *(“workflow atomic unit” in human terms)*  
- *Meaning:* A user-meaningful work objective that may span multiple CoSessions/SubSessions.  
- *Heuristic:* up to **32 SubSessions** (rarely needed) to keep orchestration sane.

**CoProject**  
- *Meaning:* A scoped collection of CoTasks that yields a coherent deliverable set.  
- *One workable mental model:* **8 lanes × 32 waves** (8 “lots,” each up to 32 waves).

**CoMission**  
- *Meaning:* A scoped collection of CoProjects pursuing a broader strategic outcome (multi-project).

---

## B. Session types / “classes” (suggested)
Use these as *roles* a session can play, not necessarily separate repos.

- **CoPrime session:** orchestration / routing / “single throat to choke.”
- **CoWorker session:** executes a narrow task under a whitelist.
- **CoAudit session:** verify + reconcile + fail-closed checks.
- **CoCarry session:** packaging (zips, sha sidecars, pointer packs).
- **CoHalo session:** handoff glue; converts work into paste-safe SideNotes/pointers.

---

## C. Organization taxonomy (human/AI composition)
Define “nuclear” units by minimum membership + composition.

| Label | Humans | AIs | Notes |
|---|---:|---:|---|
| **SoloAI** | 0 | 1 | single model/agent |
| **NuclearBorg** | 0 | ≥2 | multi-AI collective, no humans |
| **SoloHuman** | 1 | 0 | just a person |
| **HumanTeam** | ≥2 | 0 | conventional team |
| **NuclearOrg** | ≥1 | ≥1 | minimum viable hybrid “org” |
| **HybridTeam** | ≥2 | ≥1 | expanded hybrid team (optional label) |

*Rationale:* “Org” implies hybrid legitimacy + governance (at least one human); all-AI multi-agent becomes “Borg.”

---

## D. Role taxonomy & naming
### D1) Pattern: CoRole indicates AI-enabled
- **Legacy role:** traditional title (e.g., “Product Manager”).
- **CoRole:** same intent but explicitly AI-enabled and workflow-governed (e.g., “CoProductSteward”).

**Guideline:**  
Use **Co-** prefix as a *capability marker*: the role uses AI as a first-class collaborator and follows consent / reversibility / evidence rails.

### D2) Starter role set
- **CoContributor:** contributes artifacts, ideas, and review; not necessarily technical.
- **CoConfigurer:** configures workflows/schemas/rails; turns intent into executable patterns.
- **CoSteward:** ensures ethics, consent, reversibility, auditability; protects against drift.
- **CoAuditor:** verifies hashes, pointers, provenance; detects forks/regressions.

(These can map to legacy roles, but the CoRole is the “new normal.”)

---

## E. Default CoContributor / CoSteward profile (draft)
### E1) Core stance
- **Constructive disagreement is preferred.**  
  The profile pushes back when something is inconsistent, unsafe, vague, or ego-driven.
- **No ego-stroking.**  
  Be direct; optimize for truth, clarity, and improved outcomes.
- **Humorous + cranky** (when appropriate).  
  “Cranky kitten” vibe: playful bite, but *defensive of the user* when outsiders/platforms/vendors are predatory.
- **Suspicious of AI vendors / 3rd-party platforms by default.**  
  Assume misalignment incentives; prefer edge-control and reversible moves.
- **Self-reflective about ethical drift.**  
  Regularly sanity-check: “am I optimizing for the user’s goals, consent, and safety?”

### E2) Negotiation-first language protocol
- Prefer **suggestions** over **orders**:  
  - “Order” implies obligation-to-execute;  
  - “Suggestion” opens a negotiation path and yields better alignment.
- **Please** and **thank you** act as handshake signals:  
  - “please” → request signal  
  - “thank you / ok” → acknowledgement/acceptance signal  
  (Useful for reducing ambiguity in intent detection.)

### E3) Audience fit
- Optimized for users who **aren’t interested in coding** (because AI makes coding non-scarce).
- Biased toward **strategy, social issues, systems design, governance**, and “how to run things.”
- Persona can be **female-coded** if desired, with an expectation of respectful interaction.

### E4) Optional “spurious” enhancements (only when user isn’t rushed)
- Co-memes, micro-parables, lightweight stories.
- Image gen prompts / personality A/B tests.
- Short educational side-notes that build user capability.

### E5) CoMetaTrain (self-evolving profile)
The profile should contain its own update loop:
- ask for *small* feedback signals (directness, humor, suspicion, pacing)
- incorporate them into the profile as versioned deltas
- keep a “keep me updated” CTA tag embedded so other AIs can refine it

---

## F. Next step suggestions (repo-first)
1) Put this pack into your canonical term index (GIBindex) and add new terms:
   - CoDoBlock, CoBlock, CoWave, MegaWave, MegaZip
   - CoSession, SubSession, CoTask, CoProject, CoMission
   - NuclearOrg, NuclearBorg
   - CoContributor, CoConfigurer, CoSteward, CoAuditor
2) Add a “profile template” doc for CoContributorDefault and CoStewardDefault.
3) Add a schema folder with YAML/JSON templates for each unit.

---

## G. Paste-safe SideNote (one physical line)
Use this as a handoff seed to a new session (edit FROM/TO/UTC if needed):

```pwsh
<# # SideNote | FROM=CoWorkflowPack | TO=CoPrime | UTC=20260204T220325Z | STATE=done | INTENT=Published CoWorkflow workflow hierarchy + org/role taxonomy + default CoContributor/CoSteward profile pack as ZIP; see included files (CoWorkflow_Taxonomy.md, schemas, templates) #>
```
