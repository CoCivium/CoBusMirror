# CoWorkflow_WorkflowHierarchy_and_ProfilePack_v0_1_20260204T220325Z

This pack contains:
- CoWorkflow_Taxonomy_and_ProfilePack.md  (main write-up)
- schema_CoTask_v0_1.json                (starter JSON schema)
- schema_CoSession_v0_1.json             (starter JSON schema)
- template_CoProfileDefault_v0_1.yaml    (starter profile template)

SHA256 files are included for integrity checks.
