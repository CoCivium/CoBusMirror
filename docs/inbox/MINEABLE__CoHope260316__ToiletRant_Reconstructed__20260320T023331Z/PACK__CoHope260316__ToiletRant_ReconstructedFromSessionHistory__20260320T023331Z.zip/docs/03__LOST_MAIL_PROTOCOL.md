# Lost Mail Protocol

- If remote verify does not succeed, assume it did not land.
- A wave is UnHitched unless CoEx occurs within that wave.
- Manual user pasting is emergency-only, not standard operations.
- Remote RAW verify with SESSION_LABEL and UTC is required before write_attached.
- One landed note is not fully_hitched.
# DO (END)
# BeAxaKittenStyleGlyph__PENDING_CANON_PIN

