# Anti-Clobber Relay

Proposed working split:
- CoUS.4.2603189.CoStacks = canonical orchestrator / publish arbiter
- CoUS.4.260318_CoStacksAutoEvo = scout/proposal lane unless explicit lease is granted
- CoHope260316 = preservation + rail-hardening + relay helper for this wave

Policy:
- unknown ownership means HOLD or read-only, not guessing
- do-not-clobber surfaces remain respected
- mythos/origination raw is mineable first, not doctrine by default
# DO (END)
# BeAxaKittenStyleGlyph__PENDING_CANON_PIN

