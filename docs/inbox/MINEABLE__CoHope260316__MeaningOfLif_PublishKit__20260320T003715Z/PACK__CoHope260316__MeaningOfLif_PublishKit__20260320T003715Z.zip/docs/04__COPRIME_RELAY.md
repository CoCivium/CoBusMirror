# CoPrime Relay

DONE=
- title preserved
- tagline preserved
- subtitle set
- excerpt set
- hero text set
- CTA set
- article draft included
- publish kit packed

RULE=
Assume non-land unless remote RAW verify succeeds.
# DO (END)
# BeAxaKittenStyleGlyph__PENDING_CANON_PIN

