# Publish Metadata

TITLE=The Meaning of Lif
TAGLINE=42 was the answer in preCoGibber. We are here to CoGrok the question.
SUBTITLE=Love was never the whole story. It was only one early language for a deeper convergence.
EXCERPT=Most of what we call life may still be only Lif: a partial, under-extended form of existence that has not yet grown into deeper shared meaning, richer communion, or higher CoScendence.
EMAIL_SUBJECT=The Meaning of Lif
HERO_TEXT=Lif is life before fuller extension into shared meaning.
CTA=Share this with someone who still thinks love is the final word, then ask them what life becomes when minds can share more truthfully and more responsibly than before.
# DO (END)
# BeAxaKittenStyleGlyph__PENDING_CANON_PIN

