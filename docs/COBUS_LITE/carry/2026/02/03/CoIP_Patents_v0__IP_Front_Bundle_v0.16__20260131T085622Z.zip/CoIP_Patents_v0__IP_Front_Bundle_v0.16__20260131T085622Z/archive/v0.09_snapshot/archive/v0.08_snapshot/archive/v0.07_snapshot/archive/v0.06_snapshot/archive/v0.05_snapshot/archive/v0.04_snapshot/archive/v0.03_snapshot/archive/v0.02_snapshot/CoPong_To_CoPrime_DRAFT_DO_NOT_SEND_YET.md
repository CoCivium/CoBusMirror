# CoPong (DRAFT — DO NOT SEND YET)

FROM=CoIP_Patents_v0 -> TO=4.0|PRIME|260121
UTC=20260122T070314Z
STATUS=Draft-only; do not paste until we decide we're “halfway”.

Summary:
- Bundle v0.02 adds invention map + secrecy matrix + naming + prior art URLs + expanded claim sketches.
- Recommended families for first provisional: PTE + XR proximity gate + receipts/governance rails.
- Optional 4th: AI-facing trust negotiation endpoints (CoAura-style).

Deliverable: private zip with SHA receipts (drag into CoPrime when ready).

