# Counsel_DataRoom_Structure_v0.1

> A safe structure for sharing with counsel without leaking private core details.

## Recommended folders (logical, not a path requirement)
1) 00_README
- project summary + redaction rules + contacts

2) 10_Invention_Briefs_PUBLIC_SAFE
- invention map
- family briefs
- candidate inventions
- draft claims set
- drawings list
- provisional skeletons

3) 20_Prior_Art
- prior art anchors log
- search plan + query pack

4) 30_Receipts_and_Verification
- bundle receipt + SHA256SUMS
- verifier scripts (PS/Bash)

5) 90_LAWYER_ONLY (created only if/when needed)
- narrowly scoped redacted excerpts (approved)
- jurisdiction strategy notes

## Access rules
- Public-safe folders can be shared broadly to counsel team.
- Lawyer-only folder is read-only and shared to named individuals only.
- No code or internal logs unless counsel requests and we pre-redact.
