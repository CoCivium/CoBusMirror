# Invention_Map_v0.1

**Session:** CoIP_Patents_v0  
**UTC build:** 20260122T070314Z  
**Scope:** 4 boxes max. Each box: problem, solution, novelty, public vs trade-secret.

---

## Family A — Portable Trust Envelope (PTE) for cross-platform reputational signals
**Problem:** People need portable trust/reputation signals across platforms (e.g., XR worlds) without doxxing.
Platforms need to consume signals without becoming identity brokers.

**Solution (summary):** A “trust envelope” that bundles:
- verifiable claims (VC/credential objects) + issuer attestations,
- a **consent policy** that governs what is revealable, to whom, in what context,
- selective disclosure presentation mechanisms (SD-JWT / BBS-style proof variants),
- transport via standard presentation flows (e.g., OpenID4VP).

**Novelty angle (what to sell):**
- Standards define credential formats and presentations; PTE focuses on **portable reputation** with explicit
  consent policy + anti-doxxing defaults, and multi-issuer bundling as a coherent envelope with
“minimum
  reveal” behavior.

**Public vs trade-secret boundary:**
- Public: envelope format, policy language primitives, presentation flow variants, anti-doxxing defaults.
- Trade-secret: any private scoring/selection/verification core (private core/private core); thresholds/weights; abuse models.

**Evidence-of-use:** visible in credential/presentation payloads, policy metadata, and the verifier request/response flow.

---

## Family B — Proximity / Context-Gated Trust Reveal for XR
**Problem:** Trust signals should not be revealed indiscriminately; context matters (nearby player, shared session,
physical event, controlled venue). XR has a strong need for “only reveal when it makes sense.”

**Solution (summary):** A method that gates *which* trust attributes can be disclosed based on:
- proximity evidence (BLE/NFC beacons, local session handshake),
- session context evidence (XR room/session token, time window, device attestation optional),
- policy evaluation that selects a minimal disclosure set.

**Novelty angle:**
- Combine selective disclosure with **context evidence** so that trust reveal becomes a safe “proximity affordance”
  for XR: you get more signal only when you are appropriately close / in-session / consented.

**Public vs trade-secret boundary:**
- Public: evidence token formats; gating rules at a high level; example contexts; fallbacks.
- Trade-secret: risk scoring thresholds; adversarial heuristics; detection tuning.

**Evidence-of-use:** visible in the presence of context evidence tokens and conditional disclosure behavior.

---

## Family C — Governance & Provenance Rails for AI-assisted Ops (Receipts + Canonical Roots + Pointer Ledger)
**Problem:** AI-assisted workflows drift. Files, scripts, and “truth paths” fork silently. Auditing becomes impossible.

**Solution (summary):** A governance layer using:
- a canonical “root truth” file (canonical roots / canonical paths),
- an append-only pointer ledger (full URLs only) to navigate state reproducibly,
- deterministic receipts (manifest + hashes + verification scripts) that detect regressions and drift.

**Novelty angle:**
- Apply supply-chain provenance patterns (SLSA / in-toto style) to **human+AI operational state**:
  pointer-only coordination + deterministic receipts => reproducible orchestration across
sessions/tools.

**Public vs trade-secret boundary:**
- Public: receipt formats; pointer registry schema; canonical-root enforcement patterns.
- Trade-secret: heuristics about what gets logged/redacted; internal risk/quality models.

**Evidence-of-use:** receipts, manifests, hashes, and verification scripts exist as artifacts.

---

## Family D — AI-facing Trust Negotiation Endpoints (CoAura-style)
**Problem:** AI agents need structured, consent-aware ways to request trust proofs and negotiate access without
screen-scraping human UIs.

**Solution (summary):** A machine-readable endpoint surface that:
- advertises allowed trust requests (“capabilities”),
- issues a structured challenge/request (claims + context),
- mediates consent (wallet/browser/agent),
- receives a minimal proof/presentation (VC/SD-JWT/BBS),
- returns a verifiable receipt of the interaction.

**Novelty angle:**
- Combine digital credential request semantics with AI-agent interfaces (machine-readable surfaces, negotiation,
  and receipts) to make trust portable into agentic interactions.

**Public vs trade-secret boundary:**
- Public: endpoint schema; negotiation flow; receipts; consent mediation.
- Trade-secret: ranking/interpretation cores; partner routing; internal decision policies.

**Evidence-of-use:** endpoint schemas and request/response flows are externally observable.

