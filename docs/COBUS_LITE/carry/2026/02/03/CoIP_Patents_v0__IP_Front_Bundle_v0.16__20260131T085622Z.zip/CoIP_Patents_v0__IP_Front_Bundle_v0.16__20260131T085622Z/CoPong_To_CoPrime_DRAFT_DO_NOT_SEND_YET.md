
# CoPong | FROM=CoIP_Patents_v0 -> TO=4.0|PRIME|260121 | UTC=20260122T071916Z | STATUS=DRAFT_DO_NOT_SEND

## Contents ready for handoff (private zip)
- IP_Front_Strategy_v0.3
- Candidate_Inventions_v0.3 (10 items, claim sketches + secrecy boundaries)
- PriorArt_Log_v0.3 (core 30 + appendix extras with URLs)
- Provisional_Outline_PTE_v0.3 + figure list
- Secrecy_Matrix_v0.2
- Added: invention family briefs, defensive publication playbook, picket fence sequencing, counsel handoff checklist, claim glossary
- Added: archive snapshot of v0.02 to prevent erosion

## Notes (pointer-safe)
- Bundle stays **off** CoBus by default; CoPrime decides what (if anything) becomes public.
- No private core/private core contents included.

## NEXT<=5 (if you want further evolution)
1) Add “closest prior art” 3–5 per family with 1-paragraph differentiation each (patent-search style)
2) Add 1-page investor “IP front” narrative (public safe)
3) Add “figure pack” descriptions (text-only) for counsel drafting
4) Add a lightweight “invention disclosure form” per family
5) Do a first pass Google Patents/Lens.org prior-art quick scan per family (URLs only)
