# CHANGELOG

## v0.04 — 20260122T073037Z
- Prior art upgraded and URL-validated (RFC 9901 SD-JWT, MCP spec, Digital Credentials API, OpenID4VP final, multiple patent anchors).
- Added: Bundle_Index, Investor one-pager, Invention disclosure template.
- Updated: IP_Front_Strategy, PriorArt_Log, SearchPlan, Provisional outline, Candidate inventions, Secrecy matrix, invention map/briefs.
- Archive: added v0.03 snapshot folder.


# Changelog — v0.03 (from v0.02)

## Added
- Invention family 1-page briefs (A–D)
- Defensive publication playbook (what, where, when; self-sabotage avoidance)
- Filing sequencing / “picket fence” bundle structure
- Claim term glossary (to keep claim language consistent across drafts)
- Counsel handoff checklist (what to provide, what to avoid writing down)
- Frozen snapshot of v0.02 under `archive/`

## Expanded / improved
- Strategy doc: clearer patent-vs-secret-vs-defensive-publish matrix; investor-friendly “IP front” narrative
- Candidate inventions: expanded to 10 candidates; strengthened claim sketches and disclosure boundaries
- Prior art log: clarified “core 30” vs appendix; added concrete standards URLs (W3C/IETF/OpenID/MCP/SLSA/etc)
- Search plan: added query set and “closest prior art” shortlists per family
- Provisional outline: added suggested figure list, example flows, and embodiment scaffolding

## Guardrails reaffirmed
- No speculation on private core/private core contents.
- No server paths, credentials, partner names, or vault-only details.

