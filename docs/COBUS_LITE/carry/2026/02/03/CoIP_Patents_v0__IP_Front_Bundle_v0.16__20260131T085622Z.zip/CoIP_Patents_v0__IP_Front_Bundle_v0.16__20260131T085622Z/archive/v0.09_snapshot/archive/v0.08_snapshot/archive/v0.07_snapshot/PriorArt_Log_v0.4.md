# PriorArt_Log_v0.4

> **Purpose:** pragmatic anchor list (standards, papers, patents, and products) to orient counsel and guide searches.
> This is **not** an exhaustive novelty opinion.

## A) Standards / specs (closest baseline)
1. W3C Verifiable Credentials Data Model v2.0 — https://www.w3.org/TR/vc-data-model-2.0/
2. W3C Verifiable Credentials Overview (roadmap) — https://www.w3.org/TR/vc-overview/
3. W3C DID Core v1.0 — https://www.w3.org/TR/did-core/
4. W3C VC Data Integrity — https://w3c.github.io/vc-data-integrity/  (also TR landing exists)
5. W3C VC JOSE/COSE — https://www.w3.org/TR/vc-jose-cose/
6. RFC 9901 (SD-JWT) Selective Disclosure for JWTs — https://www.rfc-editor.org/rfc/rfc9901.html
7. IETF draft (SD-JWT VC) — https://datatracker.ietf.org/doc/draft-ietf-oauth-sd-jwt-vc/
8. OpenID4VP 1.0 (Final) — https://openid.net/specs/openid-4-verifiable-presentations-1_0-final.html
9. OpenID4VCI 1.0 — https://openid.net/specs/openid-4-verifiable-credential-issuance-1_0.html
10. OpenID4VP over BLE (offline) — https://openid.net/specs/openid-4-verifiable-presentations-over-ble-1_0.html
11. W3C Digital Credentials API (DC API) — https://www.w3.org/TR/digital-credentials/
12. W3C blog on DC API publication — https://www.w3.org/blog/2025/w3c-digital-credentials-api-publication-the-next-step-to-privacy-preserving-identities-on-the-web/
13. Chrome “Digital Credentials API” origin trial background — https://developer.chrome.com/blog/digital-credentials-api-origin-trial
14. DIF Presentation Exchange (overview) — https://identity.foundation/presentation-exchange/
15. DIF Presentation Exchange v2.1.1 — https://identity.foundation/presentation-exchange/spec/v2.1.1/
16. DIDComm Messaging — https://identity.foundation/didcomm-messaging/spec/

## B) Provenance / supply-chain integrity (baseline for receipts/manifests)
17. RFC 9162 (COSE/SCITT-related provenance patterns) — https://www.rfc-editor.org/rfc/rfc9162.html
18. The Update Framework (TUF) — https://theupdateframework.io/
19. Sigstore — https://www.sigstore.dev/
20. in-toto — https://in-toto.io/
21. SLSA — https://slsa.dev/
22. Reproducible Builds — https://reproducible-builds.org/
23. SPDX — https://spdx.github.io/spdx-spec/
24. CycloneDX — https://cyclonedx.org/specification/overview/
25. C2PA Spec 2.3 — https://c2pa.org/specifications/specifications/2.3/specs/C2PA_Specification.html

## C) AI-facing interfaces / machine-readable negotiation (adjacent)
26. Model Context Protocol (MCP) Spec — https://modelcontextprotocol.io/specification/2025-11-25
27. MCP versioning — https://modelcontextprotocol.io/specification/versioning
28. llms.txt overview — https://llmstxt.org/
29. llms-txt-hub — https://github.com/thedaviddias/llms-txt-hub

## E) Products / Platforms (baseline ecosystem)
- Microsoft Entra Verified ID (managed VC service): product page + docs.  
- Trinsic (platform / acceptance network): platform + site.  
- SpruceID (wallet/verifier ecosystem): learn + products pages.  
- MATTR (credential verification / OpenID4VP): capabilities page.  

## D) Patent anchors (closest risk zones)
30. US20160295349A1 Proximity based authentication using bluetooth — https://patents.google.com/patent/US20160295349A1/en
31. WO2019139630A1 Proximity-based trust — https://patents.google.com/patent/WO2019139630A1/en
32. US20230388287A1 Decentralized attribute-based access control (uses VCs + policies) — https://patents.google.com/patent/US20230388287A1/en
33. US20230164143A1 Systems/methods for providing verifiable credentials — https://patents.google.com/patent/US20230164143A1/en
34. US20190370487A1 Consent-driven privacy disclosure control processing — https://patents.google.com/patent/US20190370487A1/en
35. US12445288 Multi-issuer anonymous credentials (ZK proofs, one-out-of-many) — https://patents.google.com/patent/US12445288/en
36. US10628389B2 Data provenance verification for existing systems — https://patents.google.com/patent/US10628389B2/en
37. US11120005 Workflow provenance tracking at runtime — https://patents.justia.com/patent/11120005
38. US8010460B2 Reputation system in online communities — https://patents.google.com/patent/US8010460B2/en
39. US8150842B2 Reputation of an author of online content — https://patents.google.com/patent/US8150842B2/en

## E) Defensive publication channels (deterrence)
40. IP.com PAD intro — https://kb.ip.com/pad/knowledge-base/introduction-to-defensive-publishing-and-the-prior-art-database-pad/
41. Wired (TDCommons context) — https://www.wired.com/story/google-tdcommons-dpub-patents-prior-art

---

### Notes for counsel
- The novelty angle is often in **system composition**: policy-bound selective disclosure + context/proximity gating + provenance receipts + portability.
- Keep “private scoring/selection/verification core” (private core/private core) outside of disclosures.
