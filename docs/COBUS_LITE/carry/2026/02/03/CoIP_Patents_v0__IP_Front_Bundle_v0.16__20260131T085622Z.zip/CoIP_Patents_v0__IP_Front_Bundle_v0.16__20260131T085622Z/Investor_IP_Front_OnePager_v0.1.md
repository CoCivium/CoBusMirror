# Investor_IP_Front_OnePager_v0.1

> Public-safe, non-enabling. This is an “IP protection front” summary to establish credibility and deterrence.

## What we’re protecting (in plain English)
CoCivium is building a **portable trust** layer: opt-in reputation/consent signals that users can carry across platforms (starting with XR/gaming communities) **without doxxing**.

## Our IP posture (deliberately pragmatic)
We expect many repos and surfaces to be public. So we split IP into three lanes:

1) **Picket-fence provisionals (fast, narrow, numerous)**  
   We file small provisionals around the **interfaces & governance layer** (portable trust envelopes, consent policy capsules, context/proximity-gated presentation, auditable workflow receipts).

2) **Trade-secret core (keep narrow)**  
   We keep a limited “private scoring/selection/verification core” (internal label: private core/private core) as a trade secret. The IP-front patents do **not** depend on disclosing its parameters.

3) **Defensive publication (deterrence, not dominance)**  
   Non-core implementation patterns can be defensively published (e.g., deterministic receipts/manifests, pointer registries) to block copycats and reduce patent risk.

## 3–4 invention families we lead with
A) **Portable Trust Envelope**: policy-bound selective disclosure VC presentation with consent gates and anti-doxxing defaults.  
B) **XR Proximity/Context-Gated Trust Reveal**: local context signals (BLE/QR/session context) trigger stepped disclosure.  
C) **AI-Facing Trust Negotiation Endpoints (CoAura)**: machine-readable web surfaces for consent-aware negotiation, not human UIs.  
D) **Governance & Provenance Layer for AI-assisted ops**: canonical roots + pointer ledgers + deterministic receipts prevent drift and support reproducible audits.

## Why this can be novel even in a crowded VC/DID space
Standards define components (VCs, DIDs, selective disclosure), but **product defensibility** can come from how the system combines:
- consent policy capsule + selective disclosure
- context/proximity gating + stepped reveal
- provenance receipts + reproducible orchestration
- portability across platforms and vendors

## What this gives investors
- A credible “IP front” for diligence and deterrence
- A clear trade-secret boundary
- A path to eventual openness once brand trust is established
