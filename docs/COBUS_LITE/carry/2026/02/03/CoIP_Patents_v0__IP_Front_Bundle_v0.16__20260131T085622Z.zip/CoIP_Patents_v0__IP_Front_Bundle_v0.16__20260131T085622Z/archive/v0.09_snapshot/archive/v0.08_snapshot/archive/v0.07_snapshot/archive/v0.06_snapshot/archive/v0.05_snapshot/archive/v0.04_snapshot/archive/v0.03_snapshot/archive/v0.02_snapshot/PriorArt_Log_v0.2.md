# PriorArt_Log_v0.2

**Session:** CoIP_Patents_v0  
**UTC build:** 20260122T070314Z  
**Note:** This is an initial anchor list (not exhaustive). It is intended to be counsel-friendly seed material.

---

## A) Standards / Specs (identity, credentials, selective disclosure)
1. W3C Verifiable Credentials Data Model v2.0 — https://www.w3.org/TR/vc-data-model-2.0/  
   *Baseline for VC ecosystem and exchange roles.*

2. W3C Decentralized Identifiers (DID) Core v1.0 — https://www.w3.org/TR/did-core/  
   *Baseline DID syntax + DID documents.*

3. W3C Verifiable Credential Data Integrity 1.0 — https://www.w3.org/TR/vc-data-integrity/  
   *Baseline for securing VCs with Data Integrity proofs.*

4. IETF RFC 9901: SD-JWT — https://www.rfc-editor.org/rfc/rfc9901.html  
   *Selective disclosure for JWT-based credentials.*

5. OpenID for Verifiable Presentations 1.0 (final) — https://openid.net/specs/openid-4-verifiable-presentations-1_0-final.html  
   *Credential request and presentation protocol.*

6. OpenID for Verifiable Credential Issuance 1.0 (final) — https://openid.net/specs/openid-4-verifiable-credential-issuance-1_0-final.html  
   *Credential issuance protocol.*

7. W3C Digital Credentials API — https://www.w3.org/TR/digital-credentials/  
   *Browser/user-agent mediated credential request/issuance.*

8. IETF CFRG draft: BBS Signatures (selective disclosure proofs) — https://www.ietf.org/archive/id/draft-irtf-cfrg-bbs-signatures-05.html  
   *Selective disclosure using BBS signatures.*

9. ISO/IEC 18013-7 (mDL add-on functions) landing page — https://www.iso.org/standard/82772.html  
   *Mobile documents and over-the-internet presentation context.*

10. EU EUDI Wallet Architecture and Reference Framework (ARF) — https://digital-
strategy.ec.europa.eu/en/library/european-digital-identity-wallet-architecture-and-reference-
framework
   *Reference architecture for interoperable wallet solutions.*

11. Microsoft Entra Verified ID overview — https://learn.microsoft.com/en-us/entra/verified-
id/decentralized-identifier-overview
   *Commercial VC implementation baseline and terminology.*

---

## B) AI-facing endpoints / machine-readable surfaces
12. llms.txt proposal — https://llmstxt.org/
   *Emerging pattern: machine-readable website guidance.*

13. Model Context Protocol (MCP) specification —
https://modelcontextprotocol.io/specification/2025-11-25
   *Agent-to-tool/data integration protocol (potential embodiment).*

14. Anthropic MCP announcement (context) — https://www.anthropic.com/news/model-context-protocol
   *Background and intent for MCP as open protocol.*

---

## C) Supply-chain provenance / tamper-evident logs (for “receipts rails” family)
15. SLSA provenance spec (example) — https://slsa.dev/spec/v0.2/provenance
   *Attestation model for build provenance.*

16. Reproducible Builds project — https://reproducible-builds.org/
   *Concept baseline for deterministic output from source.*

17. RFC 6962 Certificate Transparency — https://www.rfc-editor.org/rfc/rfc6962.html
   *Append-only Merkle log concept baseline.*

18. OWASP CycloneDX SBOM standard — https://cyclonedx.org/
   *Inventory baseline for software components.*

---

## D) Gaming / reputation comparables (market anchors)
19. Steam / Counter-Strike 2 Trust Factor help page —
https://help.steampowered.com/en/faqs/view/00EF-D679-C76A-C185
   *Example of platform-specific trust scoring (opaque by design).*

---

## E) Academic / technical papers (privacy-preserving credentials)
20. Camenisch et al. “Design and Implementation of the idemix Anonymous Credential System” (2002 PDF
mirror) — https://www.csl.mtu.edu/cs6461/www/Reading/Camenisch02.pdf
   *Anonymous credentials baseline.*

21. Microsoft Research U-Prove project page — https://www.microsoft.com/en-
us/research/project/u-prove/
   *Privacy-preserving credential token system.*

22. U-Prove Cryptographic Specification v1.1 (PDF) — https://www.microsoft.com/en-us/research/wp-
content/uploads/2016/02/U-Prove20Cryptographic20Specification20V1.1.pdf
   *Technical spec baseline.*

23. Google Research: “Selective Disclosure Credential Sets” (PDF) —
https://research.google.com/pubs/archive/32874.pdf
   *Selective disclosure sets; anti-pooling considerations.*

---

## F) Patents (selected anchors; expand during counsel scan)
24. US20170019412A1 — Social and proximity based access control for mobile devices —
https://patents.google.com/patent/US20170019412A1/en
   *Context + proximity cues for access control (baseline for family B).*

25. US20160295349A1 — Proximity based authentication using Bluetooth —
https://patents.google.com/patent/US20160295349A1/en
   *BLE-based proximity auth (baseline for family B).*

26. US11107071 — Validating online access to secure device functionality (NFC proximity) —
https://patents.google.com/patent/US11107071
   *NFC proximity access validation.*

27. US10217151B1 — Systems and methods for proximity based communication (BLE beacon) —
https://patents.google.com/patent/US10217151B1/en
   *BLE beacon proximity comms baseline.*

28. US20230164143A1 — Systems and methods for providing verifiable credentials —
https://patents.google.com/patent/US20230164143A1/en
   *Subset attribute presentations for VC-like objects (baseline for family A).*

29. EP3726412B1 — Selectively verifying personal data (consent + selective verification) —
https://patents.google.com/patent/EP3726412B1/en
   *Selective verification + consent handling.*

30. US20170364552A1 — Ensuring data integrity of executed transactions (hash + receipt) —
https://patents.google.com/patent/US20170364552A1/en
   *Receipt with hash anchored concept (baseline for family C).*

31. US9130915 — Preference editor to facilitate privacy controls over user identities —
https://patents.google.com/patent/US9130915
   *Consent/preferences UI baseline.*

---

## Notes for next iteration
- Add: in-toto, TUF, Sigstore primary sources (not just summaries).
- Add: W3C VC Data Integrity cryptosuites (eddsa/jcs, etc.) + any published BBS cryptosuite specs.
- Add: competitive wallets (SpruceID, MATTR, etc.) only if counsel wants product comparables.
- Expand patent list to 15–25 patents after an actual keyword/CPC sweep.

