# Defensive_Publication_Playbook_v0.1

> Goal: after provisional filing, publish non-secret variants to prevent others from patenting obvious derivatives.

## When
- Only after you’ve filed provisionals that cover the core surfaces you care about.
- Coordinate timing with counsel (jurisdiction differences).

## What to publish (safe)
- interface patterns, schemas, flows
- non-secret embodiments/variants
- example use cases and diagrams
- receipts/provenance patterns that you are willing to make public

## What NOT to publish
- anything that reveals the private core mechanics (scoring thresholds/weights, detection heuristics)
- partner integration details, secrets, internal identifiers

## Venues (examples; confirm with counsel)
- technical blog post with time-stamped archive
- preprint / technical report with DOI-like permanence
- defensive publication services (counsel will recommend)
- standards-track contributions (when appropriate)

## Publication checklist
- confirm provisional filed
- confirm trade secret boundary language intact
- include multiple variants so publication is “enabling” and blocks derivative patents
