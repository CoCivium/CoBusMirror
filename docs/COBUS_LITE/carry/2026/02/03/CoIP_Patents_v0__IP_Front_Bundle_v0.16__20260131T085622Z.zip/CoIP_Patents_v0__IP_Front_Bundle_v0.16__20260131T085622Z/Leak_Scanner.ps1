# Leak_Scanner.ps1
# Scans extracted bundle for disallowed substrings (LeakScan_Patterns_v0.1.txt).
# Excludes the patterns file and the scanner scripts themselves to avoid self-hits.
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

$root = (Get-Location).Path
$patFile = Join-Path $root "LeakScan_Patterns_v0.1.txt"
if(!(Test-Path -LiteralPath $patFile)){ throw "Missing LeakScan_Patterns_v0.1.txt" }

$patterns = Get-Content -LiteralPath $patFile -Encoding UTF8 | Where-Object { $_ -and -not $_.StartsWith("#") } | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ }

$exclude = @(
  (Join-Path $root "LeakScan_Patterns_v0.1.txt"),
  (Join-Path $root "Leak_Scanner.ps1"),
  (Join-Path $root "Leak_Scanner.sh"),
  (Join-Path $root "Verify_Bundle.ps1"),
  (Join-Path $root "Verify_Bundle.sh")
) | ForEach-Object { $_.ToLower() }

$files = Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object {
  $_.FullName -notmatch "\\archive\\" -and
  ($_.Extension -in @(".md",".txt",".json",".yml",".yaml",".ps1",".sh",".csv"))
} | Where-Object { $exclude -notcontains $_.FullName.ToLower() }

$hits = @()
foreach($f in $files){
  $low = (Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8).ToLower()
  foreach($p in $patterns){
    if($low.Contains($p)){
      $hits += [pscustomobject]@{ file=$f.FullName.Substring($root.Length+1); pattern=$p }
    }
  }
}

if($hits.Count -gt 0){
  Write-Host "LEAK SCAN FAIL:" -ForegroundColor Red
  $hits | Sort-Object file,pattern | Format-Table -AutoSize
  throw "Leak scan failed: remove/redact flagged content."
}

Write-Host "LEAK SCAN PASS"
