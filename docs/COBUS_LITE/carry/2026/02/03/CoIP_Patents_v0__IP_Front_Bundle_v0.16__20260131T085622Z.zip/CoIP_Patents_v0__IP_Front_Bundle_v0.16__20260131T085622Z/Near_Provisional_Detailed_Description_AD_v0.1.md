# Near_Provisional_Detailed_Description_AD_v0.1

> Near-provisional Detailed Description blocks for Families A and D (public-safe).
> Avoid private-core mechanics; describe interfaces, flows, and variants broadly.

## Family A — Portable Trust Envelope + Consent Policy Capsule
**Fig A1 (System):** issuer, holder device, verifier; envelope contains verifiable claims + policy capsule.  
**Fig A2 (Issuance):** claims issued + holder binding; policy capsule issuer-provided and/or holder-augmented.  
**Fig A3 (Minimization plan):** presentation request -> constraints evaluation -> minimal subset selection.  
**Fig A4 (Step-up):** explicit re-consent before additional disclosure; contextual gating optional.  
**Fig A5 (Receipts):** deterministic receipt binds hashes of request/plan/proof; local or append-only storage variants.

**Embodiments:** tier tables; retention limits; verifier classes; expiry/revocation pointers; SD-JWT and OpenID4VP variants; multi-envelope packing; refusal receipt variants.

## Family D — Governance/Provenance for AI-assisted Ops
**Fig D1 (Overview):** canonical roots registry + pointer ledger + execution environment.  
**Fig D2 (Receipt):** hashes of inputs/outputs/pointers; tool versions and environment fingerprints optional.  
**Fig D3 (Gate):** fail-closed on mismatch; generate refusal receipt.  
**Fig D4 (Graph):** assemble receipts into provenance graph; optional transparency log inclusion proofs.

**Embodiments:** signed/rotating roots; append-only ledgers; transparency log compatibility; multi-session labels and exports.
