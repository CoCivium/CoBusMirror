# Provisional_Draft_Text_C_CoAura_v0.1

> Draft narrative blocks for counsel to reuse (Family C). Avoid ranking/interpretation internals.

## Background (draft)
Automated agents increasingly access online resources on behalf of users. Existing authorization patterns often do not express “what proofs are acceptable” in a machine-readable way and may not provide explicit user consent semantics. A standardized negotiation surface can reduce bespoke integrations and enforce minimal disclosure.

## Summary (draft)
In one aspect, a server exposes a machine-readable endpoint publishing acceptable proof requirements and claim categories for accessing a resource. An automated agent requests a minimal proof plan. The server responds with a plan specifying required claim categories and acceptable proof formats. A holder provides explicit consent through a mediated user experience (e.g., user agent mediation). The holder presents a verifiable proof satisfying the plan, and access is granted upon verification. In some embodiments, the negotiation supports step-up requests and deterministic receipts binding the negotiation and presentation artifacts.

## Embodiments (draft)
- Web discovery variant (well-known endpoint + /llms.txt hints).
- Tool-schema variant aligned with agent tool protocols (e.g., JSON-RPC tool schema ecosystems).
- Digital Credentials API mediated consent variant.
- Multi-round step-up negotiation based on risk policy (without disclosing internals).
