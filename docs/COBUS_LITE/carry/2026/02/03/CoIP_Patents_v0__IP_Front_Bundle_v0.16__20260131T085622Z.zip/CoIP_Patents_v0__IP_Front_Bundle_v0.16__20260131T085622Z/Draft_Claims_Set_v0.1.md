# Draft_Claims_Set_v0.1

> Draft-style claims (non-final). Accelerant for counsel. Avoid trade-secret mechanics.

## A) Portable Trust Envelope + Consent Policy Capsule
### A1 (method)
A computer-implemented method comprising:
generating a portable trust envelope comprising verifiable claims and a machine-readable consent policy capsule;
receiving a verifier presentation request specifying required claim categories or proof requirements;
computing, based on the consent policy capsule, a presentation plan that identifies a subset of the verifiable claims sufficient to satisfy the request while minimizing disclosure beyond the required categories; and
presenting a proof derived from the subset in accordance with the plan, wherein disclosure of additional claims requires an explicit holder consent input.

### A2 (system)
A system comprising one or more processors and memory storing instructions that cause performance of A1.

### Dependents (examples)
- selective disclosure via SD-JWT
- holder key binding
- policy capsule defines tiers + step-up conditions
- deterministic receipt generation (hashes of request and proof)

## B) XR Proximity/Context-Gated Trust Reveal
### B1 (method)
receiving a proximity/context trigger for an XR session; validating the trigger locally; selecting a disclosure tier based on the trigger and policy capsule; presenting a tier proof; and requiring re-consent for higher-tier proof.

## C) AI-facing Trust Negotiation Endpoint
### C1 (method)
exposing a machine-readable endpoint publishing acceptable proof requirements; returning a minimal proof plan; receiving explicit consent; receiving a presentation proof satisfying the plan; and granting access upon verification.

## D) Governance/Provenance Layer for AI-assisted Ops
### D1 (method)
resolving pointers through a canonical roots registry; generating a deterministic receipt binding inputs/outputs/pointers; and gating subsequent execution on receipt verification.
