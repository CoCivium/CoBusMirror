# Provisional_Skeletons_BCD_v0.1

> Companion provisional scaffolding for Families B/C/D.

## B) XR Proximity/Context-Gated Trust Reveal
- Abstract: proximity/context triggers gate stepped selective disclosures with explicit consent.
- Summary: BLE/QR/session triggers; local validation; tiered step-up; ephemeral bindings.
- Figures: B1–B3.
- Embodiments: BLE variant, QR variant, session-token variant; refusal receipts.

## C) AI-facing Trust Negotiation Endpoint
- Abstract: machine-readable endpoint negotiates minimal proof plan, then executes consent-mediated presentation.
- Summary: publish requirements; agent requests plan; holder consents; proof verified; optional step-up.
- Figures: C1–C3.
- Embodiments: MCP-like tool schema variant; llms.txt discovery; DC API mediated consent.

## D) Governance/Provenance Layer for AI-assisted Ops
- Abstract: deterministic receipts + canonical registries prevent drift and enable reproducible audit.
- Summary: canonical roots; pointer ledger; receipt generation + verification gate; fail-closed.
- Figures: D1–D4.
- Embodiments: signed roots; append-only ledger; transparency log; multi-session labeling.
