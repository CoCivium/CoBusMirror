
# Invention_Map_v0.2 — 4 invention families (A–D)

## A) Portable Trust Envelope (PTE)
- **Problem:** users have reputations/consents scattered across platforms; moving signals risks doxxing and misuse.
- **Solution:** a portable “trust envelope” that packages **verifiable claims** + **consent policy** + **selective disclosure** into a presentation that any platform can verify.
- **Novelty angle:** combine VC/DID/OpenID4VC flows with **policy-carrying envelopes** and default anti-doxxing UX.
- **Public vs private:** envelope format, consent gates, verification flows are public; scoring/selection core is private.

## B) XR Proximity / Context-gated Trust Reveal
- **Problem:** in XR, trust is needed *in the moment*; revealing too much leaks identity or enables stalking.
- **Solution:** context signals (proximity, session, venue, role, time) gate *what* trust data is revealed and at what granularity.
- **Novelty angle:** “trust reveal” is **graduated**, **consent-aware**, **anti-correlation** by design.
- **Public vs private:** gating semantics and flows public; thresholds and detection heuristics private.

## C) CoAura — AI-facing trust negotiation endpoints
- **Problem:** AI agents need machine-readable trust negotiation, not human pages and ad-hoc APIs.
- **Solution:** an AI-facing endpoint surface that supports request/offer/negotiate patterns with explicit consent semantics and portable trust tokens.
- **Novelty angle:** machine-readable negotiation + receipts + consent policy, aligned to emerging protocols (e.g., MCP/llms.txt patterns).
- **Public vs private:** endpoint schemas public; interpretation/ranking core private.

## D) Ops Governance + Provenance Substrate (Receipts)
- **Problem:** distributed AI/human work drifts (forked paths, silent edits, unverifiable bundles).
- **Solution:** canonical roots + pointer ledger + deterministic receipts/manifests enable reproducible, auditable operations.
- **Novelty angle:** unify “provenance” primitives with **session-safe orchestration** and redaction discipline.
- **Public vs private:** primitives public; risk models and redaction heuristics private.
