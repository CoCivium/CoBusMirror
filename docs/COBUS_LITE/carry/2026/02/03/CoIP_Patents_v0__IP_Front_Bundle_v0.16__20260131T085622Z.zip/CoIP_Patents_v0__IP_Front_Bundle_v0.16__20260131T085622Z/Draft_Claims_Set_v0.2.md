# Draft_Claims_Set_v0.2

> Refined draft claims for counsel. Still non-final; ensure antecedent basis and broad-to-narrow fallback.
> Trade secret boundary: inner “private scoring/selection/verification core” (no mechanics).

---

## Family A — Portable Trust Envelope + Consent Policy Capsule

### A1 (Independent — method)
A computer-implemented method comprising:
(a) storing, by a holder device, a portable trust envelope comprising (i) a set of verifiable claims associated with a holder and (ii) a machine-readable consent policy capsule defining one or more disclosure constraints for the verifiable claims;
(b) receiving, from a verifier, a presentation request specifying at least one required claim category or proof requirement;
(c) generating a presentation plan, based at least on the consent policy capsule, that selects a subset of the verifiable claims sufficient to satisfy the presentation request while minimizing disclosure beyond the required claim category or proof requirement; and
(d) transmitting to the verifier a presentation proof derived from the subset of the verifiable claims according to the presentation plan, wherein providing a presentation proof that discloses a second subset of the verifiable claims not included in the subset requires an additional explicit consent input from the holder.

### A2 (Independent — system)
A system comprising one or more processors and non-transitory memory storing instructions that cause performance of the method of claim A1.

### A-dependents (examples)
- A1 wherein the verifiable claims are selectively disclosable claims encoded as SD-JWT claims.
- A1 wherein the presentation request is an OpenID4VP presentation request.
- A1 wherein the consent policy capsule defines disclosure tiers and step-up conditions.
- A1 further comprising generating a deterministic receipt comprising hashes of (i) the presentation request and (ii) the presentation proof.
- A1 wherein the disclosure constraints include retention limits or verifier-class constraints.

---

## Family D — Governance/Provenance Layer for AI-assisted Ops

### D1 (Independent — method)
A computer-implemented method comprising:
(a) receiving a workflow step description identifying at least one input artifact and at least one output artifact and one or more pointers to external resources;
(b) resolving the one or more pointers through a canonical roots registry to obtain canonical resource identifiers;
(c) generating a deterministic receipt comprising hashes of the at least one input artifact, the at least one output artifact, and the canonical resource identifiers; and
(d) preventing execution of a subsequent workflow step unless the deterministic receipt verifies against an expected receipt value, wherein a mismatch causes generation of a refusal receipt.

### D2 (Independent — system)
A system comprising one or more processors and memory storing instructions that cause performance of the method of claim D1.

### D-dependents (examples)
- D1 wherein the canonical roots registry is signed and versioned.
- D1 wherein the deterministic receipt is recorded in an append-only pointer ledger.
- D1 wherein the deterministic receipt is compatible with a transparency log.
- D1 wherein the workflow step description includes a tool version or environment fingerprint.
- D1 wherein the subsequent workflow step is associated with a multi-session label for provenance tracing.

---

## Families B and C (keep for follow-on provisionals)
See prior Draft_Claims_Set_v0.1; counsel can lift/refine for B/C as needed.
