# ARCHIVE_NOTICE

This bundle contains an `archive/` folder with historical snapshots used for regression review.
Starting v0.13, those snapshots are **label-sanitized** (internal-label tokens replaced with “private core”) so the full bundle remains share-safe.

Integrity:
- The authoritative integrity check is the ZIP `.sha256` sidecar.
- Payload file hashes (`SHA256SUMS.txt`, `Receipt.json`) exclude `archive/` by design.
