
# Provisional_Outline_PortableTrustEnvelope_v0.3

> **Purpose:** structured outline counsel can convert into a US provisional draft.  
> Include multiple embodiments; avoid disclosing private core/private core.

## 1. Title
Policy-Carrying Verifiable Presentation Envelope for Portable Trust Across Heterogeneous Platforms

## 2. Technical Field
Digital credentials, privacy-preserving identity, cross-platform reputation signals, consent-aware disclosure, and workflow provenance.

## 3. Background
- Problem: reputations/consents are siloed; cross-platform trust requires over-sharing.
- Baseline: VC/DID; issuance and presentation protocols; selective disclosure techniques.
- Gaps: missing portable consent semantics, anti-doxxing defaults, and auditable receipts.

## 4. Summary (high-level)
- Envelope object: claims + policy + disclosure material + receipt binding.
- Verifier workflow: request → consent evaluation → selective disclosure → verification → receipt.
- Optional modules: context/proximity gating; CoAura negotiation endpoints; provenance substrate integration.

## 5. Brief description of figures (suggested)
Fig.1 System overview: issuer/holder/verifier + envelope.
Fig.2 Data structure: envelope fields and bindings.
Fig.3 Sequence: request/policy/consent → selective disclosure → verify → receipt.
Fig.4 Embodiment: multi-format credential plug-ins (VC JSON-LD, SD-JWT VC, mdoc).
Fig.5 Embodiment: XR context-gated trust reveal ladder.
Fig.6 Embodiment: CoAura endpoint negotiation (request/offer/accept/receipt).
Fig.7 Embodiment: receipt + manifest + pointer-ledger provenance chain.
Fig.8 Security/privacy: anti-correlation strategies (unlinkable proofs, rotating IDs).

## 6. Detailed description (embodiments)
### 6.1 Envelope composition
- Field set: claims payload, policy payload, disclosure proof payload, receipt binding, version identifiers.
- Binding mechanisms: signatures/proofs over components; hash commitments.

### 6.2 Consent policy evaluation
- Policy schema describing permitted attributes, granularity, audiences, contexts.
- Context signals: session identifiers; proximity proofs; venue identifiers.

### 6.3 Selective disclosure
- SD-JWT and/or DI cryptosuites (BBS) or equivalent.
- Present subset of attributes with verifiability preserved.

### 6.4 Verification and receipts
- Verification steps for claims and proofs.
- Deterministic receipt content: hashes, timestamp, verifier identity handle, decision outcome.
- Receipt redaction guidelines for public logs.

### 6.5 XR trust reveal embodiment
- Trust-level ladder mapping to attribute granularity.
- Optional proximity proof to prevent remote scraping.

### 6.6 CoAura endpoint embodiment
- Capability discovery, negotiation verbs, consent prompts, receipt outputs.
- Machine-readable interface patterns.

### 6.7 Ops provenance embodiment
- Canonical roots configuration and pointer-ledger references.
- Manifests and regression detection.

## 7. Example flows
- Example 1: cross-game reputation proof with anti-doxxing defaults.
- Example 2: XR proximity-gated trust reveal at an event.
- Example 3: agent requests trust via CoAura endpoint and receives receipt.

## 8. Claim set (non-binding sketch)
- 1–3 independent claims: envelope method, system, and endpoint negotiation.
- 10–20 dependent claims covering variations and embodiments.

## 9. Avoided disclosures
- Explicitly note: private verification core exists but is not described; thresholds/weights internal.
