# CoClassify_Linter_v0.1.ps1
# Heuristic-only local lint to reduce accidental public disclosures.
param(
  [Parameter(Mandatory=$true)][string]$Path,
  [ValidateSet("Scan","CheckFrontmatter")][string]$Mode="Scan"
)
$ErrorActionPreference="Stop"; Set-StrictMode -Version Latest
function Hit([string]$kind,[string]$file,[string]$detail){ [pscustomobject]@{ kind=$kind; file=$file; detail=$detail } }
$patterns = @(
  @{ kind="OpSec.Path"; re="\\\\Server\\\\|\\\\\\w+\\\\\\w+\\$|[A-Z]:\\\\Users\\\\|C:\\\\Users\\\\|/etc/|\\.ssh|id_rsa" },
  @{ kind="Secrets.Keys"; re="-----BEGIN (?:RSA|EC|OPENSSH) PRIVATE KEY-----|AKIA[0-9A-Z]{16}|xox[baprs]-|AIza[0-9A-Za-z\\-_]{35}" },
  @{ kind="Auth.Flows"; re="Authorization:\\s*Bearer|Bearer\\s+[A-Za-z0-9\\-\\._~\\+\\/]+=*" },
  @{ kind="Patent.Enabling"; re="state machine|protocol|schema|pseudocode|algorithm|selective disclosure|negotiation endpoint|proximity gating" }
)
$files = Get-ChildItem -Path $Path -Recurse -File -ErrorAction Stop |
  Where-Object { $_.Extension -match '\.(md|txt|json|yml|yaml|ps1)$' } |
  Where-Object { $_.FullName -notmatch '\\archive\\' }
$hits = New-Object System.Collections.Generic.List[object]
foreach($f in $files){
  $txt = Get-Content $f.FullName -Raw -ErrorAction Stop
  if($Mode -eq "CheckFrontmatter"){
    if($txt -notmatch "COCLASS:" -or $txt -notmatch "VISIBILITY:" -or $txt -notmatch "DISCLOSURE_CLASS:"){
      $hits.Add((Hit "Missing.Frontmatter" $f.FullName "Expected COCLASS/VISIBILITY/DISCLOSURE_CLASS"))
    }
  }
  foreach($p in $patterns){
    if($txt -match $p.re){ $hits.Add((Hit $p.kind $f.FullName "Matched /$($p.re)/")) }
  }
}
$hits | Sort-Object kind,file | Format-Table -AutoSize
if($hits.Count -gt 0){ Write-Error ("FAIL: {0} hits" -f $hits.Count) } else { Write-Host "PASS: no hits" }
