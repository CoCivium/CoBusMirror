# PriorArt_SearchPlan_ElementMap_v0.1
Generated: 20260122T101542Z

Purpose: element-level prior art plan so counsel can quickly sanity-check novelty/non-obviousness and focus claims on differentiators.

## Family A — Portable Trust Envelope (VC/DID substrate + consent policy + selective reveal)
### Core elements (claim-building blocks)
1. A **portable envelope** containing (a) credential material or references, (b) consent policy, (c) verification/provenance metadata, (d) presentation rules.
2. **Selective reveal** bounded by issuer or policy rules (e.g., SD-JWT/VP-style presentations).
3. A **consent gate** that binds: subject intent + verifier request + allowed disclosures + audit record.
4. Cross-platform **reputation signal import/export** without doxxing (pseudonymous, minimal disclosure).
5. A private core (trade secret) that selects/weights/validates signals (black-boxed).

### Baseline prior-art buckets to check
- VC/VP substrate: W3C VCDM v2.0; DID Core; OpenID4VP.
- Selective disclosure credentials: SD-JWT + SD-JWT VC; U-Prove; Idemix/CL credentials.
- Trust negotiation & minimal disclosure: Paci et al.; Frikken et al.

**Targets**
- W3C VCDM v2.0 (REC): https://www.w3.org/TR/vc-data-model-2.0/
- W3C DID Core: https://www.w3.org/TR/did-core/
- OpenID4VP spec: https://openid.net/specs/openid-4-verifiable-presentations-1_0.html
- SD-JWT VC draft: https://datatracker.ietf.org/doc/draft-ietf-oauth-sd-jwt-vc/
- SD-JWT draft: https://datatracker.ietf.org/doc/draft-ietf-oauth-selective-disclosure-jwt/22/
- U-Prove overview: https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/U-Prove20Technology20Overview20V1.120Revision202.pdf
- Minimal credential disclosure (Paci 2008): https://dl.acm.org/doi/10.1145/1456424.1456439
- NDSS Trust negotiation (Frikken 2006): https://www.ndss-symposium.org/ndss2006/trust-negotiation-hidden-credentials-hidden-policies-and-policy-cycles/
- Selective disclosure review (2024): https://www.sciencedirect.com/science/article/pii/S2405959524000614

### Differentiation hypotheses to validate
- The **combination** of: portable envelope + explicit consent gate + cross-platform reputation export/import + reproducible provenance/receipts (Family B) + context/proximity reveal (Family C) is the novelty.
- Keep the private core as trade secret; claim the envelope mechanics and governance/provenance interfaces.

## Family B — Governance & Provenance Layer for AI-assisted ops (receipts + pointer registry + canonical roots)
### Core elements
1. Canonical root declaration used by tools to prevent drift (“canonical paths/roots”).
2. Append-only pointer registry to full URLs; reproducible navigation + provenance.
3. Deterministic receipts/manifests for bundles; verify scripts for regression detection.
4. Redaction discipline (“public-safe bus”) + hash-only inventory.
5. Optional anchoring to transparency / supply chain integrity patterns.

### Baseline prior-art buckets
- Supply chain provenance: SLSA, in-toto, TUF, SCITT, Sigstore.
- Transparency logs: Certificate Transparency, Binary Transparency.
- Reproducible builds + content addressing (adjacent).
- Audit logs / append-only logs (adjacent).

**Targets**
- SLSA v1.0: https://slsa.dev/spec/v1.0/
- in-toto specs: https://in-toto.io/docs/specs/
- TUF spec: https://theupdateframework.github.io/specification/latest/
- SCITT architecture: https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
- Certificate Transparency RFC 6962: https://www.rfc-editor.org/rfc/rfc6962
- Binary Transparency RFC 9162: https://www.rfc-editor.org/rfc/rfc9162

### Differentiation hypotheses
- Tailored to **multi-agent / multi-session** workflows: canonical-root + pointer registry + deterministic receipts as an “ops trust substrate”.
- “Public-safe bus” redaction discipline as a governance primitive.

## Family C — Proximity/context-gated trust reveal for XR
### Core elements
1. Context signal(s) in XR: proximity, co-presence, session context, device posture.
2. Policy that controls *when* a disclosure is allowed (not just *what* is disclosed).
3. Gradual reveal ladder (e.g., “far” -> “near” -> “handshake”) with auditability.

### Baseline prior-art buckets
- Proximity authentication (Bluetooth/NFC/location-limited channels).
- Context-aware access control / Zero Trust.
- VR privacy/security threat literature.

**Targets**
- NIST proximity-based auth (Bluetooth): https://patents.google.com/patent/EP3497953B1
- Proximity-based device authentication patent: https://patents.google.com/patent/US10237734/en
- Proximity access control patent: https://link.springer.com/article/10.1007/s10055-024-01079-9
- NIST Zero Trust SP800-207: https://www.nist.gov/publications/proximity-based-authentication-mobile-devices
- VR security/privacy survey (2024): https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/U-Prove20Technology20Overview20V1.120Revision202.pdf

### Differentiation hypotheses
- Application of proximity gating to **portable reputation/credential presentations** in XR, plus consent gates and receipts.

## Family D — AI-facing trust negotiation endpoints (“CoAura”-style AI-readable surfaces)
### Core elements
1. Machine-readable endpoint(s) that advertise: required proofs, acceptable credential formats, consent requirements, and disclosure constraints.
2. Negotiation protocol for requesting proofs and returning presentations.
3. Optional: policy tickets / asynchronous authorization.

### Baseline prior-art buckets
- Trust negotiation protocols (hidden creds/policies).
- UMA / GNAP as asynchronous authorization patterns.
- VC/VP presentation protocols.

**Targets**
- UMA 2.0: https://docs.kantarainitiative.org/uma/wg/rec-oauth-uma-grant-2.0.html
- GNAP WG: https://datatracker.ietf.org/group/gnap/
- OpenID4VP: https://openid.net/specs/openid-4-verifiable-presentations-1_0.html
- NDSS Trust negotiation: https://www.ndss-symposium.org/ndss2006/trust-negotiation-hidden-credentials-hidden-policies-and-policy-cycles/

### Differentiation hypotheses
- “AI-facing” is a packaging/interaction surface; novelty likely in combining negotiation surfaces + portable trust envelope + consent gating and provenance receipts.
