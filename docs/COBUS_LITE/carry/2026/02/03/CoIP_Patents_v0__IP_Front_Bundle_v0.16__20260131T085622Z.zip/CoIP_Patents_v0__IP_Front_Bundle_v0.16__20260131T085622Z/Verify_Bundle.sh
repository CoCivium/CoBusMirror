#!/usr/bin/env bash
# Verify_Bundle.sh (v0.11)
# Verifies payload hashes (SHA256SUMS.txt) + ThemeLock required files.
set -euo pipefail
echo "== Verify_Bundle.sh (v0.11) =="

root="$(pwd)"
test -f "$root/SHA256SUMS.txt" || { echo "Missing SHA256SUMS.txt" >&2; exit 1; }
test -f "$root/ThemeLock_v0.1.json" || { echo "Missing ThemeLock_v0.1.json" >&2; exit 1; }

# payload hash check (SHA256SUMS excludes itself and Receipt.json by design)
while IFS= read -r line; do
  [[ -z "${line// }" ]] && continue
  sha="${line%%  *}"
  rel="${line#*  }"
  test -f "$root/$rel" || { echo "Missing file referenced by SHA256SUMS: $rel" >&2; exit 1; }
  got="$(sha256sum "$root/$rel" | awk '{print $1}')"
  [[ "$sha" == "$got" ]] || { echo "SHA256 FAIL: $rel expected=$sha actual=$got" >&2; exit 1; }
done < "$root/SHA256SUMS.txt"
echo "Payload SHA256SUMS OK"

# ThemeLock required files check (jq optional; fall back to grep-based if absent)
if command -v jq >/dev/null 2>&1; then
  jq -r '.required_files[]' "$root/ThemeLock_v0.1.json" | while IFS= read -r f; do
    test -f "$root/$f" || { echo "ThemeLock FAIL: missing required file: $f" >&2; exit 1; }
  done
else
  echo "NOTE: jq not found; skipping strict ThemeLock JSON parsing (PS verifier is authoritative)."
fi
echo "ThemeLock required files OK (best-effort)"

if [[ -f "$root/Leak_Scanner.sh" ]]; then
  echo "Running leak scan..."
  bash "$root/Leak_Scanner.sh"
fi

echo "VERIFY PASS"
