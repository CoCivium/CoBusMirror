# Disclosure_Risk_Rules_v0.1

> Rules to avoid accidental patent-right loss or trade-secret leakage. Not legal advice.

## Rules of thumb
1) File before you talk mechanics (demos/decks can be disclosure).
2) Keep the private core out of writing; use boundary language only.
3) Assume repos are public; public repo = disclosure.
4) If unsure, downgrade detail: outcomes + interfaces + constraints.
5) Log external disclosures (date, recipients, what shown).
6) Separate patent story (interfaces/governance) from trade-secret story (inner heuristics).

## Safe investor talk track
- “We combine consent policy, selective disclosure, and context-gated step-up reveal to make portable trust work across platforms—without doxxing.”
- “We keep a narrow private verification core as a trade secret.”
Avoid: “We compute trust using X features/weights.”
