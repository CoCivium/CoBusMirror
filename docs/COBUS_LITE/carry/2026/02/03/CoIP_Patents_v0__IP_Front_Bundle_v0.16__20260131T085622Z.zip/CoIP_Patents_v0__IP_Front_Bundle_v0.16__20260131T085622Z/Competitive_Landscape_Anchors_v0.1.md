# Competitive_Landscape_Anchors_v0.1

> This is *not* exhaustive. Purpose: show counsel/investors we know the baseline landscape.

## VC / credential platforms (baseline ecosystem)
- Microsoft Entra Verified ID (managed VC service) — see official product page + docs.  
- Trinsic (identity platform / acceptance network; wallets, issuance, verification).  
- SpruceID (wallet/verifier ecosystem; government/public sector work).  
- MATTR (credential issuance/verification; OpenID4VP support).

## Why we still have patentable surface (high-level)
Most platforms implement standards (VC/DID, OpenID4VP) and general wallet flows. Our claimable surface emphasizes:
- **consent policy capsule** bound to portable envelope
- **disclosure minimization plan** + tiered step-up
- **context/proximity gating for XR** with fail-closed behavior
- **governance/provenance layer** for AI-assisted ops (canonical roots + pointer ledger + deterministic receipts)

## Notes for counsel
- Use these as “non-patent” baseline references; don’t over-claim standard behavior.
- Differentiate via system combination + policy semantics + gating + auditability.

---

## Additions (2026-01-22)
- Microsoft Entra Verified ID (docs): https://learn.microsoft.com/en-us/entra/verified-id/decentralized-identifier-overview
- OpenID4VP Final: https://openid.net/specs/openid-4-verifiable-presentations-1_0-final.html
- OpenID4VCI (versioned): https://openid.net/specs/openid-4-verifiable-credential-issuance-1_0-16.html
- DIDKit (SpruceID) docs: https://www.didkit.dev/  (implementation baseline)
- Trinsic platform site: https://www.trinsic.id/ (baseline issuer/verifier/wallet offering)
- MATTR credential verification: https://mattr.global/capabilities/credential-verification
