# Invention_Family_Risk_Matrix_v0.1

> Counsel/investor quick view. “Risk” = closest art + enablement burden + disclosure risk.
> Not legal advice.

| Family | Patentability risk | Enablement effort | Disclosure risk | Business alignment | Notes |
|---|---|---|---|---|---|
| A — PTE + policy capsule | Medium | Medium | Low–Med | Very High | Standards baseline exists; differentiation is system composition + policy semantics + minimization + step-up |
| D — ops provenance | Low–Med | Medium | Low | High | Many provenance systems exist; novelty is enforceable gating + canonical roots + pointer ledger as workflow substrate |
| B — XR proximity gating | Medium | Low–Med | Low | High | Proximity auth art exists; focus on tier semantics + continuity + refusal receipts |
| C — AI-facing negotiation | Med–High | Medium | Low–Med | Medium–High | Endpoint negotiation overlaps with auth; differentiate via machine-readable proof plans + consent semantics + step-up |
