# Investor_Diligence_IP_FAQ_v0.1

> Public-safe answers to common investor diligence questions.

## What’s your IP strategy?
A pragmatic “IP protection front”: patentable surfaces around portable trust + consent policy semantics + context-gated step-up reveal + auditable ops provenance. Keep a narrow private verification core as a trade secret. Defensive publish non-secret variants after filing to prevent lock-up by others.

## Are you just implementing standards?
We treat standards (W3C VC 2.0, OpenID4VP, SD-JWT, Digital Credentials API) as baseline. Our differentiation is system composition: consent policy capsule + disclosure minimization planning + context gating + deterministic receipt/provenance enforcement.

## What is kept secret?
The inner “private scoring/selection/verification core” and detection heuristics. Patents focus on interfaces and governance layers that can be disclosed without leaking the core.

## How does this help the business?
Provides deterrence + diligence credibility, supports partnerships, and reinforces a trust brand. We aim for optional openness later once the brand moat is established.
