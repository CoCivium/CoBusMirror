
# PriorArt_SearchPlan_v0.2

## Goal
For each invention family (A–D), identify:
- 3–5 closest prior-art items
- how our *combination* (consent + portability + provenance + context gating) differentiates
- which claim elements are at risk of being “obvious” and need better drafting

## Search targets (where)
- Google Patents, Lens.org, USPTO, Espacenet (patents)
- W3C/IETF/OpenID/DIF (standards)
- Academic papers: anonymous credentials, selective disclosure, proximity proofs
- Products: wallets, reputation systems, anti-cheat, content provenance

## Query set (copy/paste)
### Family A (PTE)
- "policy-carrying verifiable presentation"
- "selective disclosure verifiable credential consent policy"
- "portable reputation signal verifiable credential"
- "verifiable presentation privacy preserving envelope"

### Family B (XR trust reveal)
- "extended reality trust signal disclosure proximity"
- "proximity gated reputation disclosure"
- "avatar reputation cross platform privacy"
- "BLE request verifiable presentation"

### Family C (CoAura endpoints)
- "machine readable trust negotiation protocol"
- "agent to service credential negotiation endpoint"
- "capability discovery verifiable presentation"
- "model context protocol credential negotiation"

### Family D (receipts/provenance)
- "deterministic receipt workflow manifest hash"
- "canonical configuration prevent drift automation"
- "pointer ledger provenance URL registry"
- "attestation transparency log workflow"

## Closest prior art shortlists (initial)
*(These are starting points; counsel/patent search can refine.)*

### Family A — closest starting set
- W3C VC Data Model v2.0; W3C VC Data Integrity; W3C VC JOSE/COSE; SD-JWT (RFC 9901); SD-JWT VC draft; OpenID4VP/OpenID4VCI; DIF Presentation Exchange.
**Differentiation angle:** policy-carrying envelopes + portability + anti-doxxing defaults + receipts.

### Family B — closest starting set
- OpenID4VP over BLE; proximity verification patterns in access control; anti-cheat/anti-abuse “trust scoring” in games (product prior art).
**Differentiation angle:** graduated trust reveal ladder + consent policy + anti-correlation + session binding.

### Family C — closest starting set
- MCP spec + servers; llms.txt conventions; existing API-based credential exchanges (OpenID4VC).
**Differentiation angle:** agent-facing negotiation verbs + consent + deterministic receipts as first-class outputs.

### Family D — closest starting set
- SLSA, in-toto, Sigstore, reproducible builds, SBOM standards, certificate transparency.
**Differentiation angle:** applying supply-chain provenance primitives to multi-session AI/human orchestration with pointer-ledger + canonical roots.
