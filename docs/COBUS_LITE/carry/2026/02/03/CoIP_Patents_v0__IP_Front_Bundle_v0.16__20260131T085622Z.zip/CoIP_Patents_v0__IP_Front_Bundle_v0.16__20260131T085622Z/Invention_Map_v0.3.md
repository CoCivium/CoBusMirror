# Invention_Map_v0.3

> 4-box map for a credible “IP front” without disclosing the private core.

| Family | Problem | Solution summary | Novelty angle (vs VC/DID baseline) | Public vs Trade-Secret boundary |
|---|---|---|---|---|
| A) Portable Trust Envelope | Cross-platform trust signals leak identity; credentials become “data dumps” | Policy-bound selective disclosure presentation with consent gates + anti-doxxing defaults | System combination: SD-JWT/VCs + explicit policy capsule + portability across platforms | Public: envelope format, policy semantics, step-up reveal flows. Secret: scoring/weighting/selection core. |
| B) XR Proximity/Context Reveal | In XR, trust must be local & situational; global identity is unsafe | Proximity/context triggers step-up trust reveal (BLE/QR/session) using wallet-based presentation | Context gating + stepped disclosures + local-only signals | Public: trigger mechanics & gating. Secret: risk thresholds, anti-gaming heuristics. |
| C) CoAura Negotiation Endpoints | AIs need machine-readable surfaces, but consent must remain explicit | AI-facing endpoints that negotiate required claims and consent before presentation | Combine machine-readable docs/endpoints with consent-aware credential exchange | Public: endpoint schema + consent negotiation. Secret: ranking/interpretation core, partner details. |
| D) Governance/Provenance for AI Ops | Multi-session agentic workflows drift; hard to audit | Canonical roots + pointer ledger + deterministic receipts to prevent drift & enable reproducibility | Governance layer as an auditable trust substrate | Public: receipts/pointer registry primitives. Secret: redaction heuristics + incident playbooks. |
