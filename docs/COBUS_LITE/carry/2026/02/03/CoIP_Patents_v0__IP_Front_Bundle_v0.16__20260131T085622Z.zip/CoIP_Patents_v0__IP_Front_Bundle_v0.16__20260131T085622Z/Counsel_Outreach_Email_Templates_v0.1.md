# Counsel_Outreach_Email_Templates_v0.1

> Copy/paste templates. Keep attachments public-safe. Do not include trade secret mechanics.

## 1) Initial outreach (short)
Subject: Request: seed-stage provisional bundle (portable trust / privacy / provenance)

Hi [Name],

We’re seed-stage and building “portable trust”: opt-in reputation/consent signals users can carry across platforms (XR/gaming wedge) without doxxing. We want a pragmatic “IP protection front” (deterrence + diligence credibility), not courtroom dominance.

Could you do a quick fit check and quote for drafting 2–4 provisionals using a picket-fence strategy? We’ll provide public-safe invention briefs, claim sketches, figures list, and prior-art anchors. We maintain a narrow private core as a trade secret and will not disclose its mechanics.

If you’re open, I’ll send a 2-page invention map + brief packet and we can do a 30–45 min call this week.

Thanks,
[Name]

## 2) Send packet
Subject: Packet: invention map + briefs (public-safe) — request for provisional scope + estimate

Hi [Name],

Attached is our public-safe packet:
- invention map + family briefs (A–D)
- candidate inventions + draft claim sketches
- drawings list
- prior art anchors + search plan
- secrecy matrix / redaction rules

Ask: please recommend (1) best 2–4 families for first bundle, (2) claim scope & figure set, (3) cost + schedule (fixed fee preferred, or cap).

Best,
[Name]

## 3) Scope confirmation
Subject: Confirming scope for provisional bundle + redaction boundary

Hi [Name],

Confirming we’re aligned:
- Draft provisionals for Families [A,D] first; optional [B,C]
- Include claim set + embodiments + figures list
- Keep trade-secret boundary as “private scoring/selection/verification core” with no mechanics
- Provide a short prior-art scan note and what you’d search next

If yes, please send engagement letter with deliverables checklist and billing model/cap.

Thanks,
[Name]

## 4) Decline / pause
Subject: Thanks — we’re pausing selection for now

Hi [Name],

Thanks for your time. We’re pausing selection this week and may circle back after we file an initial provisional bundle. Appreciate your input.

Best,
[Name]
