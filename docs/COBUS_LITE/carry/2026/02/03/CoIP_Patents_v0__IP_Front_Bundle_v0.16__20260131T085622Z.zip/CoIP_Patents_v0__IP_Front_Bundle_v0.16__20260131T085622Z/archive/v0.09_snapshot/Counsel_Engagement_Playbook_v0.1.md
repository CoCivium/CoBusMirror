# Counsel_Engagement_Playbook_v0.1

> Operational checklist for working with counsel in “stealth IP” mode.

## Setup
- Single internal point-person.
- Separate threads per invention family.
- Separate storage: Public-safe vs Lawyer-only.

## First call agenda
- Confirm objective: deterrence + diligence credibility.
- Choose 2–4 families; default A + D first.
- Confirm trade-secret boundary language.
- Confirm filing cadence (picket fence).
- Assign drafts: claims + figures + embodiments.

## Draft review (avoid accidental disclosure)
Reject/strip:
- stable identifier assumptions
- thresholds/weights/inner-core mechanics
- partner names or integration specifics
- “one true algorithm” language (add variants)

## Billing discipline
- Prefer fixed fee per provisional or hourly cap.
- Engagement letter deliverables checklist:
  - abstract/background/summary
  - figures list + captions
  - embodiments
  - claims set (even provisional-style)
  - lightweight prior art notes

## Defensive publication decision
- Only after provisional filed.
- Ensure defensive publication does not disclose private core boundary.
