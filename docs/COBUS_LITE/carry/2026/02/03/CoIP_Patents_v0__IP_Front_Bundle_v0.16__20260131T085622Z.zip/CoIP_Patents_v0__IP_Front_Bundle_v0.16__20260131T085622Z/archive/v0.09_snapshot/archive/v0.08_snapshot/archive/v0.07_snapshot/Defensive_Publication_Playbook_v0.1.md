
# Defensive_Publication_Playbook_v0.1

> Defensive publication is **not** “write a blog post about secrets.” It is controlled disclosure to create **prior art**.

## When to defensive publish
- You believe a competitor will patent a broad idea you need freedom-to-operate on.
- The idea is valuable ecosystem infrastructure and should remain open.
- The idea is incremental and not worth paying to prosecute as a patent.

## When NOT to defensive publish
- You haven’t filed a provisional yet and you might want patent rights later.
- The disclosure would reveal trade-secret advantage.
- The disclosure could enable a copycat MVP in weeks.

## Where to publish (examples)
- Prior-art databases / defensive publishing services (e.g., IP.com PAD)
- Defensive publication platforms (e.g., TDCommons; check how examiners treat it)
- Archival venues with stable timestamps and discoverability (technical reports, preprint servers, etc.)

## How to write a defensive disclosure safely
- Describe **generic** methods and variations; avoid implementation details that are your advantage.
- Include diagrams and parameter ranges *without* exposing proprietary thresholds.
- Include enough specificity to establish enablement for the general concept.
- Attach a deterministic hash receipt of the disclosure package itself (date-stamped).

## Recommended internal process
1) Decide “patent vs defensive publish vs secret” using `Secrecy_Matrix_v0.2.md`.
2) If patent: file provisional **first**.
3) Draft defensive disclosure: scrub for secrets; have 2-person review.
4) Publish + record receipts/hashes for the published artifact and URL.
5) Update PriorArt_Log with the publication link and timestamp.

## Don’t self-sabotage
- Anything defensively published is public forever.
- Treat disclosures as “we are okay if everyone can do this.”
