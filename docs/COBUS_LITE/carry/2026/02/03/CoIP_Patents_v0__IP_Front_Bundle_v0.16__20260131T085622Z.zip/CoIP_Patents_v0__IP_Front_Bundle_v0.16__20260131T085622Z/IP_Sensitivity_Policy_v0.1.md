# IP_Sensitivity_Policy_v0.1
Generated: 20260131T085622Z

> Not legal advice. Goal: prevent accidental **public enabling disclosures** before priority filings (provisionals/PCT), while still allowing public progress updates.

## Core rule (seed-stage)
Assume most repos are public. Anything pushed to a public repo is a **public disclosure**.

## Why this matters (jurisdiction reality check)
- **Europe/EPO** generally follows **absolute novelty**: public disclosure before filing can destroy novelty, with only narrow exceptions.
- **US/Canada** have a **12-month grace period** for *your own* disclosures, but relying on it is risky and not global; “subject matter” alignment matters and differences can still be prior art.

## Definitions
### IP-sensitive
Anything that could reasonably be used to:
- draft a claim element (method step, data structure, protocol rule), OR
- enable implementation by a skilled engineer, OR
- reveal trade-secret boundaries (private core logic, thresholds, weighting, partner integration mechanics).

### Patent-adjacent
Describes **how** a system works (even at high level) rather than **what** it is for.

## Disclosure classes (use these labels)
- PUB0 (Safe): mission, non-technical marketing, values, high-level “what” with no mechanism.
- PUB1 (Caution): component lists, vague flows (non-enabling).
- HOLD1 (Patent-adjacent): claim-element candidates; keep private until priority filing.
- HOLD2 (Enabling): steps/schemas/pseudocode/algorithms; keep private; share only with counsel.
- TS (Trade Secret): private core; never publish; avoid writing down in shared artifacts.

## Timing gates
- Before priority filing: everything HOLD1/HOLD2/TS stays private.
- After filing: publish PUB1 only if it does not exceed what’s on file (“no new matter”).
- Defensive publication only when you choose “don’t enforce, but block others.”

## Publish-safe patterns for migrations
- Hash-only inventories (no excerpts).
- Pointer-only notes pointing to **private bundles**.
- Non-enabling status updates (“migrated receipts; verifier PASS; next …”).

## Session hygiene
- Every public note includes VISIBILITY=public and CLASS=PUB0|PUB1.
- If unsure: classify as HOLD1 and route privately.
