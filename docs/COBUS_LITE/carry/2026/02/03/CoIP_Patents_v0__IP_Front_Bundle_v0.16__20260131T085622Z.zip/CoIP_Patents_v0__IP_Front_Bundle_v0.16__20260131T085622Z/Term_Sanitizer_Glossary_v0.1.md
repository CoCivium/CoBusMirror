# Term_Sanitizer_Glossary_v0.1

> Public-safe phrase mapping. Use these phrases in counsel/investor materials.

| Internal term | Public-safe phrase |
|---|---|
| private core / private core | private scoring/selection/verification core (no mechanics) |
| CoAura | machine-readable trust negotiation endpoint / AI-facing interface |
| CoBusMirror | public coordination ledger (hashes + pointers only) |
| CanonicalPaths | canonical roots registry (single source of truth) |
| PointerRegistry | append-only pointer ledger / registry |
| receipts/manifests | deterministic receipts binding hashes of inputs/outputs/pointers |
