#!/usr/bin/env bash
# Verify_Bundle.sh
# Verifies internal SHA256SUMS.txt and required files list (ThemeLock).
set -euo pipefail

sha256file() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print $1}'
  else
    echo "No sha256 tool found" >&2
    exit 2
  fi
}

root="$(pwd)"
test -f "$root/SHA256SUMS.txt" || { echo "Missing SHA256SUMS.txt" >&2; exit 1; }

while IFS= read -r line; do
  [[ -z "${line// }" ]] && continue
  expect="${line%%  *}"
  rel="${line#*  }"
  fp="$root/$rel"
  test -f "$fp" || { echo "Missing file: $rel" >&2; exit 1; }
  act="$(sha256file "$fp")"
  [[ "${expect,,}" == "${act,,}" ]] || { echo "SHA256 FAIL: $rel" >&2; exit 1; }
done < "$root/SHA256SUMS.txt"
echo "Internal SHA256SUMS OK"

test -f "$root/ThemeLock_v0.1.json" || { echo "Missing ThemeLock_v0.1.json" >&2; exit 1; }
# light check: required_files presence (no jq dependency)
reqs=$(python - <<'PY'
import json
j=json.load(open("ThemeLock_v0.1.json","r",encoding="utf-8"))
for f in j.get("required_files",[]):
    print(f)
PY
)
while IFS= read -r f; do
  test -f "$root/$f" || { echo "ThemeLock FAIL missing: $f" >&2; exit 1; }
done <<< "$reqs"
echo "ThemeLock required files OK"
echo "VERIFY PASS"

# Optional leak scan
if [[ -f "$root/Leak_Scanner.sh" ]]; then
  bash "$root/Leak_Scanner.sh"
fi
