# Naming_Options_v0.1

**Session:** CoIP_Patents_v0  
**UTC build:** 20260122T070314Z  
**Goal:** outward-facing invention names that are patent-safe + marketing umbrellas that are safe.

## A) Patent-safe family names (boring on purpose)
1. **Consent-Gated Portable Trust Envelope**
2. **Context-Constrained Selective Disclosure of Trust Attributes**
3. **Proximity-Evidenced Credential Presentation for XR Sessions**
4. **Policy-Driven Minimal-Disclosure Trust Presentation**
5. **Deterministic Receipt Generation for Agentic Workflows**
6. **Canonical Root Enforcement for Distributed Workflow State**
7. **Pointer Ledger for Reproducible Navigation and Provenance**
8. **Machine-Readable Trust Negotiation Endpoint**
9. **Consent-Mediated Agent-to-Service Credential Exchange**
10. **Tamper-Evident Trust Interaction Receipts**

## B) Marketing umbrella names (safe)
1. **Portable Trust**
2. **Consent-First Reputation**
3. **Proof, Not Profile**

## C) “Do not say in public” reminders
- “private core” and “private core” remain internal-only labels.
- Never describe scoring details; only say “private verification core.”

