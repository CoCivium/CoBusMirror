# What_Goes_Where_v0.1
Generated: 20260131T085622Z

Companion to `CoDataTaxonomy_v0.1.yml` and `CoPlacementRules_v0.1.yml`.

| Class | Default | Allowed storage | Public repo? |
|---|---|---|---|
| CrownJewel | private | vault_only_encrypted | **NO** |
| PatentWave | private_until_filed | vault_only_encrypted / private_bundle_encrypted | **NO** (until filed; then only excerpted within filed scope) |
| TradeSecret | private | vault_only_encrypted / private_bundle_encrypted | **NO** |
| OpSec | private | vault_only_encrypted / private_bundle_encrypted | **NO** |
| PersonalOrClientData | private | vault_only_encrypted | **NO** |
| OpenDesign | public_by_default | public_repo / public_bus / private_bundle | YES |

Non-negotiable: mechanism-level content (protocols/schemas/algorithms/state machines) is PatentWave or TradeSecret until counsel says otherwise.
