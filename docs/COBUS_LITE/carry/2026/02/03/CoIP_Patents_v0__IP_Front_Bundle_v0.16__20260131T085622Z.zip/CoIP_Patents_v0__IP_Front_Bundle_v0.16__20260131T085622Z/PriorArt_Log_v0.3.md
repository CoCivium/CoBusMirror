
# PriorArt_Log_v0.3

> **Purpose:** pragmatic anchor list (standards + papers + products + patents).  
> Keep **“Core 30”** for the requested 15–30 range; additional items in appendix.

## Core 30 anchors (with notes)
1. W3C — Verifiable Credentials Data Model v2.0 — https://www.w3.org/TR/vc-data-model-2.0/ (baseline VC model)
2. W3C — Verifiable Credentials Overview — https://www.w3.org/TR/vc-overview/ (roadmap + context)
3. W3C — Decentralized Identifiers (DIDs) v1.0 — https://www.w3.org/TR/did-core/ (DID baseline)
4. W3C — Verifiable Credential Data Integrity 1.0 — https://www.w3.org/TR/vc-data-integrity/ (proof suites + integrity)
5. W3C — Data Integrity BBS Cryptosuites v1.0 — https://www.w3.org/TR/vc-di-bbs/ (selective disclosure/unlinkability)
6. W3C — Securing VCs using JOSE/COSE — https://www.w3.org/TR/vc-jose-cose/ (JOSE/COSE + SD-JWT alignment)
7. OpenID — OpenID4VP 1.0 — https://openid.net/specs/openid-4-verifiable-presentations-1_0.html (presentation protocol)
8. OpenID — OpenID4VCI 1.0 — https://openid.net/specs/openid-4-verifiable-credential-issuance-1_0.html (issuance protocol)
9. IETF RFC 9901 — Selective Disclosure for JWTs (SD-JWT) — https://www.rfc-editor.org/rfc/rfc9901.html (selective disclosure)
10. IETF draft — SD-JWT VC — https://datatracker.ietf.org/doc/draft-ietf-oauth-sd-jwt-vc/ (VC expression w/ SD-JWT)
11. W3C — Digital Credentials API — https://www.w3.org/TR/digital-credentials/ (browser-mediated flows)
12. DIF — Presentation Exchange — https://identity.foundation/presentation-exchange/ (request/presentation formats)
13. DIF — Presentation Exchange v2.1.1 — https://identity.foundation/presentation-exchange/spec/v2.1.1/ (ratified version)
14. DIF — DIDComm Messaging (v2) — https://identity.foundation/didcomm-messaging/spec/ (secure agent messaging)
15. ISO/IEC 18013-5 mDL / mdoc (baseline) — (search ISO paywalled; use OpenID specs for mdoc references)
16. Camenisch–Lysyanskaya (CL) signatures / anonymous credentials (baseline) — (academic baseline; see appendix links)
17. Microsoft U-Prove (anonymous credentials) — (baseline; see appendix links)
18. IBM Idemix (anonymous credentials) — (baseline; see appendix links)
19. Certificate Transparency (Merkle log) — RFC 9162 — https://www.rfc-editor.org/rfc/rfc9162.html (tamper-evident logs)
20. The Update Framework (TUF) — https://theupdateframework.io/ (update/auth trust chain baseline)
21. Sigstore — https://www.sigstore.dev/ (signing + transparency)
22. in-toto — https://in-toto.io/ (supply chain attestations)
23. SLSA — Supply-chain Levels for Software Artifacts — https://slsa.dev/ (provenance/levels baseline)
24. Reproducible Builds project — https://reproducible-builds.org/ (determinism baseline)
25. SPDX specification — https://spdx.github.io/spdx-spec/ (SBOM baseline)
26. CycloneDX specification — https://cyclonedx.org/specification/overview/ (SBOM baseline)
27. C2PA specification — https://c2pa.org/specifications/ (content provenance baseline)
28. Model Context Protocol (MCP) — https://modelcontextprotocol.io/specification/2025-11-25 (agent/tool protocol baseline)
29. llms.txt proposal — https://github.com/fireproof-storage/llms.txt (AI-facing docs convention baseline)
30. IP.com PAD overview (defensive publishing prior art channel) — https://kb.ip.com/pad/knowledge-base/introduction-to-defensive-publishing-and-the-prior-art-database-pad/ (defensive publishing mechanics)

## Appendix — additional anchors (extras)
- OpenID4VP over BLE (proximity-ish) — https://openid.net/specs/openid-4-verifiable-presentations-over-ble-1_0.html  
- W3C VC JSON Schema — https://www.w3.org/TR/vc-json-schema/  
- W3C DID Implementation Guide — https://www.w3.org/TR/did-imp-guide/  
- W3C blog: Digital Credentials API — https://www.w3.org/blog/2025/w3c-digital-credentials-api-publication-the-next-step-to-privacy-preserving-identities-on-the-web/  
- MCP announcement (Anthropic) — https://www.anthropic.com/news/model-context-protocol  
- TDCommons defensive publication discussion (Wired) — https://www.wired.com/story/google-tdcommons-dpub-patents-prior-art  
- IP.com publishing disclosures — https://kb.ip.com/pad/knowledge-base/publishing-disclosures-to-the-prior-art-database-pad/  
- in-toto attestation framework repo — https://github.com/in-toto/attestation  
- Sigstore docs (cosign attestations) — https://docs.sigstore.dev/cosign/verifying/attestation/  
- W3C Verifiable Credentials Vocabulary v2.0 — https://www.w3.org/2018/credentials/
