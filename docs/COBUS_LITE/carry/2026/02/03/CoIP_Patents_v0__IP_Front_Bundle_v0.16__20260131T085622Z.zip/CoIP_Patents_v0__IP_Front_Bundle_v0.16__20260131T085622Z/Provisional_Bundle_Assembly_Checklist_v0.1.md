# Provisional_Bundle_Assembly_Checklist_v0.1

> Operational checklist to assemble a provisional bundle quickly and safely (public-safe).
> Not legal advice; align with counsel.

## 0) Pre-flight
- [ ] Run Verify_Bundle + Leak_Scanner inside extracted folder
- [ ] Confirm inventors list + assignments (see IP_Ownership_and_Assignment_Checklist)
- [ ] Confirm no public disclosure before filing (Disclosure_Log)

## 1) Choose families for this filing
Default: A (PTE) + D (ops provenance). Optional: B (XR), C (AI-facing).

## 2) Assemble per-family packet (minimum viable)
- abstract (draft)
- background (draft)
- summary (draft)
- brief description of figures (captions)
- detailed description (embodiments; multiple variants)
- example flows / sequence diagrams
- claim set (even if “provisional-style”)

## 3) Figure discipline
- reuse consistent figure numbering per family (A1–A5, D1–D4, etc)
- ensure each figure is referenced in the description text

## 4) Trade-secret boundary discipline
- Use only: “private scoring/selection/verification core”
- No thresholds/weights; no internal identifiers; no partner details

## 5) Prior art package (light)
- include prior-art anchors + query pack
- counsel records closest 3–5 items and our differentiators

## 6) Post-filing
- decision: defensive publication for non-secret variants?
- update disclosure log for any future pitches/demos
