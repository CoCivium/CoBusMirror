# Verify_Bundle.ps1
# PS7-safe. Verifies:
# 1) ZIP SHA256 (if user provides zip path),
# 2) internal SHA256SUMS.txt,
# 3) ThemeLock required files + headings.
param(
  [Parameter(Mandatory=$false)][string]$ZipPath = ""
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function Sha256File([string]$p){
  $h = Get-FileHash -Algorithm SHA256 -LiteralPath $p
  return $h.Hash.ToLower()
}

function ReadUtf8([string]$p){
  return Get-Content -LiteralPath $p -Raw -Encoding UTF8
}

Write-Host "== Verify_Bundle.ps1 =="

# If ZipPath provided, verify against sidecar in same folder (if exists)
if($ZipPath -and (Test-Path -LiteralPath $ZipPath)){
  $sidecar = "$ZipPath.sha256"
  if(Test-Path -LiteralPath $sidecar){
    $expected = (Get-Content -LiteralPath $sidecar -Raw).Trim().Split()[0].ToLower()
    $actual = Sha256File $ZipPath
    if($expected -ne $actual){ throw "ZIP SHA256 FAIL: expected=$expected actual=$actual" }
    Write-Host "ZIP SHA256 OK"
  } else {
    Write-Host "NOTE: No .sha256 sidecar found next to zip."
  }
}

# Working directory assumed = extracted bundle folder
$root = (Get-Location).Path
$shaPath = Join-Path $root "SHA256SUMS.txt"
if(!(Test-Path -LiteralPath $shaPath)){ throw "Missing SHA256SUMS.txt" }

# Verify internal files
$lines = Get-Content -LiteralPath $shaPath -Encoding UTF8
foreach($line in $lines){
  if(-not $line.Trim()){ continue }
  $parts = $line.Split("  ",2)
  if($parts.Count -lt 2){ continue }
  $expect = $parts[0].Trim().ToLower()
  $rel = $parts[1].Trim()
  $fp = Join-Path $root $rel
  if(!(Test-Path -LiteralPath $fp)){ throw "Missing file referenced by SHA256SUMS: $rel" }
  $act = Sha256File $fp
  if($expect -ne $act){ throw "SHA256 FAIL: $rel expected=$expect actual=$act" }
}
Write-Host "Internal SHA256SUMS OK"

# ThemeLock check
$themePath = Join-Path $root "ThemeLock_v0.1.json"
if(!(Test-Path -LiteralPath $themePath)){ throw "Missing ThemeLock_v0.1.json" }
$theme = Get-Content -LiteralPath $themePath -Raw -Encoding UTF8 | ConvertFrom-Json

foreach($f in $theme.required_files){
  $fp = Join-Path $root $f
  if(!(Test-Path -LiteralPath $fp)){ throw "ThemeLock FAIL: missing required file: $f" }
}
Write-Host "ThemeLock required files OK"

foreach($kv in $theme.required_headings.PSObject.Properties){
  $file = $kv.Name
  $need = $kv.Value
  $fp = Join-Path $root $file
  $txt = ReadUtf8 $fp
  foreach($h in $need){
    if($txt -notmatch [regex]::Escape($h)){ throw "ThemeLock FAIL: missing heading '$h' in $file" }
  }
}
Write-Host "ThemeLock required headings OK"

# Optional leak scan
$leak = Join-Path $root "Leak_Scanner.ps1"
if(Test-Path -LiteralPath $leak){
  Write-Host "Running leak scan..."
  & $leak
}
Write-Host "VERIFY PASS"
