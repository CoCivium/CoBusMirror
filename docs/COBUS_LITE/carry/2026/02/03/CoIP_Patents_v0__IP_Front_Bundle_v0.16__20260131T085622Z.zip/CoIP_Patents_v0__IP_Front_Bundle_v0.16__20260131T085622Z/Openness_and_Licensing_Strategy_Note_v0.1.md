# Openness_and_Licensing_Strategy_Note_v0.1

> Long-term preference: become more open/public-domain once the trust brand is established.
> Near-term: maintain an IP front for deterrence + diligence credibility.

## Recommended stance
- **Patent the interfaces/governance surfaces** that are easy to describe without leaking the private core.
- **Keep a narrow private core as trade secret** to preserve optionality.
- **Defensive publish** after provisional filing to prevent others from locking up obvious derivatives.

## Later-stage options (choose deliberately)
1) Patent + royalty-free pledge (defensive)
2) Patent + open license (encourage ecosystem)
3) Patent + non-assert (brand/trust moat)
4) Public domain defensive disclosures (if filing costs become wasteful)

## Trigger to open up
- Once product-market signal + brand trust is strong enough that patents are less useful than adoption velocity.
