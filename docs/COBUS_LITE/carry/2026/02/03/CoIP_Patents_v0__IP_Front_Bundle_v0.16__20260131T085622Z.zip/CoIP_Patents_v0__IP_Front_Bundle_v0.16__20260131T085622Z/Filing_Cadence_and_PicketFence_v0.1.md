# Filing_Cadence_and_PicketFence_v0.1

> Strategy: “picket fence” provisionals (many narrow filings) to create a credible IP front quickly.

## Recommended order (default)
1) **Family A (PTE + consent policy capsule)** — core product wedge (portable trust)  
2) **Family D (ops provenance substrate)** — defensible, broad applicability, supports brand trust  
3) **Family B (XR proximity gating)** — wedge-specific extension  
4) **Family C (AI-facing negotiation endpoint)** — forward-facing / CoAura story

## Cadence pattern (pragmatic)
- Week 0–2: counsel fit + select families A & D + define figure set
- Week 2–4: draft A & D provisionals; file when “good enough”
- Week 4–8: extend with B and/or C; file follow-on provisionals
- After each filing: consider **defensive publication** of non-secret variants

## Picket fence rules
- Each provisional must be self-contained enough to stand alone.
- Prefer many embodiments/variants over one “single algorithm.”
- Keep trade secret boundary consistent across filings.
- Use consistent naming + figure conventions across families.
