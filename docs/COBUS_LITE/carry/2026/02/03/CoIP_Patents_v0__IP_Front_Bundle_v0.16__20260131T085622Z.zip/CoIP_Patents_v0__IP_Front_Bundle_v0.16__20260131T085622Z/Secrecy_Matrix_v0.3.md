# Secrecy_Matrix_v0.3

> **Rule:** patents describe the interface and governance substrate; the private core remains a trade secret.

| Category | Public now | Public later | Always private (trade secret) | Never write down (operational) | Lawyer-only |
|---|---|---|---|---|---|
| Envelope formats + policy semantics | ✅ |  |  |  |  |
| Step-up reveal flows | ✅ (high-level) | ✅ (details if needed) | thresholds/heuristics | abuse playbooks |  |
| XR proximity trigger mechanics | ✅ |  | anti-gaming weights | sensor anti-tamper tactics |  |
| AI-facing negotiation endpoint schema | ✅ | ✅ (examples) | ranking/interpretation | prompt abuse mitigations |  |
| Receipts/manifests/pointer-ledgers | ✅ (formats) | ✅ (tooling) | redaction rules | incident response |  |
| Private scoring/selection/verification core (private core/private core) |  |  | ✅ | ✅ | ✅ |
| Partner integration details |  | ✅ (select partners) | ✅ | ✅ | ✅ |
| Signing keys / credentials / server paths |  |  | ✅ | ✅ | ✅ |
