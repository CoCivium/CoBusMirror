# Counsel_RFP_and_Screening_v0.1

> Objective: select IP counsel for a **seed-stage** “IP protection front” (marketing + deterrence), without leaking trade secrets.

## Paste-ready project summary
We’re seed-stage (XR/gaming wedge). We’re creating “portable trust”: opt-in reputation/consent signals users can carry across platforms without doxxing. We want a pragmatic IP front (2–4 invention families + picket-fence provisionals) while keeping a narrow private core as a trade secret.

## Non‑negotiables
- Work from public-safe briefs; do not require secret core details.
- Strong redaction discipline: no keys, server paths, partner names, or inner-core mechanics.
- Prefer multiple narrow provisionals over one monolith.

## Scope
1) Review 2–4 invention families and recommend claim scope + figure set.
2) Draft first provisional bundle (A + D first; B/C optional).
3) Provide a prior-art search plan; lightweight initial scan is fine.
4) Advise defensive publication sequencing (post-provisional).

## Screening questions
1) Experience with VC/DID/Selective Disclosure (SD-JWT / OpenID4VP / W3C VC)? Cite 1–3 public examples.
2) Patent work in privacy, identity, reputation, provenance, supply-chain integrity, or XR?
3) Default strategy: “big foundational patent” vs “picket-fence provisionals”?
4) How do you maintain trade secret boundaries while drafting?
5) Who drafts (partner/associate) and what’s your cycle time for a provisional?
6) Billing model: fixed-fee per provisional, cap, or hourly?
7) Defensive publication: where/when do you recommend?
8) How do you coordinate filings when repos are public and evolving?

## Evaluation rubric
| Criterion | Weight |
|---|---:|
| System-composition novelty grasp | 25% |
| Picket-fence comfort + speed | 20% |
| VC/DID familiarity | 15% |
| Trade secret boundary discipline | 15% |
| Drafting quality | 15% |
| Cost fit | 10% |

## Redaction rules for counsel comms
- Replace private core/private core with: “private scoring/selection/verification core” (no mechanics).
- No credentials, keys, server paths, private folder names, partner names.
- No code excerpts unless pre-redacted.
