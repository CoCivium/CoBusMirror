
# Claim_Term_Glossary_v0.1 — consistent terminology

Use these terms consistently across provisionals/claims to avoid scope drift.

- **Trust Envelope / Portable Trust Envelope (PTE):** a data object that packages verifiable claims plus consent policy and (optionally) selective disclosure material.
- **Verifiable Claim:** a claim about a subject that can be cryptographically verified (e.g., VC, SD-JWT VC).
- **Selective Disclosure Proof:** cryptographic or structured method for disclosing a subset of claims while enabling verification.
- **Consent Policy:** machine-readable constraints indicating what can be disclosed, to whom, when, and under what context.
- **Context Signal:** a parameter about the interaction environment (e.g., proximity proof, session identifier, venue, role).
- **Trust Reveal:** a presentation of trust-related information with bounded granularity.
- **Receipt / Manifest:** deterministic record of an operation and its outputs, including content hashes and provenance references.
- **Pointer Ledger / Registry:** append-only list of external references (e.g., full URLs) used to reproduce or verify a workflow.
- **Canonical Roots:** a single source-of-truth configuration (paths/roots) used to prevent drift in orchestration.

Avoid internal terms (private core/private core) in filings; refer only to a **confidential verification core** when necessary.
