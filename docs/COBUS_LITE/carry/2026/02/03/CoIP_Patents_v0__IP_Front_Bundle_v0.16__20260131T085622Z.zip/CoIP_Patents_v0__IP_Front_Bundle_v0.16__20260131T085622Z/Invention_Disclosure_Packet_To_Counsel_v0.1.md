# Invention_Disclosure_Packet_To_Counsel_v0.1

> The minimal packet that lets counsel start drafting a provisional fast.

## Packet contents (attach or link)
- Invention_Map_v0.3.md
- Invention_Family_Briefs_v0.2.md
- Candidate_Inventions_v0.4.md
- Draft_Claims_Set_v0.1.md
- Drawings_List_and_Captions_v0.1.md
- Provisional_Outline_PortableTrustEnvelope_v0.4.md
- Provisional_Skeletons_BCD_v0.1.md
- PriorArt_Log_v0.4.md (+ updates)
- PriorArt_SearchPlan_v0.3.md (+ updates)
- Secrecy_Matrix_v0.3.md
- Disclosure_Risk_Rules_v0.1.md

## Counsel questions to answer (fast)
1) Which 2–4 families for initial bundle?
2) What claim breadth is realistic vs closest art?
3) Which 6–10 figures are essential?
4) What needs more detail (request *narrow* redacted excerpt only)?
5) Recommended filing cadence for picket fence (next 60–120 days)?
