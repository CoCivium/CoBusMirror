# Drawings_List_and_Captions_v0.1

## A) Portable Trust Envelope
- Fig A1 System overview (issuer / wallet / verifier / policy capsule / optional audit store)
- Fig A2 Issuance + holder binding + policy capsule attachment
- Fig A3 Presentation request → minimization plan → selective disclosure proof
- Fig A4 Step-up reveal (re-consent)
- Fig A5 Receipt generation + verification

## B) XR Proximity/Context
- Fig B1 BLE/QR/session trigger + nonce
- Fig B2 Local validation + fail-closed
- Fig B3 Proximity continuity window for step-up

## C) AI-facing negotiation endpoint
- Fig C1 Endpoint schema publication (machine-readable requirements)
- Fig C2 Negotiation: proof plan → consent → proof
- Fig C3 Step-up negotiation

## D) Governance/provenance
- Fig D1 Canonical roots registry + pointer registry
- Fig D2 Receipt/manifest contents
- Fig D3 Verification gate (mismatch halts)
- Fig D4 Provenance graph across sessions
