# Candidate_Inventions_v0.2

**Session:** CoIP_Patents_v0  
**UTC build:** 20260122T070314Z  
**Baseline references:** W3C VCDM; DID Core; VC Data Integrity; SD-JWT; OpenID4VP/4VCI.

Each candidate includes: novelty hook, baseline diff, claim sketch (1 independent + 3–5 dependent),
and disclosure boundary.

---

## 1) Consent-Gated Portable Trust Envelope (PTE)
**Novelty hook:** A portable “envelope” that bundles multi-issuer trust/reputation signals with an explicit consent
policy, producing minimal-disclosure presentations by default (anti-doxxing).

**Diff vs baseline:** Standards define credential formats and presentations; this focuses on *portable reputation signals*
with policy-governed selective reveal and multi-issuer bundling as a coherent envelope.

**Independent claim (method sketch):**  
1. A computer-implemented method comprising:  
   (a) storing, for a subject, a plurality of digitally verifiable claims issued by multiple
issuers;
   (b) associating the plurality of digitally verifiable claims with a consent policy specifying one
or more
       disclosure constraints based on at least a requester identity and a request context;
   (c) receiving, from a verifier, a request specifying a set of requested attributes;
   (d) evaluating the consent policy to determine a minimal attribute subset permitted to be
disclosed for the request;
   (e) generating a verifiable presentation proving the minimal attribute subset without disclosing
at least one
       non-requested attribute; and
   (f) transmitting the verifiable presentation to the verifier.

**Dependent claims (sketch):**
1.1 The minimal attribute subset is encoded using SD-JWT disclosures and salted digests.  
1.2 The verifiable presentation includes a zero-knowledge proof derived from a multi-message signature scheme.  
1.3 The request and transmission are performed using an OpenID4VP protocol flow.  
1.4 The consent policy includes anti-doxxing defaults that deny disclosure of stable identifiers unless an explicit
    context condition is met.
1.5 The claims include reputation or behavior signals expressed as bounded, non-identifying attributes with expiry.

**Disclosure boundary:**  
- Must disclose: envelope structure, policy evaluation flow, example selective disclosure mechanisms, interop flows.  
- Can keep secret: scoring/selection/verification core (private core/private core), weights/thresholds, abuse heuristics.

---

## 2) Policy-Driven Minimal Disclosure (PDM) with Consent Receipts
**Novelty hook:** Consent isn’t just a UI decision; it produces a verifiable *receipt* that binds (request, consent,
context, disclosed subset) for later dispute resolution without revealing secrets.

**Independent claim (method sketch):**  
1. A computer-implemented method comprising:  
   (a) receiving a trust request identifying requested attributes and a context;
   (b) presenting a consent interface or consent mediation to a holder;
   (c) generating a disclosure decision that selects a minimal set of attributes;
   (d) generating a cryptographically verifiable receipt that includes at least hashes of the
request, the context,
       and the disclosed attributes; and
   (e) transmitting the receipt to at least one of the holder and verifier.

**Dependent claims:**
2.1 The receipt is verifiable using a public key associated with an issuer or wallet.  
2.2 The receipt omits raw attribute values and includes salted hashes of disclosed values.  
2.3 The receipt includes an expiry and replay-protection token.  
2.4 The receipt is stored in an append-only log.

**Disclosure boundary:**  
- Must disclose: receipt fields at a schema level and verification method.  
- Can keep secret: heuristics that decide defaults; risk scoring; internal threat models.

---

## 3) Proximity-Evidenced Trust Reveal for XR Sessions (PETR)
**Novelty hook:** Trust reveals are gated by XR session evidence and/or near-field proximity evidence to prevent
drive-by data leakage.

**Independent claim (method sketch):**  
1. A computer-implemented method comprising:  
   (a) receiving a request for one or more trust attributes in an XR experience;
   (b) obtaining a context evidence token indicating a proximity condition or a shared-session
condition;
   (c) evaluating a disclosure policy using the context evidence token;
   (d) selecting a minimal subset of the trust attributes permitted under the disclosure policy; and
   (e) generating and transmitting a verifiable presentation proving the minimal subset.

**Dependent claims:**
3.1 The context evidence token is derived from a BLE or NFC interaction within a distance threshold.  
3.2 The context evidence token is derived from an XR session handshake and includes a time window.  
3.3 The disclosure policy denies stable identifiers unless proximity evidence is present.  
3.4 The minimal subset is selectively disclosed via SD-JWT or zero-knowledge proof mechanisms.

**Disclosure boundary:**  
- Must disclose: evidence token types and policy gating flow.  
- Can keep secret: proximity thresholds, risk heuristics, abuse detection.

---

## 4) Cross-Platform Reputation Signal Packaging with Anti-Pooling Controls
**Novelty hook:** Prevent “credential pooling” or “signal laundering” while still allowing pseudonymous portability.

**Independent claim (method sketch):**  
1. A computer-implemented method comprising:  
   (a) receiving reputation signals from multiple issuers associated with a subject;
   (b) binding the signals to a subject-held secret or device-bound key;
   (c) generating a presentation that proves possession of the bound signals without revealing the
secret; and
   (d) rejecting presentations that combine signals bound to different subject-held secrets.

**Dependent claims:**
4.1 The binding uses a signature on a committed value.  
4.2 The presentation includes a proof that disclosed signals are bound to a single holder.  
4.3 The signals are time-bounded and include revocation information.  
4.4 The method supports optional anonymity revocation under defined conditions (counsel review).

**Disclosure boundary:**  
- Must disclose: binding concept and proof structure at a high level.  
- Can keep secret: how signals are weighted/combined into scores.

---

## 5) Canonical Root Enforcement for Distributed Workflow State (CREF)
**Novelty hook:** Prevent silent “truth path” forks by enforcing a canonical root declaration referenced by tools and
workflows.

**Independent claim (method sketch):**  
1. A computer-implemented method comprising:  
   (a) reading a canonical root declaration that specifies one or more authorized root locations for
workflow state;
   (b) receiving a workflow instruction referencing a target resource;
   (c) verifying that the target resource resolves under the authorized root locations; and
   (d) denying or quarantining the workflow instruction when the target resource resolves outside
the authorized
       root locations.

**Dependent claims:**
5.1 The canonical root declaration is cryptographically signed.  
5.2 The method logs a hash-only denial receipt for denied instructions.  
5.3 The method is used to constrain AI-assisted tools that write or mutate files.  
5.4 The canonical root declaration is versioned and referenced by a pointer ledger.

**Disclosure boundary:**  
- Must disclose: enforcement logic and canonical root file format.  
- Can keep secret: internal path inventories; private infrastructure details.

---

## 6) Pointer Ledger for Reproducible Navigation and Provenance (PLRNP)
**Novelty hook:** An append-only pointer ledger (full URLs) enables reproducible navigation of artifacts and prevents
hidden drift, especially across AI/human sessions.

**Independent claim (method sketch):**  
1. A computer-implemented method comprising:  
   (a) appending, to an append-only log, a pointer record comprising a fully qualified locator of an
artifact and a
       cryptographic hash of the artifact;
   (b) resolving subsequent workflow steps exclusively through pointer records in the append-only
log; and
   (c) verifying, before consumption, that the artifact matches the cryptographic hash recorded in
the pointer record.

**Dependent claims:**
6.1 The pointer record includes a timestamp and an author identity.  
6.2 The method produces a deterministic bundle receipt for a set of pointers.  
6.3 The method supports “hash-only” public disclosure while keeping artifact contents private.  
6.4 The method is used to orchestrate multi-session AI workflows.

**Disclosure boundary:**  
- Must disclose: pointer record schema and verification steps.  
- Can keep secret: internal redaction heuristics and private artifact contents.

---

## 7) Deterministic Receipt Bundles for Agentic Workflows (DRBAW)
**Novelty hook:** Deterministic receipts (manifest + hashes + verification script) for *operations* (not just builds),
applied to AI-assisted workflow runs.

**Independent claim (method sketch):**  
1. A computer-implemented method comprising:  
   (a) generating, for an execution of a workflow, a manifest enumerating input artifacts and output
artifacts;
   (b) computing a cryptographic hash for each enumerated artifact;
   (c) generating a receipt that includes the manifest and the cryptographic hashes; and
   (d) providing a verification procedure that validates the receipt and detects deviation between
the manifest and
       a later-observed artifact set.

**Dependent claims:**
7.1 The manifest is stored in a zip bundle together with the receipt and verification procedure.  
7.2 The receipt includes a monotonic version identifier and a timestamp.  
7.3 The receipt includes redaction rules for omitting sensitive file contents while preserving hash integrity.  
7.4 The receipt is linked to pointer ledger records.

**Disclosure boundary:**  
- Must disclose: receipt/manifest structure and verification procedure.  
- Can keep secret: redaction policy details; sensitive artifact contents.

---

## 8) Machine-Readable Trust Negotiation Endpoint with Consent Mediation (MRTNE)
**Novelty hook:** A machine-readable endpoint advertises allowable trust requests and returns structured challenges,
enabling AI agents to negotiate trust proofs with consent mediation.

**Independent claim (method sketch):**  
1. A computer-implemented method comprising:  
   (a) publishing, at a network endpoint, a machine-readable capability description that specifies
acceptable trust
       proof requests;
   (b) receiving a request from an automated agent for a trust proof;
   (c) generating a structured challenge that encodes requested claims and required context;
   (d) mediating consent via a user agent or wallet; and
   (e) receiving a verifiable presentation and returning a verifiable interaction receipt.

**Dependent claims:**
8.1 The capability description includes a disclosure policy and a receipt schema.  
8.2 The structured challenge is compatible with a digital credential request API.  
8.3 The method supports progressive disclosure based on context evidence.  
8.4 The interaction receipt is appended to a transparency log.

**Disclosure boundary:**  
- Must disclose: endpoint schema, challenge format, receipt fields.  
- Can keep secret: internal ranking/interpretation; partner routing.

