# Leak_Scanner.ps1
# Scans extracted bundle for disallowed substrings (LeakScan_Patterns_v0.1.txt).
# Use before sending to counsel/investors.
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

$root = (Get-Location).Path
$patFile = Join-Path $root "LeakScan_Patterns_v0.1.txt"
if(!(Test-Path -LiteralPath $patFile)){ throw "Missing LeakScan_Patterns_v0.1.txt" }

$patterns = Get-Content -LiteralPath $patFile -Encoding UTF8 | Where-Object { $_ -and -not $_.StartsWith("#") } | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ }

# File types to scan
$files = Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object {
  $_.FullName -notmatch "\\archive\\" -and
  ($_.Extension -in @(".md",".txt",".json",".yml",".yaml",".ps1",".sh",".csv"))
}

$hits = @()
foreach($f in $files){
  $txt = Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8
  $low = $txt.ToLower()
  foreach($p in $patterns){
    if($low.Contains($p)){
      $hits += [pscustomobject]@{ file=$f.FullName.Substring($root.Length+1); pattern=$p }
    }
  }
}

if($hits.Count -gt 0){
  Write-Host "LEAK SCAN FAIL:" -ForegroundColor Red
  $hits | Sort-Object file,pattern | Format-Table -AutoSize
  throw "Leak scan failed: remove/redact flagged content."
}

Write-Host "LEAK SCAN PASS"
