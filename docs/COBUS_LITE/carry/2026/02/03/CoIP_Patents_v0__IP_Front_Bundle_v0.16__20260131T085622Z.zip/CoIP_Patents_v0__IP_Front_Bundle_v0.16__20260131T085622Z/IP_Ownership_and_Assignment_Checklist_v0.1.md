# IP_Ownership_and_Assignment_Checklist_v0.1

> Seed-stage hygiene: ensure you actually own what you plan to patent.
> Not legal advice; align with counsel.

## People
- founders: invention assignment agreements signed?
- employees/contractors: invention + confidentiality assignments signed?
- advisors: is compensation tied to IP? have they signed assignment/confidentiality?
- contributors: are public repos accepting PRs? ensure contributor license terms are clear.

## Records
- invention disclosure logs: date, inventors, summary, exhibits
- contribution log: who wrote what, when
- third-party code: licenses reviewed for contamination risk

## Process
- do not co-mingle trade-secret internals into public repos
- run disclosure log for every investor demo/deck
- keep “lawyer-only” folder for redacted excerpts when needed
