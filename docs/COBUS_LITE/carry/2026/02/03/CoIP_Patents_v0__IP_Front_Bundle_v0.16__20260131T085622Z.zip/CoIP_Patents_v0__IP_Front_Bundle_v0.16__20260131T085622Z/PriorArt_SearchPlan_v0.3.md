# PriorArt_SearchPlan_v0.3

> Goal: quickly identify the “closest” 3–5 items per family and capture differentiators.
> This plan is intentionally **pragmatic** and designed for fast counsel handoff.

## How to search (repeatable)
### Patent search
Use multiple engines:
- Google Patents
- Lens.org (if available)
- Espacenet (if needed)
- USPTO and WIPO as backups

Suggested query patterns:
- ("verifiable credential" OR "digital credential" OR "selective disclosure") AND (policy OR consent OR "presentation")
- (SD-JWT OR "selective disclosure" OR "key binding") AND (JWT OR JWS OR credential)
- (proximity OR BLE OR "bluetooth low energy" OR QR) AND (credential OR authentication OR trust reveal)
- (provenance OR "deterministic receipt" OR manifest OR "tamper-evident") AND (workflow OR orchestration OR agent)
- (pointer OR registry OR "canonical path" OR "append-only") AND (audit OR reproducible OR governance)

For each candidate patent:
- record: number, assignee, filing date, priority date, key claim 1 paraphrase, why close

### Standards & open-source search
- W3C TR index for VC/DID/DC API related docs
- IETF Datatracker for SD-JWT / SD-JWT VC status
- OpenID specs for OID4VP / OID4VCI / offline BLE variants
- provenance ecosystems: TUF, Sigstore, in-toto, SLSA, C2PA
- AI tool interface specs: MCP; llms.txt

## Family-specific search targets (10–20 each)
### Family A: Portable Trust Envelope (policy-bound selective disclosure)
Targets:
- SD-JWT (RFC 9901), SD-JWT VC draft, OpenID4VP/4VCI, DC API
- Patents around VCs issuance/verification platforms and policy-based access control with credentials
Closest-risk examples (starter set):
- US20230164143A1 (VC issuance/verification platform)
- US20230388287A1 (VCs + policies for service federation)
- US20190370487A1 (consent-driven disclosure + privacy vault model)

### Family B: XR proximity/context-gated trust reveal
Targets:
- OpenID4VP over BLE; QR/offline presentation flows; BLE proximity auth patents
Closest-risk examples:
- US20160295349A1 (proximity authentication using bluetooth)
- WO2019139630A1 (proximity-based trust)

### Family C: AI-facing trust negotiation endpoints (CoAura)
Targets:
- MCP spec; llms.txt patterns; machine-readable negotiation endpoints; consent mediated credential retrieval via DC API
Notes:
- Likely novelty is in **combining** machine-readable interfaces with explicit consent + portable trust envelopes.

### Family D: Governance/provenance layer for AI-assisted ops
Targets:
- TUF/Sigstore/in-toto/SLSA/C2PA and workflow provenance patents
Closest-risk examples:
- US10628389B2 (provenance verification)
- US11120005 (workflow provenance tracking)

## Capture format (recommended)
For each “closest” item, record:
- why close (1–2 lines)
- how we differ (system combination, consent policy capsule, step-up reveal, receipts/pointer registry)
- what we must avoid claiming too narrowly

## Output artifacts (for counsel)
- 1-page family brief (problem/solution/novelty/trade-secret boundary)
- 5–10 candidate claims (independent + dependents)
- 3–5 closest prior art + differentiator notes

## Additional baseline checks
- Scan major VC platform providers (Entra Verified ID, Trinsic, SpruceID, MATTR) to avoid claiming standard behavior.
- Track W3C Verifiable Credentials 2.0 Recommendation announcement and changes vs VC 1.1.
