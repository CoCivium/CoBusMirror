# Candidate_Inventions_v0.4

> 10 candidate inventions. Each includes: novelty hook, 1 independent claim sketch + 3–5 dependents,
> and what must be disclosed vs can remain trade secret.
> **Not legal advice.** Use as structured input for counsel.

---

## 1) Portable Trust Envelope with Consent Policy Capsule
**Novelty hook:** combine selective disclosure credentials with a machine-readable **consent policy capsule** that governs step-up reveal and portability across platforms.  
**Independent claim sketch:** A computer-implemented method comprising generating a portable trust envelope including a verifiable claim set and a consent policy capsule that constrains disclosure of claims to a verifier request, and presenting a subset of claims according to the consent policy capsule and an explicit user consent input.  
**Dependents:** (a) selective disclosure via SD-JWT; (b) holder key binding; (c) policy capsule expresses tiers + expiry; (d) verifier request language; (e) audit receipt generation.  
**Disclose vs keep secret:** disclose envelope structure + policy semantics; keep private any scoring/selection heuristics and thresholds.

## 2) Step-up Trust Reveal (Incremental Disclosure Tiers)
**Novelty hook:** deterministic stepped disclosure with explicit re-consent gates and optional “cap” to prevent over-disclosure.  
**Independent claim sketch:** presenting an initial minimal proof and, upon receiving a step-up request, presenting additional claims only if a policy tier allows and re-consent is obtained.  
**Dependents:** (a) tiered policy capsule; (b) decoy claim digests; (c) verifier categories; (d) time/geo/session constraints; (e) anti-replay binding.  
**Disclose vs keep secret:** disclose step-up mechanism; keep risk thresholds and abuse detection triggers.

## 3) XR Proximity-Triggered Credential Presentation
**Novelty hook:** proximity/context signal triggers a wallet-based trust presentation with local-only signals and stepped reveal.  
**Independent claim sketch:** receiving a proximity trigger (BLE/QR/session), initiating a credential presentation flow, and enforcing a local context check prior to disclosure.  
**Dependents:** (a) BLE advertisement; (b) QR challenge; (c) session token binding; (d) local-only ephemeral identifiers; (e) step-up reveal tied to proximity continuity.  
**Disclose vs keep secret:** disclose trigger + gating; keep anti-gaming heuristics and signal weighting.

## 4) Context-Gated Trust Reveal Using Multi-Signal “Context Bundle”
**Novelty hook:** combine multiple contextual signals (device posture, session, proximity) into a context bundle used to gate disclosure tiers.  
**Independent claim sketch:** generating a context bundle from multiple sensors/signals and selecting a disclosure tier based on the bundle and policy.  
**Dependents:** (a) fail-closed behavior; (b) per-verifier policies; (c) privacy-preserving bundling; (d) context expiry; (e) user override rules.  
**Disclose vs keep secret:** disclose context bundle concept; keep exact scoring/decision logic.

## 5) AI-facing Trust Negotiation Endpoint (“CoAura”)
**Novelty hook:** machine-readable endpoint that produces a minimal proof plan, then executes a consent-mediated presentation.  
**Independent claim sketch:** exposing an endpoint that returns required claim categories and acceptable proofs, receiving a consent confirmation, and producing a presentation proof satisfying the endpoint.  
**Dependents:** (a) endpoint includes retention constraints; (b) supports DC API; (c) supports SD-JWT VC; (d) supports step-up requests; (e) emits deterministic receipt.  
**Disclose vs keep secret:** disclose endpoint schema; keep ranking/interpretation core and abuse controls.

## 6) Consent-Aware “Disclosure Minimization” Compiler
**Novelty hook:** compile verifier requirements + policy capsule into the smallest satisfiable disclosure set.  
**Independent claim sketch:** computing, from a verifier request and policy capsule, a minimal subset of claims and disclosures required to satisfy the request.  
**Dependents:** (a) optimization objective: minimize identifiability; (b) tie-breakers; (c) supports multiple credential formats; (d) decoy digests; (e) proof plan explanation for user.  
**Disclose vs keep secret:** disclose minimization concept; keep objective weights/heuristics.

## 7) Canonical Roots Enforcement for Multi-Agent Orchestration
**Novelty hook:** prevent drift/fork by requiring scripts/tools to resolve all paths/pointers through a canonical roots file.  
**Independent claim sketch:** executing a workflow step only if all referenced resources resolve via a canonical roots registry, otherwise halting with a deterministic receipt of failure.  
**Dependents:** (a) pointer registry ledger; (b) allowlist of full URLs; (c) signed root registry; (d) session labeling; (e) regression detection.  
**Disclose vs keep secret:** disclose enforcement mechanism; keep redaction heuristics and incident playbooks.

## 8) Deterministic Receipts/Manifests for Agentic Workflows
**Novelty hook:** produce tamper-evident receipts binding inputs/outputs/pointers and enabling reproducible audits across sessions.  
**Independent claim sketch:** generating a receipt including hashes of inputs, outputs, and pointers for a workflow step and verifying the receipt prior to subsequent steps.  
**Dependents:** (a) zip manifest; (b) hash algorithm agility; (c) signed receipt; (d) provenance graph; (e) external transparency log integration.  
**Disclose vs keep secret:** disclose receipt format; keep internal risk scoring and redaction rules.

## 9) Trust-Brand Authenticity Proof Chain for Rep Signals
**Novelty hook:** anti-sabotage pattern: a platform can validate that a presented reputation signal is authentic and unmodified, without learning underlying identity.  
**Independent claim sketch:** verifying a trust signal against an issuer proof chain and presenting a verifier-only proof of authenticity.  
**Dependents:** (a) unlinkable presentations; (b) short-lived trust tags; (c) revocation handling; (d) anti-replay binding; (e) verifier policy constraints.  
**Disclose vs keep secret:** disclose proof chain concept; keep signal generation heuristics.

## 10) Privacy Vault Tokenization with Verifier-Specific Consents (VC-friendly)
**Novelty hook:** consent-specific tokens representing a user and allowed disclosures (aligned to VC/Digital Credentials flows).  
**Independent claim sketch:** issuing verifier-specific consent tokens that gate access to a subset of private attributes and generating a proof limited by the token.  
**Dependents:** (a) per-verifier scopes; (b) expiry; (c) revocation; (d) audit receipts; (e) wallet mediation.  
**Disclose vs keep secret:** disclose tokenization concept; keep vault internals and decision rules.

---

## Notes
- Several items overlap; counsel can consolidate into 2–4 families for provisionals.
- Avoid claims that require disclosing the private scoring/selection core.
