
# Counsel_Handoff_Checklist_v0.1

## What we should give counsel (safe + useful)
- This bundle (v0.03) and any non-sensitive architecture diagrams
- A 1-page “product story” (portable trust wedge in XR/gaming; opt-in; anti-doxxing)
- A short list of 2–4 invention families we want to file on first
- Any public repo artifacts that reflect the ops substrate primitives (URLs only)

## What counsel should ask us (without needing private core)
- What parts of the system are customer-visible vs internal?
- Where do partners integrate? (interfaces, not partner names)
- What must be interoperable with standards, and what can be proprietary?
- What is the trade-secret boundary? (explicit list of “don’t write down” items)

## What we must NOT hand over in plaintext
- private core/private core internals (parameters, thresholds, formulas, model details)
- credential keys, server paths, private folder names, or partner rosters
- internal “abuse response” thresholds and playbooks

## Outputs we want from counsel
- invention disclosure forms (one per family) refined into provisional-ready drafts
- claim set strategy (broad + fallback claims)
- filing timing recommendation (provisional/PCT/non-provisional) within budget
- trade secret hygiene checklist tailored to our team/contractors
