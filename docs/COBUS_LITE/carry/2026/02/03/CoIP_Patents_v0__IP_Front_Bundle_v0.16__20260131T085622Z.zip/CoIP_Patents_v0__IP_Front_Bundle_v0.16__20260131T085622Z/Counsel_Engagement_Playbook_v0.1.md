# Counsel_Engagement_Playbook_v0.1
Generated: 20260122T101542Z

> **Not legal advice.** This is a practical, investor-credible “IP-front” operating guide for working with counsel efficiently while keeping the narrow trade-secret band private.

## 1) What you want from a firm (deliverables, not vibes)
**Phase 0 — Fit + framing (1–2 weeks)**
- Confirm **2–4 invention families** and trade-secret boundaries.
- Draft **invention disclosures** (1–3 pages each) and a **provisional filing plan** (“picket fence” sequencing).
- Produce a **prior art shortlist**: closest 3–5 per family, plus how we differentiate.

**Phase 1 — Provisionals (30–45 days)**
- 1–2 **provisional applications** that are:
  - broad enough to support continuations/divisionals later
  - detailed enough to avoid “spec starvation”
  - written with **claim scaffolding** (not just marketing prose)
- A **figure pack list**: sequence diagrams, data flows, consent gates, receipt creation/verification, and threat-mitigation flows.

**Phase 2 — Convert (9–12 months)**
- Convert strongest families to **non-provisional**; keep the rest as new provisionals or defensive publications.

## 2) Selection criteria (what matters for seed-stage)
- Demonstrated work in **identity / credentials / OAuth / privacy** and **software + crypto-adjacent** filings.
- Can write **system + method claims** credibly without forcing disclosure of the private core.
- Comfortable with: “*We claim the envelope and the governance/provenance layer; the scoring core stays a trade secret.*”
- Clear billing + predictable budgets (avoid “blank check” research tasks).

## 3) How to brief them (the minimum packet)
Provide counsel a single bundle containing:
- **Invention Map** (one page, 4 boxes max).
- **Secrecy Matrix** (one page).
- **Candidate inventions** (6–10 entries with claim sketches).
- **Prior art shortlist + scan plan** (so they don’t reinvent your homework).
- **Provisional skeleton** (outline + figure list).
- A short glossary defining “portable trust envelope”, “consent gate”, “proximity/context reveal”, “AI-facing endpoint” at a high level.

## 4) Guardrails you enforce with counsel
- The private core stays black-boxed: “private core selects/weights/validates signals.” No parameters, no thresholds, no scoring math in drafts.
- No partner names. No server paths. No keys. No internal registries.
- Drafts should be **reviewable by a non-lawyer**: if you can’t understand it, it will be hard to defend later.

## 5) Budget tactics (seed-stage)
- Push for **fixed-fee** on: invention disclosure + provisional + conversion.
- Ask for a **claim-scope matrix** per family before they draft long text.
- Insist on a “**draft-to-provisional**” schedule that ends with a filing, not endless rewrites.

## 6) Filing posture: credible front + deterrence
- File 1–2 **broad provisionals** early for investor comfort.
- Keep 1–2 families as “**ready to file**” but delay if the product may pivot.
- Use **defensive publication** for things you don’t want to spend money enforcing (especially ops/governance patterns).

## 7) What to ask in the first call (script)
- “Show me 3 examples of provisionals you wrote that converted cleanly to non-provisional.”
- “How do you handle inventions where the secret sauce must remain a trade secret?”
- “What’s your recommended **picket fence** schedule across 12 months?”
- “What’s your **prior art approach**? What do you expect us to provide vs you provide?”

## References you can point to as *baseline context* (not your novelty)
- W3C VC Data Model v2.0: https://www.w3.org/TR/vc-data-model-2.0/
- DID Core: https://www.w3.org/TR/did-core/
- OpenID4VP: https://openid.net/specs/openid-4-verifiable-presentations-1_0.html
- SD-JWT VC draft: https://datatracker.ietf.org/doc/draft-ietf-oauth-sd-jwt-vc/
- UMA 2.0: https://docs.kantarainitiative.org/uma/wg/rec-oauth-uma-grant-2.0.html
