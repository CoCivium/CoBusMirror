# IP_Front_Strategy_v0.2

**Session:** CoIP_Patents_v0  
**Version:** v0.02 (public-safe draft for counsel)  
**UTC build:** 20260122T070314Z  
**Hard rule:** private core/private core stays a **trade secret**. This bundle does **not** speculate on its contents.

## 0) Purpose (investor-credible “IP protection front”)
The goal is a credible, disciplined IP posture that signals “we take protection seriously” while
preserving
freedom-to-operate. This is **deterrence + clarity**, not courtroom dominance.

Primary effects:
- **“Patent pending”** optics (after filing) + a coherent story investors can believe.
- Defensive positioning: reduce risk of being boxed out by incumbents.
- Keep a narrow secret-sauce band private (private core/private core), while still patenting the *system-level* rails.

## 1) What to patent vs keep secret vs defensively publish

### 1.1 Buckets (policy)
**Patent (provisional now)** what is:
- System-level and describable without secrets.
- Likely to show up in competitors’ products (evidence-of-use).
- Hard to protect as a trade secret because it’s visible in protocols or artifacts.

**Trade secret (always)** what is:
- Hard to reverse engineer *if kept compartmented* (e.g., scoring/selection/verification core).
- Provides differentiation but does not need to be disclosed to operate the product.

**Defensively publish (selectively)** what is:
- Likely “commodity” or inevitable, but still useful to block others from patenting.
- Non-core primitives that help operations and trust branding.

### 1.2 High-level classification matrix

| Bucket | What goes here (examples) | Why (business/legal) |
|---|---|---|
| **Provisional patents (now)** | (A) Portable Trust Envelope (PTE) flows; (B) XR proximity/context-gated trust reveal; (C) Governance & provenance rails (canonical roots + pointer ledger + deterministic receipts); (D) AI-facing trust negotiation endpoints (CoAura-style) | Visible in product behavior; enables deterrence; can be described without private core/private core |
| **Trade secret (always)** | private core/private core: “private scoring/selection/verification core”; weights/thresholds; adversary models; abuse detection heuristics | Avoids disclosing the hardest-to-copy differentiator |
| **Defensive publication (later / selective)** | “Receipt discipline” patterns; pointer-only coordination conventions; canonical-root anti-fork patterns; generic consent UX patterns | Blocks others; still keeps crown jewels private |
| **Open (now)** | Interop glue and documentation aligned to standards (W3C VC/DID, OpenID4VP, SD-JWT) | Adoption leverage; lowers integration friction |

## 2) Recommended invention families (2–4 max, counsel-ready)
**Recommended for first provisional bundle:**
1. **Portable Trust Envelope (PTE)**: consent policy + selective reveal + portability of rep signals.
2. **XR Proximity/Context-Gated Trust Reveal**: reveal based on near-field / session context.
3. **Governance & Provenance Rails for AI-assisted Ops**: deterministic receipts + pointer registry + canonical roots.

**Optional 4th (only if we can draft cleanly fast):**
4. **AI-facing Trust Negotiation Endpoints (CoAura)**: machine-readable negotiation + consent gating.

## 3) Filing sequencing (“picket fence” / provisional bundle)
### 3.1 Minimum credible sequence (lean)
- **P0 (Day 0):** File **one** provisional that contains 3 families (PTE + XR gate + receipts rails).
- **P1 (Weeks 4–10):** File a **second** provisional (continuation-style) with refinements:
  - Add more embodiments, stronger claim breadth, and figure variants.
  - Add AI-facing endpoint family if ready.
- **N0 (By month 12):** Convert to non-provisional(s) and/or PCT (counsel choice).

### 3.2 “Picket fence” logic (investor story)
Instead of one giant application, build 2–4 families with overlapping coverage:
- A: product wedge (portable trust)  
- B: XR delivery mechanism (context/proximity gating)  
- C: operational defensibility (provenance rails)  
- D: future web interface mode (AI-facing endpoints)

This reads as: “core product + distribution + defensibility + future interface.”

## 4) Defensive publication posture (do **after** counsel alignment)
- Publish **non-core** operational patterns as dated disclosures (with hashes) once the provisional is filed.
- Publish in a way that qualifies as “printed publication” (counsel to advise venue).
- Keep disclosures at the level that blocks competitors without teaching them your private core.

## 5) “Secrecy boundary” rule of thumb
If a detail is:
- **Visible in network traces / artifacts** ⇒ treat as patentable (or accept it becomes public).
- **Not visible & high value** ⇒ trade secret (and compartment operationally).
- **Obvious / commodity / inevitable** ⇒ defensively publish or open.

## 6) Immediate next steps (counsel handoff)
- Review **Invention_Map_v0.1** (this bundle) and pick 3 families for P0.
- Use **Candidate_Inventions_v0.2** to start invention disclosure forms.
- Use **PriorArt_SearchPlan_v0.1** to run a fast scan and identify the closest 3–5 items per family.
- Draft provisional using **Provisional_Outline_PortableTrustEnvelope_v0.2** + figures list.

