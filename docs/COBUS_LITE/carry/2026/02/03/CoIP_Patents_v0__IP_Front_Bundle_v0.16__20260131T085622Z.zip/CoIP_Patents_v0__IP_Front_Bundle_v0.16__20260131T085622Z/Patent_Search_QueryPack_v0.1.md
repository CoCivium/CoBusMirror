# Patent_Search_QueryPack_v0.1

> Pragmatic query pack for counsel or an intern doing quick scans.

## Core keywords (mix & match)
- "verifiable presentation" consent policy
- selective disclosure credential policy tier step-up
- "SD-JWT" presentation policy
- "OpenID4VP" verifiable presentation request
- proximity gated credential presentation BLE QR nonce
- XR identity trust signal presentation
- deterministic receipt workflow verification gate
- canonical path registry pointer ledger append-only
- transparency log workflow receipt provenance

## Query templates
1) (verifiable OR credential) AND (policy OR consent) AND (presentation OR disclosure)
2) ("selective disclosure" OR "minimal disclosure") AND (credential OR presentation) AND (policy)
3) (proximity OR BLE OR NFC OR QR) AND (credential OR "verifiable presentation") AND (consent OR policy)
4) (receipt OR manifest) AND (workflow OR pipeline) AND (verification OR provenance)
5) (canonical OR "single source of truth") AND (registry OR ledger) AND (automation OR workflow)

## Classification hints (for counsel)
- Identity/authentication, cryptography, access control, privacy-preserving disclosure, XR/AR interaction.
- Consider searching within CPC/IPC classes relevant to:
  - authentication / access control
  - cryptographic protocols
  - data provenance / integrity
  - wearable / short-range / proximity interactions

## Search targets
- Google Patents
- USPTO search
- Espacenet
- Lens.org

## What to record
- closest 3–5 patents per family
- what they cover (mechanics vs system)
- our differentiation: consent policy capsule + disclosure minimization plan + context-gated step-up + deterministic receipts + canonical roots
