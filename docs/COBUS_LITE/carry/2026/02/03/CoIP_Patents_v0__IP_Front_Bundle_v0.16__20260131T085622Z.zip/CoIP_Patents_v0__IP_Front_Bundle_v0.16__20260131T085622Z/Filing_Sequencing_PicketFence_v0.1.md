
# Filing_Sequencing_PicketFence_v0.1

## Objective
Build a small, credible fence around the *exchange substrate* (not the private core) with 2–4 rapid provisionals.

## Suggested bundle (2–4 provisionals)
1) **PTE Core** — portable trust envelope with consent policy + selective disclosure
2) **XR Trust Reveal** — context/proximity-gated disclosure in XR interactions
3) **CoAura Endpoints** — machine-readable negotiation endpoints + receipts
4) **Ops Provenance** — canonical roots + pointer ledger + deterministic receipts

## Each provisional should include
- 3–6 embodiments (variations) to widen scope
- 6–12 figures across embodiments
- claim-like language embedded in “Summary” and “Embodiments” sections

## Continuation hooks (design-around traps)
- alternative transports: HTTPS, BLE, QR/NFC, DIDComm, etc.
- alternative credential formats: JSON-LD VC, JOSE/COSE-secured VC, SD-JWT VC, mdoc
- alternative policy grammars: rule lists, OPA/Rego-like, JSON schema constraints, capability tokens
- alternative receipt models: hash receipts, transparency log receipts, attestation receipts
