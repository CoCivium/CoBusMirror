# IP_Front_Strategy_v0.4

> **Intent:** an investor-credible “IP protection front” + deterrence posture.
> **Hard guardrails:** do not describe private core/private core beyond “a private scoring/selection/verification core.”

## 1) IP lanes (what we do and why)
### Lane 1 — Patent picket fence (fast, narrow, numerous)
File **multiple small provisionals** around interfaces and governance primitives:
- Portable Trust Envelope + consent policy capsule
- XR proximity/context-gated stepped disclosure
- AI-facing trust negotiation endpoints (“CoAura”)
- Deterministic receipts / pointer ledger / canonical roots (governance/provenance layer)

Why: increases diligence credibility and raises copycat friction without revealing the private core.

### Lane 2 — Trade-secret band (keep narrow)
Keep private:
- scoring/weighting/selection heuristics
- abuse thresholds and anomaly detection triggers
- partner-specific mappings and integration playbooks
- any “never write down” operational details

### Lane 3 — Defensive publication (selectively)
Defensively publish non-core patterns that are likely to be copied and are not differentiators by themselves:
- generic deterministic receipt formats
- manifest schemas
- pointer-ledger patterns
- redaction discipline patterns (as long as they don’t reveal thresholds/playbooks)

Suggested channels:
- IP.com PAD (paid, discoverable by examiners)
- TDCommons / similar (free, variable discoverability)
- arXiv / public tech memo (for non-patent blocking; counsel discretion)

## 2) What to patent vs keep secret vs defensively publish (matrix)
| Topic | Patent | Trade secret | Defensive publish |
|---|---:|---:|---:|
| Envelope format + policy semantics | ✅ |  |  |
| Step-up selective disclosure flows | ✅ | thresholds/heuristics | partial |
| XR proximity trigger handshake | ✅ | anti-gaming signals |  |
| AI-facing negotiation endpoint schema | ✅ | ranking/interpretation |  |
| Canonical roots + pointer ledger enforcement | ✅ | incident playbooks | ✅ (generic) |
| Receipt/manifest verification tooling | ✅ (broad) | redaction rules | ✅ (formats) |
| Private core scoring/verification |  | ✅ |  |
| Partner integration details |  | ✅ |  |

## 3) Sequencing (picket-fence)
**Stage 0: Freeze the boundary**
- write a 1-page secrecy matrix (done in this bundle)
- define “safe-to-disclose” claims scope (what works without private core/private core)

**Stage 1: Provisional bundle 1 (2–4 families)**
- file A + D first (portable trust + governance/provenance)
- file B and/or C as second/parallel provisionals if ready

**Stage 2: Defensive publication (after provisional)**
- publish generic parts of receipts/manifests/pointer registry to block copycats

**Stage 3: Continuations / PCT decisions**
- choose which families to pursue; keep others as deterrence-only

## 4) Claiming strategy (avoid painting into a corner)
- claim **systems + methods + non-transitory media**
- keep claims focused on: consent policy capsule + selective disclosure + step-up + provenance enforcement
- avoid claims that require revealing thresholds, scoring parameters, or partner mappings

## 5) Counsel handoff artifacts
This bundle includes:
- invention map + family briefs
- 10 candidate inventions with claim sketches
- prior art anchor list + search plan
- provisional skeleton for Portable Trust Envelope
- secrecy matrix

## 6) Non-goals (explicit)
- “courtroom dominance”
- litigating incumbents
- disclosing the private core
