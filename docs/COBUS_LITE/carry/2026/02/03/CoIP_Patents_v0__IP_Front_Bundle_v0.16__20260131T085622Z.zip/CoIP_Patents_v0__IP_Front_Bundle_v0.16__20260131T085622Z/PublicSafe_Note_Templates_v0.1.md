# PublicSafe_Note_Templates_v0.1
Generated: 20260131T085622Z

## Public-safe CoPong (one line)
# CoPong | FROM=<...> -> TO=<...> | UTC=<...> | STATE=INFO | ACTIONNOW=Run verifier; confirm PASS | PASS=ZipSHA256=<...> | RFA=none | POINTERS=URL_RAW=<...> VISIBILITY=public CLASS=PUB1 END

## Public-safe CoBus note (markdown)
- UTC=
- SESSION_LABEL=
- PRIME_ID=
- STATUS=doing/next
- VISIBILITY=public
- CLASS=PUB0|PUB1
- CHANGES=hash inventory, pointer updates
- RISKS=No enabling disclosures; IPGate PASS
- ACTIONS=verify receipts
