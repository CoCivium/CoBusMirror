
# IP_Front_Strategy_v0.3 — CoCivium “IP protection front” (marketing-first)

> **Goal:** an investor-credible posture that deters copycats and signals maturity, without leaking private core/private core.
> **Not legal advice.** This is counsel input and an internal strategy memo.

## 0) North star
- **We protect the *envelope and governance*** (portable trust, consent gates, provenance/receipts, interoperability).
- **We keep the core scoring/selection/verification core private** (private core/private core) as **trade secret**.
- **We use defensive publication** to block broad “obvious” patents by others on generic versions of our ideas.

## 1) Three buckets: patent vs trade secret vs defensive publish
### 1.1 Patent (file, then talk)
Patent things that are:
- visible in the product (easy to reverse engineer)
- needed for ecosystem adoption (standards-adjacent / partner-facing)
- strong for *marketing* (“we filed on X”)
Examples (candidate families):
- **Portable Trust Envelope**: consent-aware packaging of verifiable presentations with policy + selective disclosure.
- **XR proximity/context-gated trust reveal**: context signals drive what trust data is revealed (without doxxing).
- **Governance + provenance layer**: deterministic receipts + pointer registry + canonical roots to prevent drift.
- **AI-facing trust endpoints (CoAura)**: machine-readable negotiation endpoints with explicit consent semantics.

### 1.2 Trade secret (never patent)
Keep private anything that:
- provides durable advantage *and* can be kept confidential in operations
- would be expensive to defend in a patent fight (hard to prove infringement)
- is “how we decide” vs “how we exchange”
Examples:
- private core/private core internals (scoring/weights/thresholds/heuristics)
- abuse detection thresholds and escalation playbooks
- partner-specific integration constraints or datasets

### 1.3 Defensive publish (block others, keep ours free)
Defensive publish things that are:
- broad/generic versions of features we expect others to try to patent
- incremental “ops tricks” that are useful but not worth filing
- helpful to establish “prior art” for our exact combinations (without disclosing the secret core)
Examples:
- “Receipt + manifest + pointer-ledger” pattern generalized
- Consent policy language primitives (generic)
- XR trust reveal UX patterns (generic)

## 2) Portfolio shape: 2–4 invention families (“picket fence”)
Target **4 families max** to avoid dilution and keep counsel work feasible:
A) **Portable Trust Envelope (PTE)** — interoperable rep/consent packaging across platforms.
B) **XR Context/Proximity-gated Reveal** — safe, anti-doxxing trust reveal driven by context signals.
C) **CoAura endpoints** — AI-facing negotiation + machine-readable trust surfaces.
D) **Ops provenance substrate** — canonical roots + pointer registry + deterministic receipts for AI/human workflows.

**Marketing line:** “We’ve filed around the portable-trust substrate, not the private scoring core.”

## 3) Filing sequencing (fast + credible)
### 3.1 Stage 1 — Provisional bundle (2–4 provisionals, same month)
- File one provisional per invention family (A–D) with:
  - background, summary, drawings list, embodiments, example flows
  - multiple variations (“embodiments”) to widen scope
- Keep each provisional **self-contained**, but cross-reference the other families as optional modules.

### 3.2 Stage 2 — PCT / non-provisional selectivity (month ~10–12)
- Convert only the 1–2 families that show product traction / partner pull.
- Leave others as “marketing deterrent” unless traction appears.

### 3.3 Stage 3 — Continuations / picket extensions
- Use continuation strategy to “fence” competitor design-arounds as product realities emerge.

## 4) Disclosure boundaries (how to describe without leaking secrets)
**Describe publicly:**
- data structures, consent gates, portability, provenance receipts, verification flows
- interoperability with VC/DID/OpenID4VC/SD-JWT/DI cryptosuites
**Avoid describing:**
- exact scoring parameters, weights, thresholds, anomaly rules, internal ranking formulas
**Phrase safely:**
- “private verification core” / “private risk-scoring module” / “confidential policy evaluation logic”

## 5) Defensive publication playbook (high level)
- Publish generic disclosures to establish prior art **after** (or parallel to) provisional filing.
- Publish only what you can tolerate becoming public forever.
- Prefer established prior-art channels (see `Defensive_Publication_Playbook_v0.1.md`).

## 6) Investor-facing “IP front” script (public-safe)
- “We’re building **portable trust**: opt-in reputation and consent signals that users can carry across platforms without doxxing.”
- “We’re filing on the **exchange substrate** (consent-gated envelopes, provenance, and negotiation endpoints).”
- “A narrow core remains **trade secret** to preserve advantage and reduce disclosure risk.”
- “We will selectively **defensively publish** to prevent patent thickets that could harm the ecosystem.”

## 7) Counsel requests (what we want from the attorney)
- confirm novelty vs closest prior art, refine claim set, tighten drawings/embodiments
- recommend US provisional vs PCT timing and portfolio budget controls
- advise on trade-secret hygiene (what not to write down; employee/contractor controls)

See `Counsel_Handoff_Checklist_v0.1.md`.
