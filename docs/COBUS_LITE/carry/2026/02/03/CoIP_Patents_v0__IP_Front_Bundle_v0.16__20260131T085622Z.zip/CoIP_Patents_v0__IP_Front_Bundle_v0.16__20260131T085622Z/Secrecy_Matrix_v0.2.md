
# Secrecy_Matrix_v0.2

| Topic / Asset | Public now | Public later | Always private (trade secret) | Never write down (operational) | Lawyer-only |
|---|---:|---:|---:|---:|---:|
| Portable Trust Envelope structure + verification flows | ✅ |  |  |  |  |
| Consent policy schema (generic) | ✅ |  |  |  |  |
| XR context-gated trust reveal UX + semantics | ✅ |  |  |  |  |
| CoAura endpoint schemas + receipts | ✅ |  |  |  |  |
| Canonical roots / pointer ledger / deterministic receipts primitives | ✅ |  |  |  |  |
| private core/private core core scoring/selection/verification logic |  |  | ✅ | ✅ | ✅ |
| Abuse detection thresholds and response playbooks |  |  | ✅ | ✅ | ✅ |
| Partner integration specifics (names, constraints, data) |  | ✅ | ✅ | ✅ | ✅ |
| Keys, credentials, private server paths, vault-only locations |  |  | ✅ | ✅ | ✅ |
| Future open-sourcing plan / governance messaging | ✅ | ✅ |  |  |  |

**Rule of thumb:** if disclosure enables a copycat MVP in weeks, keep it in the right-hand columns.
