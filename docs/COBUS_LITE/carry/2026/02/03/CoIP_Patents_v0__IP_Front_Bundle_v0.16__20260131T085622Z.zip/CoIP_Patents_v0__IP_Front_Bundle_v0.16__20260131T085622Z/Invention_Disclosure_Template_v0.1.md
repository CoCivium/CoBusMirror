# Invention_Disclosure_Template_v0.1

> Use this template to capture **counsel-ready** invention disclosures without leaking trade secrets.

## 1) Working title (patent-safe)
-

## 2) Problem statement (1 paragraph)
-

## 3) Prior art (closest 3–5)
- (URL / patent no.) — why close
-

## 4) Summary of the invention (2–6 bullets)
-

## 5) Novelty hook (what is new / unexpected)
-

## 6) System overview (components)
- Client / wallet / verifier / policy service / audit store / etc.

## 7) Key method steps (high-level)
1.
2.
3.

## 8) Example use cases (2–3)
- XR proximity reveal
- cross-platform rep presentation
- AI-facing negotiation endpoint

## 9) Variants / alternatives (breadth)
- alternative credential formats (SD-JWT VC, JSON-LD + Data Integrity, etc.)
- alternative context signals (BLE, QR, device posture, session)
- alternative disclosure semantics (step-up, capped reveal, decoy claims)

## 10) What must be disclosed vs can remain private
### Must disclose (to support patent)
-
### Can remain private (trade secret)
- scoring/weighting/selection heuristics; risk thresholds; partner integration details

## 11) Suggested figures (sketch list)
- Fig 1: System block diagram
- Fig 2: Sequence diagram (policy-bound presentation)
- Fig 3: XR proximity trigger and step-up reveal
- Fig 4: Receipt generation + verification

## 12) Inventors / dates / public disclosure risk
- First conception date:
- Any planned demos/posts?
- Any prior public disclosure?
