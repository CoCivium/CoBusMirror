# ClosestPriorArt_Shortlist_v0.1
Generated: 20260122T101542Z

This is a pragmatic “closest hits” shortlist to arm counsel with early comparisons. It is *not* exhaustive.

## Family A — Portable Trust Envelope
Closest anchors:
1. W3C VC Data Model v2.0 (standard substrate): https://www.w3.org/TR/vc-data-model-2.0/
2. OpenID4VP 1.0 (presentation protocol): https://openid.net/specs/openid-4-verifiable-presentations-1_0.html
3. SD-JWT VC (selective disclosure VC format): https://datatracker.ietf.org/doc/draft-ietf-oauth-sd-jwt-vc/
4. U-Prove (selective disclosure credentials): https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/U-Prove20Technology20Overview20V1.120Revision202.pdf
5. Trust negotiation w/ hidden creds/policies (privacy-preserving negotiation): https://www.ndss-symposium.org/ndss2006/trust-negotiation-hidden-credentials-hidden-policies-and-policy-cycles/

Differentiation emphasis:
- Standard pieces exist; novelty is the **envelope + consent gate + cross-platform reputation portability** and its coupling to governance/provenance receipts (Family B).

## Family B — Governance & Provenance Layer for AI-assisted ops
Closest anchors:
1. SLSA v1.0 (provenance requirements): https://slsa.dev/spec/v1.0/
2. in-toto (attestation framework / metadata): https://in-toto.io/docs/specs/
3. TUF (update integrity roles/metadata): https://theupdateframework.github.io/specification/latest/
4. SCITT architecture (supply chain transparency services): https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
5. Certificate Transparency / Binary Transparency (append-only log patterns): https://www.rfc-editor.org/rfc/rfc6962 ; https://www.rfc-editor.org/rfc/rfc9162

Differentiation emphasis:
- Apply provenance/transparency primitives specifically to **agentic/multi-session orchestration** with canonical roots + pointer-ledger navigation + deterministic bundle receipts + redaction-safe public bus.

## Family C — Proximity/context-gated reveal in XR
Closest anchors:
1. NIST proximity-based authentication (Bluetooth): https://patents.google.com/patent/EP3497953B1
2. EP3497953B1 (proximity-based device authentication): https://patents.google.com/patent/US10237734/en
3. US10237734 (proximity-based access control policy): https://link.springer.com/article/10.1007/s10055-024-01079-9
4. NIST SP 800-207 (zero trust / context signals): https://www.nist.gov/publications/proximity-based-authentication-mobile-devices
5. VR security/privacy survey (context & threat landscape): https://www.microsoft.com/en-us/research/wp-content/uploads/2016/02/U-Prove20Technology20Overview20V1.120Revision202.pdf

Differentiation emphasis:
- The novelty is mapping proximity/context to **portable trust presentations** (VC/VP style) with explicit consent gating and receipts—i.e., not just device unlock, but **trust disclosure staging**.

## Family D — AI-facing trust negotiation endpoints
Closest anchors:
1. UMA 2.0 (policy + asynchronous access): https://docs.kantarainitiative.org/uma/wg/rec-oauth-uma-grant-2.0.html
2. GNAP (authorization negotiation patterns): https://datatracker.ietf.org/group/gnap/
3. OpenID4VP (presentation exchange): https://openid.net/specs/openid-4-verifiable-presentations-1_0.html
4. Trust negotiation literature (hidden credentials/policies): https://www.ndss-symposium.org/ndss2006/trust-negotiation-hidden-credentials-hidden-policies-and-policy-cycles/

Differentiation emphasis:
- Most prior art is protocol-level. The novelty claim should stress “AI-readable surfaces advertising proof requirements + consent constraints + provenance receipts” tied to the portable envelope.
