# CoIP_Patents_v0 — IP Front Bundle (v0.02)

**UTC build:** 20260122T070314Z  
**Scope:** Private, counsel-facing drafts to seed provisional filings and an investor-credible IP story.  
**Hard rule:** This bundle does **not** reveal or speculate on private core/private core.

## What changed since v0.01
- Added: **Invention_Map_v0.1**, **Secrecy_Matrix_v0.1**, **Naming_Options_v0.1**, **PriorArt_SearchPlan_v0.1**
- Upgraded: prior art log now includes concrete URLs and initial patent anchors.
- Upgraded: candidate inventions expanded to 8 with more structured claim sketches.
- Upgraded: provisional outline expanded with figure list + embodiments.

## Files
- IP_Front_Strategy_v0.2.md
- Invention_Map_v0.1.md
- Secrecy_Matrix_v0.1.md
- Naming_Options_v0.1.md
- PriorArt_SearchPlan_v0.1.md
- Candidate_Inventions_v0.2.md
- PriorArt_Log_v0.2.md
- Provisional_Outline_PortableTrustEnvelope_v0.2.md

## Verification
- See **SHA256SUMS.txt** for per-file hashes.
- See **Receipt.json** for bundle metadata + hash inventory.

## Handling discipline
- Treat this zip as **private** unless CoPrime explicitly chooses to publish parts post-filing.
- Anything in a public repo/public bus becomes public quickly.

