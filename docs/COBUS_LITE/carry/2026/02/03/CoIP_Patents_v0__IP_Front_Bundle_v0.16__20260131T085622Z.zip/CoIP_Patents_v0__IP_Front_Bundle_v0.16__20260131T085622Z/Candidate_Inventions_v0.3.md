
# Candidate_Inventions_v0.3

> **Format:** novelty hook, baseline delta, claim sketch (1 independent + 3–5 dependents), disclosure boundary.

## 1) Portable Trust Envelope (policy-carrying verifiable presentation)
**Novelty hook:** a verifiable presentation container that **carries consent policy** and supports selective disclosure by default.  
**Baseline delta:** beyond VC/DID baseline by making policy and anti-doxxing defaults first-class and portable across platforms.

**Claim sketch**
- **1.** A method comprising: receiving a request for trust information; generating a portable trust envelope comprising (i) a set of verifiable claims, (ii) a machine-readable consent policy, and (iii) selective disclosure material; presenting, to a verifier, a subset of the verifiable claims in accordance with the consent policy; and generating a receipt indicating the presented subset and verification outcome.
- **1.1** wherein the selective disclosure material comprises unlinkable derived proofs.
- **1.2** wherein the consent policy specifies permitted audiences, contexts, and attribute granularities.
- **1.3** wherein the verifiable claims are expressible in multiple credential formats.
- **1.4** wherein the receipt includes content hashes of the envelope and verification artifacts.

**Disclosure boundary**
- disclose: envelope fields, policy grammar, flows, receipt behavior.
- keep secret: trust scoring/selection thresholds used after verification.

---

## 2) Consent Policy Micro-Language for Trust Exchange
**Novelty hook:** a compact policy schema for “who can see what, when, and under what context,” carried with the envelope.  
**Baseline delta:** policy is transportable and auditable; not an app-specific permission model.

**Claim sketch**
- **2.** A system comprising: a policy schema defining disclosure constraints for verifiable claims; a policy evaluator configured to determine permitted disclosures based on context signals; and an envelope generator configured to bind the policy schema to the verifiable claims.
- **2.1** wherein constraints include time windows and session binding.
- **2.2** wherein constraints include attribute granularity levels.
- **2.3** wherein evaluation produces a deterministic disclosure decision receipt.
- **2.4** wherein policy changes are versioned and auditable via pointer-ledger references.

**Disclosure boundary**
- disclose: the schema and evaluation interface.
- keep secret: internal risk heuristics that influence “deny/allow” beyond explicit policy.

---

## 3) XR Context-gated Trust Reveal (trust-level ladder)
**Novelty hook:** a graduated trust reveal in XR driven by context (proximity/session/venue/role), reducing doxxing risk.  
**Baseline delta:** identity proofs typically ignore spatial/social context and correlation risk.

**Claim sketch**
- **3.** A method comprising: determining one or more context signals for an XR interaction; selecting a trust level responsive to the context signals; and presenting, to a recipient, a subset of trust attributes at a granularity corresponding to the trust level, subject to a consent policy.
- **3.1** wherein the context signals include a proximity proof.
- **3.2** wherein the trust level ladder maps to multiple attribute granularities.
- **3.3** wherein presentations are session-bound to prevent replay.
- **3.4** wherein correlation is reduced by generating unlinkable presentations.

**Disclosure boundary**
- disclose: ladder concept, context inputs, flows.
- keep secret: thresholds and anti-abuse heuristics that tune the ladder automatically.

---

## 4) Proximity / Presence Proof Modes for Anti-Scrape XR Trust
**Novelty hook:** optional proof-of-presence modes (BLE/QR/NFC/session tokens) to prevent remote scraping of trust signals.  
**Baseline delta:** general auth systems do not address “scrape at a distance” threats in XR.

**Claim sketch**
- **4.** A system comprising: a proximity verifier configured to validate a proximity proof; and a trust presentation module configured to permit disclosure of trust attributes only upon validation of the proximity proof.
- **4.1** wherein the proximity proof is established via BLE advertising.
- **4.2** wherein the proximity proof is established via an out-of-band QR or NFC exchange.
- **4.3** wherein the proximity verifier binds proof validity to a session identifier.
- **4.4** wherein the system emits a receipt proving the disclosure was proximity-gated.

**Disclosure boundary**
- disclose: supported modes and session-binding rules.
- keep secret: anti-abuse thresholds/rate limits.

---

## 5) Anti-correlation Trust Reveal Defaults (privacy hardening)
**Novelty hook:** presentation defaults explicitly minimize correlation and doxxing (e.g., unlinkable proofs, coarse granularity until consent upgrades).  
**Baseline delta:** many VC deployments optimize for verification, not correlation resistance.

**Claim sketch**
- **5.** A method comprising: receiving a request for trust attributes; selecting a correlation-minimizing disclosure strategy; and generating a presentation revealing the trust attributes at a reduced granularity while preserving verifiability.
- **5.1** wherein the disclosure strategy includes unlinkable derived proofs.
- **5.2** wherein the disclosure strategy includes rotating identifiers per session.
- **5.3** wherein the strategy is selected using context signals.
- **5.4** wherein the method stores only hashed receipts of disclosure events.

**Disclosure boundary**
- disclose: privacy defaults and strategies.
- keep secret: selection/ranking logic for strategies.

---

## 6) CoAura: Machine-readable Trust Negotiation Endpoint
**Novelty hook:** a standardized endpoint surface for agent/service trust negotiation, consent-aware, with deterministic receipts.  
**Baseline delta:** replaces ad-hoc APIs and human-only web pages with machine-readable negotiation verbs.

**Claim sketch**
- **6.** A system comprising: a network-accessible interface providing machine-readable capability descriptions; a negotiation engine configured to exchange trust requests and presentations subject to consent policy; and a receipt generator configured to output a deterministic receipt of the negotiation.
- **6.1** wherein capability descriptions include required credential types and policy constraints.
- **6.2** wherein negotiation supports request/offer/accept/reject verbs.
- **6.3** wherein receipts include hashes of exchanged messages.
- **6.4** wherein the interface is discoverable via standardized AI-facing documentation files.

**Disclosure boundary**
- disclose: endpoint schemas and receipt formats.
- keep secret: internal ranking/interpretation core for evaluating presented proofs.

---

## 7) Canonical Roots + Pointer Ledger to Prevent Drift in Orchestration
**Novelty hook:** force all automation to reference a canonical roots file plus append-only pointer ledger for reproducible navigation and provenance.  
**Baseline delta:** typical workflows lack hard anti-drift constraints across distributed agents and sessions.

**Claim sketch**
- **7.** A method comprising: reading a canonical roots configuration; enforcing that workflow steps reference only canonical roots and registered pointers; generating a pointer-ledger entry for each external reference; and producing a deterministic receipt for each workflow output.
- **7.1** wherein pointers comprise full URLs.
- **7.2** wherein ledger entries are append-only with cryptographic hashes.
- **7.3** wherein the method detects drift by comparing receipts across runs.
- **7.4** wherein redaction rules prevent sensitive details from being written to public logs.

**Disclosure boundary**
- disclose: canonical roots + ledger schemas and verification steps.
- keep secret: redaction/risk policies and escalation playbooks.

---

## 8) Deterministic Receipt + Manifest for Agentic Workflow Outputs
**Novelty hook:** every output bundle is accompanied by a deterministic manifest and verification scripts to detect regression/hallucination/erosion.  
**Baseline delta:** typical “AI outputs” are not reproducible or hash-verified end-to-end.

**Claim sketch**
- **8.** A system comprising: a manifest generator configured to compute hashes for each output artifact; a receipt generator configured to bind the manifest to workflow inputs and pointers; and a verifier configured to validate the receipt and detect differences across versions.
- **8.1** wherein the receipt is generated in a deterministic format.
- **8.2** wherein verification includes regression detection rules.
- **8.3** wherein manifests include dependency references and tool versions.
- **8.4** wherein receipts support third-party verification without access to private data.

**Disclosure boundary**
- disclose: receipt/manifest formats and verifier behavior.
- keep secret: internal heuristic rules that decide what is “acceptable drift.”

---

## 9) Trust-brand Defense: Authenticity Proofs for Community Trust Artifacts
**Novelty hook:** authenticity proofs for trust artifacts (anti-fork dilution) using tamper-evident receipts and provenance.  
**Baseline delta:** brand protection typically lacks cryptographic provenance integrated into community reputation artifacts.

**Claim sketch**
- **9.** A method comprising: generating a trust artifact for a community; producing a provenance receipt comprising hashes of the artifact and its source references; and verifying the provenance receipt to determine authenticity.
- **9.1** wherein verification includes checking a transparency log or attestation.
- **9.2** wherein artifacts include versioned policy identifiers.
- **9.3** wherein invalid artifacts are quarantined via governance rules.
- **9.4** wherein proofs are portable across platform boundaries.

**Disclosure boundary**
- disclose: provenance proof formats and verification rules.
- keep secret: fraud detection thresholds and response tactics.

---

## 10) Cross-platform Trust Signal Import/Export Contracts (format + governance)
**Novelty hook:** a standardized contract for importing/exporting reputation signals with opt-in consent and audit receipts, enabling platform interoperability without identity leakage.  
**Baseline delta:** “reputation” systems are mostly platform-siloed and non-portable.

**Claim sketch**
- **10.** A system comprising: an export module configured to produce portable trust signals for a subject; an import module configured to validate the trust signals using verifiable proofs; and a governance module configured to enforce consent policy and produce audit receipts.
- **10.1** wherein the export module redacts identifiers by default.
- **10.2** wherein the import module verifies freshness and session binding.
- **10.3** wherein audit receipts are shareable without revealing identity.
- **10.4** wherein trust signals are exchangeable across heterogeneous platforms.

**Disclosure boundary**
- disclose: contracts, formats, audit receipts.
- keep secret: scoring/weighting/ranking of imported signals.
