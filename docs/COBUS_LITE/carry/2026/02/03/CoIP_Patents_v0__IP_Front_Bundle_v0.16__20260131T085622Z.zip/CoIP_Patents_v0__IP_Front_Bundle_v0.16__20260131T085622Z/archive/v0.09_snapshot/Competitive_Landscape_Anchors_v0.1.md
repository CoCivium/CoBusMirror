# Competitive_Landscape_Anchors_v0.1

> This is *not* exhaustive. Purpose: show counsel/investors we know the baseline landscape.

## VC / credential platforms (baseline ecosystem)
- Microsoft Entra Verified ID (managed VC service) — see official product page + docs.  
- Trinsic (identity platform / acceptance network; wallets, issuance, verification).  
- SpruceID (wallet/verifier ecosystem; government/public sector work).  
- MATTR (credential issuance/verification; OpenID4VP support).

## Why we still have patentable surface (high-level)
Most platforms implement standards (VC/DID, OpenID4VP) and general wallet flows. Our claimable surface emphasizes:
- **consent policy capsule** bound to portable envelope
- **disclosure minimization plan** + tiered step-up
- **context/proximity gating for XR** with fail-closed behavior
- **governance/provenance layer** for AI-assisted ops (canonical roots + pointer ledger + deterministic receipts)

## Notes for counsel
- Use these as “non-patent” baseline references; don’t over-claim standard behavior.
- Differentiate via system combination + policy semantics + gating + auditability.
