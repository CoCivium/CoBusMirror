# Bundle_Index_v0.1

**Bundle:** CoIP_Patents_v0__IP_Front_Bundle_v0.04__20260122T073037Z

This bundle is intentionally **public-safe**. It assumes any “secret sauce” core (private core/private core) remains a trade secret and is never described here beyond generic boundary language.

## Start here
1) `BUNDLE_README.md` — how to use this bundle, verification steps, and counsel handoff notes  
2) `IP_Front_Strategy_v0.4.md` — what to patent vs keep secret vs defensive publish + sequencing  
3) `Invention_Map_v0.3.md` + `Invention_Family_Briefs_v0.2.md` — 2–4 families packaged for counsel  
4) `Candidate_Inventions_v0.4.md` — 10 candidate inventions with claim sketches & disclosure boundaries  
5) `PriorArt_Log_v0.4.md` + `PriorArt_SearchPlan_v0.3.md` — anchors and search plan  
6) `Provisional_Outline_PortableTrustEnvelope_v0.4.md` — counsel-ready provisional skeleton  
7) `Secrecy_Matrix_v0.3.md` — what stays private, what can go public, and when  

## New in v0.05
- Prior art upgraded: RFC 9901 (SD-JWT), MCP spec, DC API spec + blog posts, patents covering proximity/auth, ABAC with VCs, consent/privacy vaults, provenance verification.
- Added investor-facing 1-pager (safe, non-enabling) and invention disclosure template.
- Added an archive snapshot of v0.03 to prevent erosion/regressions.

## Archive
- `archive/v0.03_snapshot/` is a frozen copy of the prior bundle version to support regressions checks.

## Verification
- Run `Verify_Bundle.ps1` (PS7) or `Verify_Bundle.sh` (bash) inside the extracted bundle folder.

## New in v0.06
- Added counsel/law-firm RFP + engagement playbook + disclosure risk rules.
- Added draft claims set + drawings list + B/C/D provisional skeletons.

## New in v0.07
- Added counsel outreach templates + dataroom structure + disclosure log template.
- Added patent search query pack + competitive landscape anchors.
- Added draft narrative text blocks for Family A (PTE) and Family D (ops provenance).
- Added openness/licensing strategy note + term sanitizer glossary.
- Added CoPong draft handoff note (starts with '#').
