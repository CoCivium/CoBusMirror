# Verify_Bundle.ps1 (v0.11)
# PS7-safe. Verifies (from extracted bundle folder):
# 1) ZIP SHA256 (optional, if ZipPath provided and .sha256 sidecar exists)
# 2) SHA256SUMS.txt payload hashes (excludes SHA256SUMS.txt and Receipt.json)
# 3) ThemeLock required files + required headings
# 4) Optional Leak scan (if Leak_Scanner.ps1 present)
param(
  [Parameter(Mandatory=$false)][string]$ZipPath = ""
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function Sha256File([string]$p){
  (Get-FileHash -Algorithm SHA256 -LiteralPath $p).Hash.ToLower()
}

function ReadUtf8([string]$p){
  Get-Content -LiteralPath $p -Raw -Encoding UTF8
}

Write-Host "== Verify_Bundle.ps1 (v0.11) =="

# If ZipPath provided, verify against sidecar in same folder (if exists)
if($ZipPath -and (Test-Path -LiteralPath $ZipPath)){
  $sidecar = "$ZipPath.sha256"
  if(Test-Path -LiteralPath $sidecar){
    $expected = (Get-Content -LiteralPath $sidecar -Raw).Trim().Split()[0].ToLower()
    $actual = Sha256File $ZipPath
    if($expected -ne $actual){ throw "ZIP SHA256 FAIL: expected=$expected actual=$actual" }
    Write-Host "ZIP SHA256 OK"
  } else {
    Write-Host "NOTE: No .sha256 sidecar found next to zip."
  }
}

$root = (Get-Location).Path

# Payload hash check (excludes SHA256SUMS + Receipt to avoid self-reference loops)
$shaPath = Join-Path $root "SHA256SUMS.txt"
if(!(Test-Path -LiteralPath $shaPath)){ throw "Missing SHA256SUMS.txt" }

$lines = Get-Content -LiteralPath $shaPath -Encoding UTF8
foreach($line in $lines){
  if(-not $line.Trim()){ continue }
  $parts = $line.Split("  ",2)
  if($parts.Count -lt 2){ continue }
  $expect = $parts[0].Trim().ToLower()
  $rel = $parts[1].Trim()
  $fp = Join-Path $root $rel
  if(!(Test-Path -LiteralPath $fp)){ throw "Missing file referenced by SHA256SUMS: $rel" }
  $act = Sha256File $fp
  if($expect -ne $act){ throw "SHA256 FAIL: $rel expected=$expect actual=$act" }
}
Write-Host "Payload SHA256SUMS OK"

# ThemeLock check
$themePath = Join-Path $root "ThemeLock_v0.1.json"
if(!(Test-Path -LiteralPath $themePath)){ throw "Missing ThemeLock_v0.1.json" }
$theme = Get-Content -LiteralPath $themePath -Raw -Encoding UTF8 | ConvertFrom-Json

foreach($f in $theme.required_files){
  $fp = Join-Path $root $f
  if(!(Test-Path -LiteralPath $fp)){ throw "ThemeLock FAIL: missing required file: $f" }
}
Write-Host "ThemeLock required files OK"

foreach($kv in $theme.required_headings.PSObject.Properties){
  $file = $kv.Name
  $need = $kv.Value
  $fp = Join-Path $root $file
  $txt = ReadUtf8 $fp
  foreach($h in $need){
    if($txt -notmatch [regex]::Escape($h)){ throw "ThemeLock FAIL: missing heading '$h' in $file" }
  }
}
Write-Host "ThemeLock required headings OK"

# Optional leak scan
$leak = Join-Path $root "Leak_Scanner.ps1"
if(Test-Path -LiteralPath $leak){
  Write-Host "Running leak scan..."
  & $leak
}

Write-Host "VERIFY PASS"
