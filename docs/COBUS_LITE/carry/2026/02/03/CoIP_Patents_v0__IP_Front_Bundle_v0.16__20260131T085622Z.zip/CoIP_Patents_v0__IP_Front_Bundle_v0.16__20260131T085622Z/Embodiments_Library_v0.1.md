# Embodiments_Library_v0.1

> A catalog of embodiments/variants to make provisionals harder to design-around.
> Keep variants broad; avoid inner “private core” mechanics.

## Family A — Portable Trust Envelope (PTE)
1) Policy capsule variants
- tier table (Tier0..TierN) + step-up conditions
- retention limits (time, purpose, verifier class)
- expiry + revocation pointers
- context constraints (proximity required, session token required)
2) Presentation plan variants
- rule-based minimization plan
- verifier-provided acceptable alternative claim sets
- constraint satisfaction (minimize disclosure subject to requirements)
3) Formats / interoperability variants
- SD-JWT VC; OpenID4VP; VC DM 2.0-compatible representations
- multi-credential packing in one envelope
4) Receipt variants
- local-only receipt; append-only log receipt; transparency-log compatible receipt

## Family B — XR proximity/context gating
- BLE, QR, NFC, session token triggers
- liveness / continuity window for step-up
- venue-issued ephemeral session tickets
- refusal receipts for failed validation

## Family C — AI-facing negotiation endpoint (CoAura-style)
- well-known endpoint discovery; llms.txt hint; tool schema registry
- minimal proof plan with acceptable formats + policy terms
- multi-round step-up negotiation
- user-agent mediated consent (Digital Credentials API)
- receipts for negotiation requests/responses and proofs

## Family D — governance/provenance ops substrate
- signed canonical roots registry (single-source-of-truth)
- append-only pointer ledger; transparency log integration
- deterministic receipts binding step inputs/outputs/pointers/tool versions
- fail-closed mismatch + refusal receipt
- multi-session labeling + provenance graph export
