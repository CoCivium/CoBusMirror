
# Invention_Family_Briefs_v0.1 — 1-page briefs per family

## Family A — Portable Trust Envelope (PTE)
**One-liner:** Consent-carrying verifiable presentations that let users port trust signals across platforms without doxxing.

### Problem / pain
- Platform lock-in of reputation and consent.
- Over-sharing identity attributes when proving trust.
- Cross-platform verification is inconsistent.

### Proposed solution (system)
- Envelope contains: (i) verifiable claims, (ii) consent policy, (iii) selective-disclosure proof material, (iv) provenance receipt.
- Verifier uses policy + proof material to validate and decide what is revealed.
- Envelope supports multiple credential formats (VC Data Model, SD-JWT VC, mDL/ISO mdoc, etc.).

### Novelty hooks (how it differs from baseline VC/DID)
- Policy is **first-class** and travels with the presentation.
- Defaults are **anti-doxxing** and **anti-correlation** (unlinkable derived proofs when possible).
- Envelope designed for cross-platform “portable trust,” not just single-domain login.

### Claim scope sketch (family)
- independent: method/system for generating and verifying policy-carrying verifiable presentations with selective disclosure.
- dependents: policy grammar, redaction defaults, multi-format support, receipt integration.

### What must be disclosed vs can remain secret
- disclose: envelope format, flows, consent semantics, verification API behavior.
- keep secret: scoring/selection logic and thresholds for trust decisions (private core/private core).

### Suggested figures
1) data-flow: issuer/holder/verifier; envelope composition
2) sequence: request → consent → selective disclosure → verify → receipt
3) embodiment: multiple credential formats plugged into same envelope

### Closest prior art to compare (examples)
- W3C VC Data Model, VC Data Integrity, SD-JWT / SD-JWT VC, OpenID4VCI/OpenID4VP, DIF Presentation Exchange.

---

## Family B — XR Context/Proximity-gated Trust Reveal
**One-liner:** In XR, reveal trust signals gradually based on context (proximity/session/venue) with anti-correlation defaults.

### Problem / pain
- “Trust now” is needed; identity leaks are irreversible.
- Traditional identity proofs ignore spatial/social context.

### Proposed solution
- A verifier requests a trust reveal at a requested “trust level” plus context parameters.
- Holder’s wallet/agent evaluates consent policy and context; reveals only allowed granularity.
- Optional proximity proofs (BLE/QR/NFC or session-bound tokens) prevent remote scraping.

### Novelty hooks
- graduated reveal with context gating + consent policy
- anti-scrape controls (session binding, rate limits, proof-of-presence optional)
- portable trust: same reveal semantics across games/venues/platforms

### Claim scope sketch
- independent: method/system for context-gated selective disclosure of trust attributes in XR interactions.
- dependents: proximity proof modes, session binding, “trust level ladder,” anti-correlation transforms.

### Disclosure boundary
- disclose: gating framework, context parameters, UX flows.
- secret: detection thresholds, risk scoring, anti-abuse heuristics.

### Figures
1) XR interaction scene diagram (avatars + trust reveal overlay)
2) sequence: proximity establish → request → consent → reveal
3) table: trust level vs attribute granularity

---

## Family C — CoAura endpoints: AI-facing trust negotiation
**One-liner:** A machine-readable negotiation surface for agents to request trust, present proof, and receive receipts—consent-aware by default.

### Problem / pain
- Agents need standardized negotiation with consent + provenance.
- Humans can’t manually audit agent interactions at scale.

### Proposed solution
- “CoAura endpoint” exposes: capabilities, consent requirements, request schemas, and verification results.
- Supports agent-to-agent and agent-to-service negotiation patterns.
- Every negotiation emits a deterministic receipt.

### Novelty hooks
- explicit consent semantics + portable trust artifacts + receipts
- AI-facing interface patterns aligned with emerging agent protocols (MCP) and AI-doc conventions (llms.txt)

### Claim scope sketch
- independent: system providing a machine-readable endpoint for trust negotiation with consent gating and receipts.
- dependents: capability discovery, standardized negotiation verbs, receipt formats, replay protection.

### Disclosure boundary
- disclose: endpoints, schemas, receipts.
- secret: ranking/interpretation module that chooses which proofs are accepted or how they are weighted.

### Figures
1) endpoint capability graph
2) message sequence: request/offer/accept/receipt
3) data-flow: trust envelope into agent decision pipeline

---

## Family D — Ops governance + provenance substrate (Receipts)
**One-liner:** Prevent drift and prove lineage in distributed AI/human workflows using canonical roots + pointer ledger + deterministic receipts.

### Problem / pain
- AI-assisted ops are prone to silent drift (paths, versions, unstated assumptions).
- Teams can’t prove “what happened” or reproduce it.

### Proposed solution
- Canonical roots file prevents forked paths.
- Pointer registry is append-only (full URLs only) to enforce provenance.
- Receipts + manifests hash every output bundle; verification scripts detect regression.

### Novelty hooks
- applies software supply-chain provenance concepts to **multi-session AI/human orchestration**
- integrates redaction discipline (pointer-only comms) into the substrate

### Claim scope sketch
- independent: method/system generating deterministic receipts for agentic workflow artifacts using canonical roots and pointer-ledger references.
- dependents: receipt schema, regression checks, redaction enforcement, tamper-evident audit trail.

### Disclosure boundary
- disclose: schemas, verification flows.
- secret: risk models and redaction heuristics; internal governance escalation rules.

### Figures
1) artifact lineage DAG with hashes
2) sequence: create → hash → sign/attest → verify
3) canonical roots + pointer registry interaction diagram
