
# CoIP_Patents_v0 — IP Front Bundle v0.03

**Purpose:** marketing-first, investor-credible IP posture for CoCivium (seed-stage), **without** exposing private core/private core.
This bundle is written to be **public-safe** *as text*, but intended for **private handoff to CoPrime/counsel**.

## What’s inside (top-level)
- `IP_Front_Strategy_v0.3.md` — what to patent vs keep secret vs defensively publish; sequencing (“picket fence”).
- `Invention_Map_v0.2.md` — 4 invention families (A–D) in 1–2 pages.
- `Invention_Family_Briefs_v0.1.md` — 1-page briefs per family (problem/solution/novelty/claims/figures).
- `Candidate_Inventions_v0.3.md` — 10 candidate inventions w/ claim sketches and disclosure boundaries.
- `PriorArt_Log_v0.3.md` — 30 “core” anchors + appendix extras (standards, papers, patents, products).
- `PriorArt_SearchPlan_v0.2.md` — pragmatic search plan + query set + “closest prior art” shortlists.
- `Provisional_Outline_PortableTrustEnvelope_v0.3.md` — counsel-ready provisional skeleton + figure list.
- `Secrecy_Matrix_v0.2.md` — what is public now/later/always private/never write down/lawyer-only.
- `Defensive_Publication_Playbook_v0.1.md` — when and how to defensive publish without self-sabotage.
- `Filing_Sequencing_PicketFence_v0.1.md` — suggested sequencing and bundle structure for quick provisionals.
- `Naming_Options_v0.2.md` — boring patent-safe names + marketing umbrella names.
- `Claim_Term_Glossary_v0.1.md` — consistent terminology for claims/specs.
- `Counsel_Handoff_Checklist_v0.1.md` — what to give patent counsel; what counsel should ask us.
- `CHANGELOG.md` — what changed since v0.02.
- `Receipt.json` + `SHA256SUMS.txt` — internal integrity receipts for this bundle.
- `archive/v0.02_snapshot/` — frozen copy of prior bundle docs (prevents “erosion”).

## Integrity checks (Windows PowerShell 7)
```powershell
# Verify ZIP SHA
Get-FileHash -Algorithm SHA256 -LiteralPath ".\CoIP_Patents_v0__IP_Front_Bundle_v0.03__20260122T071916Z.zip"

# After unzipping, verify all file hashes:
Get-Content -LiteralPath ".\CoIP_Patents_v0__IP_Front_Bundle_v0.03__20260122T071916Z\SHA256SUMS.txt" |
  ForEach-Object {
    if($_ -match '^(?<sha>[a-f0-9]{64})\s\s(?<file>.+)$'){
      $p = Join-Path ".\CoIP_Patents_v0__IP_Front_Bundle_v0.03__20260122T071916Z" $Matches.file
      $h = (Get-FileHash -Algorithm SHA256 -LiteralPath $p).Hash.ToLower()
      if($h -ne $Matches.sha) { throw "HASH FAIL: $p" }
    }
  }
"OK"
```

## Non-legal note
This is **not legal advice**. It is structured input to accelerate a patent attorney’s work.


## Integrity model (v0.11)
- Primary integrity = ZIP SHA256 sidecar.
- Secondary (payload) integrity = SHA256SUMS.txt over payload files **excluding** SHA256SUMS.txt and Receipt.json (avoids self-reference).
- ThemeLock enforces required files/headings.
