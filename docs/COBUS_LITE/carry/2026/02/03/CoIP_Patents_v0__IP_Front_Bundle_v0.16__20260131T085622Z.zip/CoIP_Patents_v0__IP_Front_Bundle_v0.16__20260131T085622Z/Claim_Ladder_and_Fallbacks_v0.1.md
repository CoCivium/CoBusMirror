# Claim_Ladder_and_Fallbacks_v0.1

> A claim-scope ladder per family to help counsel structure broad-to-narrow coverage.

## Family A ladder (PTE)
1) Broad: envelope + policy capsule + minimization plan + explicit step-up consent
2) Narrower: selective disclosure via SD-JWT VC + OpenID4VP presentation request handling
3) Narrower: deterministic receipt binding request/plan/proof hashes
4) Narrower: policy capsule includes retention limits + verifier-class constraints
5) Narrower: issuer/holder binding and expiration semantics

## Family B ladder (XR proximity)
1) Broad: proximity/context trigger gates disclosure tier selection + step-up consent
2) Narrower: BLE/QR/session-token triggers with nonce challenge
3) Narrower: proximity continuity window for step-up
4) Narrower: refusal receipts and fail-closed behavior
5) Narrower: ephemeral session binding

## Family C ladder (AI-facing negotiation)
1) Broad: endpoint publishes acceptable proofs + returns minimal proof plan + consent-mediated presentation
2) Narrower: endpoint schema aligned with MCP-style tool schemas / web discovery
3) Narrower: step-up negotiation rounds + receipts
4) Narrower: user-agent mediated consent via Digital Credentials API
5) Narrower: retention constraints and policy terms attached to plan

## Family D ladder (ops provenance)
1) Broad: canonical roots registry + pointer ledger + deterministic receipt gating subsequent execution
2) Narrower: signed roots registry + append-only ledger
3) Narrower: transparency-log compatible receipt inclusion proofs
4) Narrower: multi-session labeling + provenance graph
5) Narrower: refusal receipts for mismatches
