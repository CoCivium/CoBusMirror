# PriorArt_SearchPlan_v0.1

**Session:** CoIP_Patents_v0  
**UTC build:** 20260122T070314Z  
**Goal:** pragmatic scan plan + initial closest items to sanity-check novelty positioning.

---

## General search workflow (fast)
1. Start with **standards baseline** (VC/DID/OpenID/SD-JWT) to define the “known floor.”
2. Search **Google Patents** + Lens.org using:
   - “verifiable credential presentation selective disclosure”
   - “context-aware access control proximity bluetooth”
   - “policy engine credential disclosure consent”
   - “receipt manifest hash verification workflow”
3. Capture the **closest 3–5** per family and write a 3-line differentiation note.

---

## Family A — Portable Trust Envelope (PTE)
### What to search
- “verifiable credential proof presentation subset attributes”
- “credential wallet consent policy selective disclosure”
- “portable reputation signal across platforms”
- “anti-doxxing reputation” / “privacy-preserving reputation badge”

### Closest prior art candidates (initial)
- W3C VCDM v2.0; DID Core; VC Data Integrity (baseline).
- IETF SD-JWT (selective disclosure).
- OpenID4VP / OpenID4VCI (presentation & issuance protocols).
- Patents on “verifiable credential” generation/presentation (see PriorArt_Log).

### Differentiation hypothesis (test with counsel)
- Claims focus on **envelope** bundling multi-issuer signals + explicit consent policy + portability for reputation use
  cases, not just a single credential presentation.

---

## Family B — XR Proximity/Context-Gated Trust Reveal
### What to search
- “proximity based authentication bluetooth nfc”
- “context aware access control social proximity”
- “policy engine location based access control”
- “XR proximity identity disclosure”

### Closest prior art candidates (initial)
- Proximity-based access control patents; context-aware access control patents.
- NFC/BLE proximity authentication patents.

### Differentiation hypothesis
- Combine selective disclosure presentations with **context evidence tokens** and **policy-selected minimal attribute
  set** tailored to XR sessions.

---

## Family C — Governance & Provenance Rails (Receipts + Canonical Roots + Pointer Ledger)
### What to search
- “deterministic receipt manifest hash verification”
- “append-only ledger pointer registry provenance”
- “workflow provenance in-toto slsa receipts”
- “reproducible navigation pointers urls”

### Closest prior art candidates (initial)
- SLSA provenance + in-toto attestation (baseline).
- Reproducible Builds project (baseline concept).
- Certificate Transparency (append-only Merkle log concept).
- SBOM standards (CycloneDX/SPDX) (inventory concept).

### Differentiation hypothesis
- Apply these supply-chain patterns specifically to **human+AI multi-session orchestration** with “canonical root”
  enforcement and pointer-only coordination designed to prevent silent drift.

---

## Family D — AI-facing Trust Negotiation Endpoints (CoAura-style)
### What to search
- “machine readable agent endpoint negotiation protocol”
- “digital credentials api request presentation user agent”
- “llms.txt machine readable site guidance”
- “model context protocol specification”

### Closest prior art candidates (initial)
- W3C Digital Credentials API (web-mediated request/issuance).
- MCP specification (agent-to-tool integration protocol).
- llms.txt proposal (site guidance for LLMs).

### Differentiation hypothesis
- Novel combination: agent-readable negotiation surface + consent-mediated credential exchange + receipts.

---

## Output standard (for counsel)
For each family, produce:
- 3–5 closest references, with URLs
- 5–10 “secondary” references
- 3-line differentiation note
- Any “killers” (if found) that collapse novelty claims

