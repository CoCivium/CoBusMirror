# Invention_Family_Briefs_v0.2

> Each family is packaged as a 1-page counsel brief: **problem → approach → novelty → claims sketch → prior art targets → secrecy boundary**.

## Family A — Portable Trust Envelope (policy-bound selective disclosure)
**Problem:** portable trust requires sharing “just enough” across platforms without doxxing or full data dumps.  
**Approach:** package verifiable claims (e.g., SD-JWT VC / VC DM 2.0) with a **Consent Policy Capsule** that expresses what can be revealed, when, to whom, and with what step-up options.  
**Novelty hook:** explicit policy semantics + selective disclosure + portability + step-up reveal (system composition).  
**Claims sketch:** method and system for generating an envelope that (i) binds disclosures to an issuer proof, (ii) binds to holder key, (iii) enforces policy-driven claim minimization and step-up.  
**Prior art targets:** RFC 9901; SD-JWT VC draft; OpenID4VP/4VCI; DC API; VC issuance/verification platform patents.  
**Secrecy boundary:** scoring/weighting/selection heuristics; partner-specific mappings.

## Family B — XR Proximity/Context-Gated Trust Reveal
**Problem:** XR encounters need a local, situational trust reveal; global profiles are unsafe.  
**Approach:** device-local context/proximity signals trigger a wallet presentation flow; disclosures are stepped and capped.  
**Novelty hook:** multi-signal context gating + step-up selective disclosure for XR presence.  
**Claims sketch:** verifier emits a proximity challenge (BLE/QR/session); holder wallet returns constrained disclosures; step-up requires explicit consent.  
**Prior art targets:** OpenID4VP over BLE; proximity auth/trust patents.  
**Secrecy boundary:** thresholds, anomaly detection, anti-gaming signals.

## Family C — AI-facing Trust Negotiation Endpoints (“CoAura”)
**Problem:** AI agents need machine-readable negotiation surfaces, but consent must remain explicit and auditable.  
**Approach:** publish AI-readable endpoint schemas describing required claims, acceptable proofs, and consent prompts; integrate DC API / wallet flows.  
**Novelty hook:** combining AI-facing interface patterns (MCP-like tool/resource schemas + llms.txt discovery patterns) with credential negotiation and explicit consent.  
**Claims sketch:** methods for machine-readable “trust negotiation endpoints” that return a minimal proof plan, then execute a consent-gated exchange.  
**Prior art targets:** MCP spec; llms.txt patterns; DC API; credential negotiation systems.  
**Secrecy boundary:** ranking/interpretation; anti-abuse; partner integrator details.

## Family D — Governance & Provenance Layer for AI-assisted Ops
**Problem:** distributed AI/human ops drift, fork, and silently corrupt state; audits are hard.  
**Approach:** canonical roots + pointer registry + deterministic receipts/manifests for every wave/artifact.  
**Novelty hook:** provenance layer framed as a governance substrate for safe multi-agent orchestration.  
**Claims sketch:** generating manifests/receipts that bind inputs, outputs, and pointers; verifying against canonical roots; preventing execution when drift detected.  
**Prior art targets:** TUF/Sigstore/in-toto/SLSA; provenance verification/workflow provenance patents; C2PA manifests.  
**Secrecy boundary:** redaction heuristics; incident response playbooks; risk scoring.
