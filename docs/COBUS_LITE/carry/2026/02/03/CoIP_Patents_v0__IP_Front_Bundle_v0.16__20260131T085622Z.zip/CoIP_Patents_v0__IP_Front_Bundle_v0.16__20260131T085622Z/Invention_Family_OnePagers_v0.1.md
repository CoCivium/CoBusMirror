# Invention_Family_OnePagers_v0.1

> 1-page summaries you can hand to counsel or investors (public-safe).
> Trade secret boundary: inner “private scoring/selection/verification core” (no mechanics).

## Family A — Portable Trust Envelope (PTE) + Consent Policy Capsule
**Problem:** cross-platform trust needs authenticity + privacy + explicit consent. Standards alone don’t guarantee minimization or step-up consent.  
**Solution:** a portable trust envelope containing verifiable claims + a machine-readable consent policy capsule. Verifier requests a presentation; holder computes a disclosure-minimization plan under policy; presents selectively disclosed proof; step-up requires re-consent. Optional deterministic receipt binds hashes (request, plan, proof).  
**Novelty hook:** policy capsule semantics + minimization plan + tiered step-up + optional receipts as a system composition.  
**Public vs secret:** public = envelope/policy interfaces + flows; secret = inner verification/scoring heuristics.  
**Quick filing:** 6–10 figures, 3–5 embodiments; avoid algorithmic scoring details.

## Family B — XR Proximity/Context-Gated Trust Reveal
**Problem:** XR interactions are high-context; trust must be shown without doxxing; proximity triggers are easy to spoof without robust gating.  
**Solution:** proximity/context triggers (BLE/QR/session token + nonce) validated locally; disclosure tier chosen under policy capsule; step-up requires proximity continuity and explicit re-consent; refusal receipts optionally emitted.  
**Novelty hook:** context/proximity gating + tier semantics + fail-closed behavior + portability across XR environments.  
**Public vs secret:** public = trigger validation + tier gating patterns; secret = fraud scoring thresholds and detection heuristics.

## Family C — AI-facing Trust Negotiation Endpoint (CoAura-style)
**Problem:** automated agents increasingly access resources; current auth often lacks explicit consent semantics and machine-readable “what proofs are acceptable.”  
**Solution:** machine-readable endpoint publishes acceptable proof requirements; agent requests a minimal proof plan; holder gives explicit consent (e.g., via user agent mediation); proof is presented and verified; step-up negotiation supported.  
**Novelty hook:** negotiation endpoint + policy semantics + minimal proof plan + receipts in a single interoperable pattern (not a proprietary “wallet silo”).  
**Public vs secret:** public = endpoint schema + negotiation flow; secret = ranking/interpretation core and partner integration specifics.

## Family D — Governance & Provenance Layer for AI-assisted Ops
**Problem:** agentic workflows drift; path/pointer forks corrupt provenance; audits are hard without deterministic receipts.  
**Solution:** canonical roots registry + append-only pointer ledger + deterministic receipts binding inputs/outputs/pointers. Execution gates on receipt verification; mismatches fail-closed and emit refusal receipts.  
**Novelty hook:** enforceable provenance primitives for multi-session orchestration; drift prevention as a workflow substrate.  
**Public vs secret:** public = primitives + verification gates; secret = risk/retention heuristics and internal playbooks.
