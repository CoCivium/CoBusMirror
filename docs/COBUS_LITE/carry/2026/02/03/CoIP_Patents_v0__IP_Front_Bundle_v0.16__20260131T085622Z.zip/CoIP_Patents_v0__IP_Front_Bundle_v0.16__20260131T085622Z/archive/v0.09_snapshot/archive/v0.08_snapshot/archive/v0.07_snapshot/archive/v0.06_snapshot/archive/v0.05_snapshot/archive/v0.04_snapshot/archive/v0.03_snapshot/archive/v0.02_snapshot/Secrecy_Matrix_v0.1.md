# Secrecy_Matrix_v0.1

**Session:** CoIP_Patents_v0  
**UTC build:** 20260122T070314Z  
**Intent:** one-page discipline guide for what goes where.

> Reminder: anything written in a public repo or public “bus” becomes public domain fast.
> This matrix is for **private** handling + counsel handoff.

| Category | Examples | Handling rule |
|---|---|---|
| **Public now** | Standards-aligned interop (VC/DID/OpenID4VP/SD-JWT); high-level product claims; non-secret terminology; public demos that reveal nothing sensitive | OK to publish |
| **Public later (post-filing)** | Receipt/manifest schemas; pointer-ledger schema; canonical-root enforcement patterns; high-level embodiments | Publish only after provisional filing (date-stamped) |
| **Always private (trade secret)** | private core/private core: scoring/selection/verification core; weights/thresholds; adversary models; abuse heuristics; feature engineering | Keep off public bus/repos; compartment; NDA when needed |
| **Never write down (operational)** | Incident playbooks; bypass procedures; red-team checklists; response triggers; accounts/credentials; server inventory | Oral / restricted; smallest distribution |
| **Lawyer-only** | Draft claims; novelty arguments; prior art comparisons; filing strategies | Share only with counsel under privilege where possible |

### Practical redaction rules
- Prefer **“private scoring/verification core”** over describing mechanics.
- Don’t include partner names, server paths, internal repo names, or private folder names.
- Prefer **hash-only** receipts for public surfaces; keep detailed manifests private unless post-filing and reviewed.

