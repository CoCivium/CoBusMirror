## v0.16 — 20260131T085622Z
- Added IPGate docs + machine-checkable taxonomy/placement rules + linter.
- Archived v0.14 zip reference.

## v0.14 — 20260122T101542Z
- Added counsel engagement playbook + pragmatic budgeting/briefing guidance.
- Added prior-art element map and closest-hit shortlist with primary anchors.
- Added provisional figure pack list.
- Expanded prior-art anchors + web_sources inventory.
- Archived v0.13 snapshot.

## v0.13 — 20260122T100806Z
- Sanitized internal-label tokens across **entire** bundle including `archive/` so the full zip remains share-safe.
- Added ARCHIVE_NOTICE.md (archive semantics + integrity model recap).
- Archived v0.12 snapshot.

## v0.12 — 20260122T100644Z
- Removed remaining internal-label tokens from non-archive docs to satisfy leak-scan patterns.
- Appended primary standards/provenance anchors to PriorArt + Competitive logs.
- Expanded web_sources.json with primary specs + provenance baselines.
- Archived v0.11 snapshot.

## v0.11 — 20260122T095914Z
- Fixed integrity model: SHA256SUMS + Receipt now hash **payload only** (exclude SHA256SUMS.txt and Receipt.json) to avoid self-reference failures.
- Rewrote Verify_Bundle.ps1 and Verify_Bundle.sh cleanly (removed accidental duplicated content).
- Archived v0.10 snapshot for regression checks.

## v0.10 — 20260122T095523Z
- Fixed leak scanner self-hit by excluding patterns/scanner/verify files from scan set.
- Scrubbed internal label tokens from non-archive docs to satisfy leak-scan policy.
- Added near-provisional Detailed Description summary for Families A & D.
- Archived full v0.09 snapshot for regression checks.

## v0.09 — 20260122T090811Z
- Added LeakScan patterns + Leak scanner scripts (PS/Bash) and wired them into Verify_Bundle.
- Added provisional bundle assembly checklist and embodiments library to expand enablement coverage.
- Added refined draft claims set v0.2 (stronger A & D independents + fallback dependents).
- Added invention family risk matrix for counsel/investor triage.
- Archived full v0.08 snapshot for regression checks.

## v0.08 — 20260122T085717Z
- Added invention family one-pagers (A–D) for fast counsel/investor briefing.
- Added filing cadence + picket-fence strategy (sequencing + rules).
- Added defensive publication playbook and IP ownership/assignment checklist.
- Added claim ladder/fallbacks document.
- Added draft narrative text blocks for Families B (XR gating) and C (AI-facing negotiation endpoint).
- Added investor diligence IP FAQ (public-safe talk track).
- Updated prior art anchors + web_sources with primary sources (RFC 9901, OpenID4VP Final, W3C VC2.0, W3C Digital Credentials API, MCP, llms.txt, SLSA/Sigstore/in-toto).
- Archived full v0.07 snapshot for regression checks.

## v0.07 — 20260122T084814Z
- Added counsel outreach templates, counsel dataroom structure, and disclosure log template.
- Added patent search query pack and competitive landscape baseline anchors.
- Added draft narrative text blocks for provisional drafting (Family A + D).
- Added openness/licensing strategy note and term sanitizer glossary.
- Added CoPong draft handoff notes (PS7-ready, starts with '#').
- Archived full v0.06 snapshot for regression checks.

## v0.06 — 20260122T083533Z
- Added law-firm/counsel selection RFP and engagement playbook.
- Added disclosure risk rules (stealth IP hygiene).
- Added draft-style claims, drawings list, and provisional skeletons for B/C/D.
- Archived full v0.05 snapshot for regression checks.

## v0.05 — 20260122T073156Z
- Added ThemeLock_v0.1.json + Verify_Bundle.ps1 + Verify_Bundle.sh to prevent erosion and detect missing headings.
- Archived full v0.04 snapshot for regression checks.

# CHANGELOG

## v0.04 — 20260122T073037Z
- Prior art upgraded and URL-validated (RFC 9901 SD-JWT, MCP spec, Digital Credentials API, OpenID4VP final, multiple patent anchors).
- Added: Bundle_Index, Investor one-pager, Invention disclosure template.
- Updated: IP_Front_Strategy, PriorArt_Log, SearchPlan, Provisional outline, Candidate inventions, Secrecy matrix, invention map/briefs.
- Archive: added v0.03 snapshot folder.


# Changelog — v0.03 (from v0.02)

## Added
- Invention family 1-page briefs (A–D)
- Defensive publication playbook (what, where, when; self-sabotage avoidance)
- Filing sequencing / “picket fence” bundle structure
- Claim term glossary (to keep claim language consistent across drafts)
- Counsel handoff checklist (what to provide, what to avoid writing down)
- Frozen snapshot of v0.02 under `archive/`

## Expanded / improved
- Strategy doc: clearer patent-vs-secret-vs-defensive-publish matrix; investor-friendly “IP front” narrative
- Candidate inventions: expanded to 10 candidates; strengthened claim sketches and disclosure boundaries
- Prior art log: clarified “core 30” vs appendix; added concrete standards URLs (W3C/IETF/OpenID/MCP/SLSA/etc)
- Search plan: added query set and “closest prior art” shortlists per family
- Provisional outline: added suggested figure list, example flows, and embodiment scaffolding

## Guardrails reaffirmed
- No speculation on private core/private core contents.
- No server paths, credentials, partner names, or vault-only details.

