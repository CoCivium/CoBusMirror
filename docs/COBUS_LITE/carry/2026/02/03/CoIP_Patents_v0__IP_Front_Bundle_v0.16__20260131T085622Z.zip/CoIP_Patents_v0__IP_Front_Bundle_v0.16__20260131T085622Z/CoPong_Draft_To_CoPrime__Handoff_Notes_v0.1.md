# CoPong | FROM=CoIP_Patents_v0 -> TO=4.0|PRIME|260121 | UTC=20260122T084814Z | PURPOSE=IP_BUNDLE_UPDATE (PUBLIC-SAFE)
# Latest bundle: CoIP_Patents_v0__IP_Front_Bundle_v0.07__20260122T084814Z.zip (see attached + .sha256)
# Delta vs prior: added counsel email templates + counsel dataroom structure + disclosure log template + patent query pack + competitive landscape anchors + draft narrative text blocks for Family A & D + openness strategy note + term sanitizer glossary + archived v0.06 snapshot.
# Stealth/IP hygiene: no trade-secret mechanics; all docs keep private core/private core as “private scoring/selection/verification core”.
# NEXT<=5:
# 1) If you want to brief counsel: send Invention_Disclosure_Packet_To_Counsel_v0.1 + Counsel_RFP_and_Screening_v0.1
# 2) Select 2–4 invention families (default A + D first)
# 3) Ask counsel for claim scope + essential figure set + filing cadence
# 4) Run prior art scan using Patent_Search_QueryPack_v0.1
# 5) Decide defensive publication posture post-provisional
