# Provisional_Draft_Text_B_XR_v0.1

> Draft narrative blocks for counsel to reuse (Family B). Avoid private-core mechanics.

## Background (draft)
XR interactions are contextual and often involve real-time proximity between participants. Conventional identity proofs can reveal personally identifying information and create doxxing risk. Proximity-based trust signaling can improve safety and coordination, but naive approaches are susceptible to spoofing, relay attacks, or over-disclosure.

## Summary (draft)
In one aspect, a holder device receives a proximity or context trigger (e.g., short-range radio signal, visual code, or session token) that includes a freshness component such as a nonce. The holder device validates the trigger locally and selects a disclosure tier for a portable trust envelope based on a consent policy capsule. The holder device presents a selectively disclosed proof corresponding to the selected tier. Presentation of higher tiers requires explicit re-consent and, in some embodiments, sustained proximity across a continuity window. When validation fails, the system fails closed and may generate a refusal receipt.

## Embodiments (draft)
- BLE trigger variant with rotating identifiers + nonce challenge.
- QR trigger variant displayed by verifier or venue.
- Session-token trigger variant within XR session infrastructure.
- Continuity window variant requiring repeated liveness checks prior to step-up.
- Refusal receipt variants (local-only or optional append-only log).
