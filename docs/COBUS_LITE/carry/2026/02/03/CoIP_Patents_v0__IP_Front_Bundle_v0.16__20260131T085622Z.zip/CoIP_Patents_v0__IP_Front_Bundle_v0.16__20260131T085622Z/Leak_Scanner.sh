#!/usr/bin/env bash
# Leak_Scanner.sh
# Simple substring scan using patterns file (no regex, no jq required).
# Excludes the patterns file and scanner scripts themselves to avoid self-hits.
set -euo pipefail
root="$(pwd)"
pat="$root/LeakScan_Patterns_v0.1.txt"
test -f "$pat" || { echo "Missing LeakScan_Patterns_v0.1.txt" >&2; exit 1; }

mapfile -t pats < <(grep -v '^\s*#' "$pat" | awk 'NF' | tr '[:upper:]' '[:lower:]')

exclude=("LeakScan_Patterns_v0.1.txt" "Leak_Scanner.ps1" "Leak_Scanner.sh" "Verify_Bundle.ps1" "Verify_Bundle.sh")

is_excluded() {
  local f="$1"
  for e in "${exclude[@]}"; do
    [[ "$f" == "$root/$e" ]] && return 0
  done
  return 1
}

files=$(find "$root" -type f ! -path "*/archive/*" \( -name "*.md" -o -name "*.txt" -o -name "*.json" -o -name "*.yml" -o -name "*.yaml" -o -name "*.ps1" -o -name "*.sh" -o -name "*.csv" \))

hits=0
while IFS= read -r f; do
  if is_excluded "$f"; then
    continue
  fi
  low=$(tr '[:upper:]' '[:lower:]' < "$f")
  for p in "${pats[@]}"; do
    if [[ "$low" == *"$p"* ]]; then
      echo "HIT: ${f#$root/}  pattern=$p"
      hits=$((hits+1))
    fi
  done
done <<< "$files"

if [[ "$hits" -gt 0 ]]; then
  echo "LEAK SCAN FAIL ($hits hits)" >&2
  exit 1
fi

echo "LEAK SCAN PASS"
