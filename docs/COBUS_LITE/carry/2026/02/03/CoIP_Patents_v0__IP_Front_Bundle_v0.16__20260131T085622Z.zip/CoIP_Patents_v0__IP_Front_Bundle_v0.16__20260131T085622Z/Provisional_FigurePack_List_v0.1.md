# Provisional_FigurePack_List_v0.1
Generated: 20260122T101542Z

Recommended figure set (portable across 1–2 provisionals). Keep diagrams abstract; avoid trade-secret internals.

1. System context diagram (actors): subject/holder, issuer(s), verifier(s), wallet/envelope, policy/consent service, provenance/receipt service.
2. Data model diagram: Portable Trust Envelope contents (credential refs, disclosure rules, consent policy, receipts, pointers).
3. Flow A1: Request → Consent gate → Presentation → Verification → Receipt.
4. Flow A2: Cross-platform rep signal import/export (pseudonymous, opt-in, minimal disclosure).
5. Flow B1: Canonical roots + pointer registry + deterministic receipt generation for a bundle.
6. Flow B2: Verification pipeline (hash inventory → manifest check → regression gate).
7. Flow C1: Proximity/context ladder in XR (far/near/handshake) controlling reveal level.
8. Flow D1: AI-facing endpoint advertises requirements → negotiation → presentation exchange.
9. Threat model figure: attacks + mitigations (doxxing, replay, probing, fork dilution, log poisoning, drift).
