# CoShare_Migration_IPGate_Checklist_v0.1
Generated: 20260131T085622Z

Purpose: crisp gate for what goes into public repos (CoBusMirror, CoShareHub, etc.).

## For EVERY candidate artifact
1) Classify: PUB0 / PUB1 / HOLD1 / HOLD2 / TS (see IP_Sensitivity_Policy_v0.1.md)
2) If HOLD1+ → keep private; publish only hashes/receipts/inventory
3) Run leak scan + enabling-disclosure sniff test

## Enabling-disclosure sniff test
Would a competent engineer implement meaningful parts from this text?
- YES → HOLD2
- MAYBE → HOLD1
- NO → PUB1 or PUB0

## Default allow (migration-safe)
- SHA inventories (hash + filename only), no prose describing internals
- Receipt/manifest formats without invention-family mechanics
- Pointer specs (full URLs) + generic redaction discipline

## Default block (high-risk)
- trust negotiation protocol rules / state machines
- envelope data model field-level specs
- proximity/context reveal ladders described mechanistically
- AI-facing endpoint negotiation rules
- fork-dilution/sabotage implementation details
