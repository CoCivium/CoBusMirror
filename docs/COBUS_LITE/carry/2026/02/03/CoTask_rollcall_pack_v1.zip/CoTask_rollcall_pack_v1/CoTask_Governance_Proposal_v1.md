# CoTask / CoLead / CoContext Governance Proposal (v1)
**Purpose:** Standardize the atomic unit of work, role delegation, identity/provenance, and leadership handoff so multi-session workflows stay coordinated—especially when no human is in the loop.

## 1) Core objects (separate unit-of-work, roles, and session classes)
### 1.1 CoTask (atomic assignable unit)
**CoTask** = smallest independently assignable work unit that carries a call-to-action and can be handed between sessions without losing intent or verification.

Minimum fields (normative):
- **CoTaskID**: stable unique id
- **CoCTA**: imperative action statement
- **SuccessCriteria**: verifiable completion definition
- **CoContextID**: bounded orchestration scope (see below)
- **CoMetaTrain**: tags that tie to products/themes/constraints
- **CoReceiptTargets**: where evidence must land (commit SHA, artifact hash, PR url, etc.)
- **CoTraceID**: correlation id for end-to-end observability

Optional but recommended:
- **Inputs/Outputs**: explicit artifacts + formats
- **Constraints**: safety, privacy, “follow only pointer-pack”, etc.
- **Rollback**: how to revert or invalidate the work if wrong

### 1.2 CoContext (scope boundary)
**CoContext** = a bounded orchestration scope (e.g., “MasterPlan branch X”, “Release train Y”, “Migration wave Z”).

Invariant:
- **Exactly one CoLead per CoContext at any moment.**

### 1.3 Session classes vs roles
- **CoPrime**: a *session class* (a type of session with orchestration mandate).
- **CoLead**: a *role* (a temporary decision anchor held by exactly one session per CoContext).
- **CoLead can be held by CoPrime** but can also be held by another session if CoPrime is absent/quarantined.

## 2) CoLead handoff: lease + fencing to avoid split-brain
A “lease” alone doesn’t prevent stale leaders from writing after partitions/pauses. Use both:

### 2.1 CoLeadLease (liveness)
- Lease has **TTL** and must be renewed by current CoLead.
- If lease expires, candidates may attempt acquisition.

### 2.2 CoLeadTerm (epoch)
- Every new leader acquisition increments a monotonic **term/epoch** for the CoContext.

### 2.3 CoFenceToken (safety)
- Every authoritative mutation must include the current **CoFenceToken**.
- Downstream/validators reject mutations with stale tokens.
- Authoritative actions include: canon pointer updates, merges, releases, publish-latest, quarantine decisions.

## 3) Identity & provenance: stop “self-declared identity drift”
### 3.1 CoIdentityCard
Each session instance carries an externally checkable “identity card”:
- Session label + session class
- Current roles (may include CoLead for specific CoContextIDs)
- Capability constraints (allowed mutation surfaces)
- Canonical pointer-pack reference (what it must follow)
- Provenance rule: prefer **content-addressed pointers** (commit SHA raw URLs + artifact hashes)

### 3.2 Practical rule
If a session cannot prove it followed the canonical pointer-pack (and cannot provide receipts),
its outputs are treated as **non-authoritative** until revalidated.

## 4) Observability: CoTrace across sessions
Give every CoTask a **CoTraceID** and require it in receipts, notes, and artifacts so work can be reconstructed later.

## 5) MasterPlan integration (minimal patch set)
Add a Governance/Orchestration section that is normative:
1. **CoTask Spec v1** (fields + invariants)
2. **Role Model** (session class vs role; “1 CoLead per CoContext”)
3. **Leadership Protocol** (CoLeadLease + CoLeadTerm + CoFenceToken)
4. **Identity/Provenance** (CoIdentityCard + pointer-pack rule)
5. **Audit/Telemetry** (CoTrace requirement)

Add a gate checklist for high-impact actions:
- Valid CoLead for CoContext?
- Mutation includes current CoFenceToken?
- Inputs are content-addressed and verified?
- CoTask links to CoTraceID + CoReceiptTargets?

## 6) Phased rollout (priority-first)
**Phase 1:** Define CoTask + CoContext + CoLead invariants in MasterPlan; require CoTask fields on new work.
**Phase 2:** Extend handoff notes to carry CoContextID + CoLead + term + fence + pointer-pack ref.
**Phase 3:** Token-gate authoritative actions (initially by human review, then by scripts).
**Phase 4:** Enforce CoTrace on receipts; add simple “trace timeline” index.
**Phase 5:** Allow “virtual CoPrime” patterns only after leases + fencing + identity gates are stable.

## 7) Suggested SideNote payload fields for handoffs (v1)
- CoContextID=...
- CoTaskID=... (or CoTask set)
- CoLead=... ; CoLeadTerm=... ; CoFenceToken=...
- CanonPointerPack=... (commit-SHA raw preferred)
- Receipts=... (sha256/pr/commit)
- NEXT=... ; NEED=... ; RISK=...

